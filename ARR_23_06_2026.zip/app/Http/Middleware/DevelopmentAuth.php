<?php

namespace App\Http\Middleware;

use Closure;
use App\Models\User;
use Illuminate\Support\Facades\Auth;

class DevelopmentAuth
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if (!Auth::check()) {
            $user = User::first();
            
            if (!$user) {
                // Create a default user if none exists
                $user = User::create([
                    'name' => 'Development User',
                    'email' => 'dev@example.com',
                    'password' => bcrypt('password'),
                    'is_active' => true,
                ]);
            }
            
            Auth::login($user);
        }

        return $next($request);
    }
}
