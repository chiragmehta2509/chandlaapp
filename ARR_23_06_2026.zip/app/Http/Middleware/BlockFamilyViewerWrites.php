<?php

namespace App\Http\Middleware;

use App\Models\User;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

/**
 * Family-member route enforcement.
 *
 * - Viewers (read-only): blocked from any non-GET except logout/own-password.
 * - Editors (full access): can add/edit, but blocked from:
 *     - DELETE methods (cannot delete events / chandla / contacts / etc.)
 *     - Family-member management (cannot add/remove other family members)
 *     - Pack & plan purchases (cannot spend money on parent's account)
 */
class BlockFamilyViewerWrites
{
    /** Routes neither role may invoke (always blocked for any family member). */
    private const FAMILY_BLOCKED_ROUTES = [
        // Family management — only main user can manage
        'client.family-members.store',
        'client.family-members.destroy',
        'client.family-members.reset-password',
        // Plan / pack purchases — billing is parent-only
        'client.packs.celebration.pay',
        'client.packs.celebration.payment-link',
        'client.packs.razorpay.order',
        'client.packs.razorpay.verify',
        'client.events.plan.update',
        'client.events.plan.payment.store',
        'client.events.plan.razorpay.order',
        'client.events.plan.razorpay.verify',
        'client.events.direct-gpay-unlock.store',
        'client.events.direct-gpay-unlock.razorpay.order',
        'client.events.direct-gpay-unlock.razorpay.verify',
        'client.events.direct-gpay-unlock.redeem-guest-pay-pack',
        'client.marriage-invitations.payment',
        'client.marriage-invitations.payment.submit',
        'client.marriage-invitations.payment.razorpay',
        'client.marriage-invitations.payment.razorpay.order',
        'client.marriage-invitations.payment.razorpay.verify',
    ];

    /** Viewer-only allowlist for non-GET requests. */
    private const VIEWER_WRITE_ALLOWLIST = [
        'client.logout',
        'client.password.update',
    ];

    public function handle(Request $request, Closure $next)
    {
        /** @var \App\Models\User|null $user */
        $user = Auth::user();
        if (!$user || !$user->isFamilyMember()) {
            return $next($request);
        }

        $method = $request->method();
        $routeName = $request->route()?->getName();

        if (in_array($routeName, self::FAMILY_BLOCKED_ROUTES, true)) {
            return $this->forbid($request, 'Only the main account can do this.');
        }

        if (in_array($method, ['GET', 'HEAD'], true)) {
            return $next($request);
        }

        if ($user->isFamilyEditor()) {
            // Editors cannot DELETE — prevents removal of parent's records.
            if ($method === 'DELETE') {
                return $this->forbid($request, 'Family editors cannot delete records. Ask the main account holder.');
            }
            return $next($request);
        }

        // Viewer: block all writes except whitelisted (logout, change own password).
        if (in_array($routeName, self::VIEWER_WRITE_ALLOWLIST, true)) {
            return $next($request);
        }

        return $this->forbid($request, 'Family viewer accounts are read-only.');
    }

    private function forbid(Request $request, string $message)
    {
        if ($request->expectsJson()) {
            return response()->json(['error' => $message], 403);
        }
        abort(403, $message);
    }
}
