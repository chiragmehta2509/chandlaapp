<?php

namespace App\Http\Controllers\Api\UPI;

use App\Http\Controllers\Controller;
use App\Models\UPITransaction;
use App\Models\Event;
use App\Services\PaymentService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;

class UPIController extends Controller
{
    protected $paymentService;

    public function __construct(PaymentService $paymentService)
    {
        $this->paymentService = $paymentService;
    }

    public function index(Request $request)
    {
        $perPage = $request->get('per_page', 15);
        $transactions = $request->user()
            ->upiTransactions()
            ->with('event')
            ->orderBy('created_at', 'desc')
            ->paginate($perPage);

        return response()->json([
            'success' => true,
            'data' => $transactions
        ]);
    }

    public function show(Request $request, $id)
    {
        $transaction = $request->user()
            ->upiTransactions()
            ->with('event')
            ->findOrFail($id);

        return response()->json([
            'success' => true,
            'data' => $transaction
        ]);
    }

    public function createOrder(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'amount' => 'required|numeric|min:1',
            'event_id' => 'nullable|exists:events,id',
            'description' => 'nullable|string',
            'payment_method' => 'nullable|string|in:upi,card,netbanking,wallet',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation error',
                'errors' => $validator->errors()
            ], 422);
        }

        if ($request->event_id) {
            $event = $request->user()->events()->findOrFail($request->event_id);
        }

        $transaction = UPITransaction::create([
            'user_id' => $request->user()->id,
            'event_id' => $request->event_id,
            'transaction_id' => 'TXN' . Str::random(16),
            'amount' => $request->amount,
            'status' => 'pending',
            'payment_method' => $request->payment_method ?? 'upi',
            'description' => $request->description,
        ]);

        // Create Razorpay order
        $order = $this->paymentService->createOrder([
            'amount' => $request->amount * 100, // Convert to paise
            'currency' => 'INR',
            'receipt' => $transaction->transaction_id,
        ]);

        $transaction->update([
            'razorpay_order_id' => $order['id'],
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Order created successfully',
            'data' => [
                'transaction' => $transaction,
                'razorpay_order_id' => $order['id'],
                'amount' => $order['amount'],
                'currency' => $order['currency'],
            ]
        ]);
    }

    public function verifyPayment(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'razorpay_order_id' => 'required|string',
            'razorpay_payment_id' => 'required|string',
            'razorpay_signature' => 'required|string',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation error',
                'errors' => $validator->errors()
            ], 422);
        }

        $transaction = $request->user()
            ->upiTransactions()
            ->where('razorpay_order_id', $request->razorpay_order_id)
            ->firstOrFail();

        // Verify signature
        $isValid = $this->paymentService->verifySignature(
            $request->razorpay_order_id,
            $request->razorpay_payment_id,
            $request->razorpay_signature
        );

        if (!$isValid) {
            $transaction->update(['status' => 'failed']);
            return response()->json([
                'success' => false,
                'message' => 'Payment verification failed'
            ], 400);
        }

        $transaction->update([
            'razorpay_payment_id' => $request->razorpay_payment_id,
            'razorpay_signature' => $request->razorpay_signature,
            'status' => 'completed',
            'paid_at' => now(),
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Payment verified successfully',
            'data' => $transaction
        ]);
    }

    public function refund(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'transaction_id' => 'required|exists:upi_transactions,transaction_id',
            'amount' => 'nullable|numeric',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation error',
                'errors' => $validator->errors()
            ], 422);
        }

        $transaction = $request->user()
            ->upiTransactions()
            ->where('transaction_id', $request->transaction_id)
            ->where('status', 'completed')
            ->firstOrFail();

        $refundAmount = $request->amount ?? $transaction->amount;

        // Process refund via Razorpay
        $refund = $this->paymentService->refund($transaction->razorpay_payment_id, $refundAmount);

        if ($refund) {
            $transaction->update(['status' => 'refunded']);
            return response()->json([
                'success' => true,
                'message' => 'Refund processed successfully',
                'data' => $transaction
            ]);
        }

        return response()->json([
            'success' => false,
            'message' => 'Refund failed'
        ], 400);
    }

    public function getHistory(Request $request)
    {
        $transactions = $request->user()
            ->upiTransactions()
            ->with('event')
            ->orderBy('created_at', 'desc')
            ->get();

        return response()->json([
            'success' => true,
            'data' => $transactions
        ]);
    }

    public function getStats(Request $request)
    {
        $user = $request->user();

        $stats = [
            'total_transactions' => $user->upiTransactions()->count(),
            'completed_transactions' => $user->upiTransactions()->completed()->count(),
            'pending_transactions' => $user->upiTransactions()->pending()->count(),
            'failed_transactions' => $user->upiTransactions()->failed()->count(),
            'total_amount' => $user->upiTransactions()->completed()->sum('amount'),
            'this_month_amount' => $user->upiTransactions()
                ->completed()
                ->whereMonth('created_at', now()->month)
                ->sum('amount'),
        ];

        return response()->json([
            'success' => true,
            'data' => $stats
        ]);
    }
}

