{{-- Live-rendered template snapshot (iframe shrinks HTML/CSS from real Blade layouts). Expects $thumbSrc, optional $thumbTitle. --}}
<div class="relative aspect-[5/8] w-full overflow-hidden bg-slate-100 isolate rounded-sm">
    <iframe
        src="{{ $thumbSrc }}"
        title="{{ $thumbTitle ?? 'Invitation preview' }}"
        loading="lazy"
        class="pointer-events-none absolute inset-0 h-full w-full border-0"
        referrerpolicy="no-referrer-when-downgrade"
    ></iframe>
</div>
