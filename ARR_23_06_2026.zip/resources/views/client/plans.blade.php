@extends('layouts.client')

@section('title', 'Plans & pricing')

@section('content')
<div class="space-y-8 sm:space-y-10 pb-8 w-full min-w-0 max-w-full overflow-x-hidden">
    {{-- Active Package Status --}}
    @php
        $user = Auth::user();
        $planLevel = $user->planLevel();
        $planNames = [
            0 => 'Starter Plan',
            1 => 'Celebration Pack',
            2 => 'Guest Contribution',
            3 => 'Host Plus Plan',
            4 => 'Family Plan',
            5 => 'Premium Host Plan',
            6 => 'Professional Plan',
            7 => 'Enterprise Plan'
        ];
        $planBadges = [
            0 => 'bg-slate-100 text-slate-700 border-slate-200',
            1 => 'bg-indigo-50 text-indigo-700 border-indigo-200',
            2 => 'bg-amber-50 text-amber-700 border-amber-200',
            3 => 'bg-sky-50 text-sky-700 border-sky-200',
            4 => 'bg-purple-50 text-purple-700 border-purple-200',
            5 => 'bg-emerald-50 text-emerald-700 border-emerald-200',
            6 => 'bg-rose-50 text-rose-700 border-rose-200',
            7 => 'bg-zinc-800 text-amber-200 border-zinc-700'
        ];
        $planIcons = [
            0 => 'fa-seedling text-slate-400',
            1 => 'fa-wand-magic-sparkles text-indigo-500',
            2 => 'fa-qrcode text-amber-500',
            3 => 'fa-book-open text-sky-500',
            4 => 'fa-shield-halved text-purple-500',
            5 => 'fa-gem text-emerald-500',
            6 => 'fa-briefcase text-rose-500',
            7 => 'fa-building text-amber-300'
        ];
        $activePlanName = $planNames[$planLevel] ?? 'Starter Plan';
        $activeBadgeClass = $planBadges[$planLevel] ?? 'bg-slate-100 text-slate-700 border-slate-200';
        $activeIconClass = $planIcons[$planLevel] ?? 'fa-seedling text-slate-400';
    @endphp

    <div class="cb-card border border-slate-200/90 bg-white p-5 rounded-2xl shadow-sm flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div class="flex items-center gap-3">
            <span class="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-slate-50 border border-slate-100 text-lg shadow-sm">
                <i class="fa-solid {{ $activeIconClass }}" aria-hidden="true"></i>
            </span>
            <div>
                <p class="text-xs font-semibold text-slate-500 uppercase tracking-wide">Your Active Package</p>
                <h2 class="text-lg font-extrabold text-slate-900 flex items-center gap-2 mt-0.5">
                    {{ $activePlanName }}
                    <span class="inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider {{ $activeBadgeClass }}">
                        Active
                    </span>
                </h2>
            </div>
        </div>
        <div class="text-xs text-slate-500 sm:text-right">
            @if($planLevel === 0)
                <p class="text-slate-600">You are on the free tier. Upgrade below to unlock premium features.</p>
            @elseif($planLevel >= 5)
                <p class="text-emerald-700 font-semibold">You have premium access to site modules &amp; features!</p>
            @else
                <p class="text-slate-600">Unlock more features or upgrade to a higher tier anytime.</p>
            @endif
        </div>
    </div>
    {{-- New Interconnected Pricing Section --}}
    <div class="mt-8">
        @include('partials.pricing-section')
    </div>
</div>
@endsection
