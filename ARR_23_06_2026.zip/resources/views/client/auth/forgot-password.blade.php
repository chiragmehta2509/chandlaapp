<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot password - Chandla Book</title>
    <link rel="stylesheet" href="{{ asset('css/tailwind.css') }}?v=2">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="min-h-screen bg-slate-950 text-white">
    <div class="min-h-screen bg-gradient-to-br from-indigo-950 via-purple-900 to-slate-950 flex flex-col">
        <header class="max-w-6xl w-full mx-auto px-4 sm:px-6 py-4 flex items-center justify-between">
            <a href="{{ route('public.home') }}" class="flex items-center gap-2 sm:gap-3 group">
                <img src="{{ asset('images/chandla-favicon.png') }}" alt="Chandla Book" class="h-10 sm:h-12 w-auto">
                <span class="text-lg sm:text-2xl font-bold text-white group-hover:text-white/90">Chandla Book</span>
            </a>
            <a href="{{ route('public.home') }}" class="text-sm text-white/80 hover:text-white font-medium">
                ← Home
            </a>
        </header>

        <div class="flex-1 flex items-center justify-center px-4 py-8 sm:py-12">
            <div class="w-full max-w-md">
                <div class="bg-white/10 backdrop-blur-md rounded-2xl border border-white/20 p-6 sm:p-8 shadow-xl">
                    <div class="text-center mb-8">
                        <h1 class="text-2xl sm:text-3xl font-bold text-white">Forgot password</h1>
                        <p class="text-white/70 mt-2 text-sm sm:text-base">We&apos;ll email you a reset link.</p>
                    </div>

                    @if($errors->any())
                        <div class="mb-4 rounded-lg border border-red-400/50 bg-red-500/20 px-4 py-3 text-sm text-red-100">
                            <ul class="list-disc list-inside space-y-1">
                                @foreach($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                        </div>
                    @endif
                    @if(session('status'))
                        <div class="mb-4 rounded-lg border border-emerald-400/50 bg-emerald-500/20 px-4 py-3 text-sm text-emerald-100">
                            {{ session('status') }}
                        </div>
                    @endif

                    <form method="POST" action="{{ route('password.email') }}">
                        @csrf
                        <div class="mb-6">
                            <label class="block text-sm font-medium text-white/80 mb-2" for="email">Registered email</label>
                            <input
                                class="w-full rounded-xl border border-white/20 bg-white/10 px-4 py-3 text-white placeholder:text-white/40 focus:border-indigo-400/60 focus:outline-none focus:ring-2 focus:ring-indigo-500/40"
                                id="email"
                                type="email"
                                name="email"
                                value="{{ old('email') }}"
                                required
                                autofocus
                                autocomplete="email"
                                placeholder="you@email.com"
                            >
                        </div>

                        <button type="submit" class="w-full flex items-center justify-center gap-2 rounded-lg bg-white px-4 py-3 text-base font-semibold text-indigo-700 shadow transition hover:bg-indigo-50">
                            <i class="fas fa-paper-plane"></i>
                            Send reset link
                        </button>

                        <p class="mt-6 text-center text-sm text-white/70">
                            Remembered it?
                            <a href="{{ route('client.login') }}" class="font-semibold text-white hover:underline">Back to login</a>
                        </p>
                    </form>
                </div>

                <p class="text-center mt-6 text-xs text-white/50">
                    Need an account?
                    <a href="{{ route('client.register') }}" class="text-indigo-200 hover:text-white">Get started</a>
                </p>
            </div>
        </div>

        <p class="text-center mt-8 text-xs text-white/45 px-4">
            <a href="{{ route('public.privacy') }}" class="hover:text-white/90">Privacy</a>
            <span class="mx-2">·</span>
            <a href="{{ route('public.terms') }}" class="hover:text-white/90">Terms</a>
        </p>
    </div>
</body>
</html>
