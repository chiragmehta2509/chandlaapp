<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - Chandla Book</title>
    <link rel="stylesheet" href="{{ asset('css/tailwind.css') }}?v=2">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="min-h-screen bg-slate-950 text-white">
    <div class="min-h-screen bg-gradient-to-br from-indigo-950 via-purple-900 to-slate-950 flex flex-col">
        <header class="max-w-6xl w-full mx-auto px-4 sm:px-6 py-4 flex items-center justify-between">
            <a href="{{ route('public.home') }}" class="flex items-center gap-2 sm:gap-3 group">
                <img src="{{ asset('images/chandla-favicon.png') }}" alt="Chandla Book" class="h-10 sm:h-12 w-auto" decoding="async">
                <span class="text-lg sm:text-2xl font-bold text-white group-hover:text-white/90">Chandla Book</span>
            </a>
            <a href="{{ route('public.home') }}" class="text-sm text-white/80 hover:text-white font-medium">
                ← Home
            </a>
        </header>

        <div class="flex-1 flex items-center justify-center px-4 py-8 sm:py-12">
            <div class="w-full max-w-md">
                <div class="bg-white/10 backdrop-blur-md rounded-2xl border border-white/20 p-6 sm:p-8 shadow-xl">
                    <div class="text-center mb-8">
                        <h1 class="text-2xl sm:text-3xl font-bold text-white">Create your account</h1>
                        <p class="text-white/70 mt-2 text-sm sm:text-base">Join Chandla Book</p>
                    </div>

                    @if($errors->any())
                        <div class="mb-4 rounded-lg border border-red-400/50 bg-red-500/20 px-4 py-3 text-sm text-red-100">
                            <ul class="list-disc list-inside space-y-1">
                                @foreach($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                        </div>
                    @endif
                    @if(session('status'))
                        <div class="mb-4 rounded-lg border border-emerald-400/50 bg-emerald-500/20 px-4 py-3 text-sm text-emerald-100">
                            {{ session('status') }}
                        </div>
                    @endif

                    <form method="POST" action="{{ route('client.register') }}">
                        @csrf
                        <div class="mb-5">
                            <label class="block text-sm font-medium text-white/80 mb-2" for="name">Full name *</label>
                            <input
                                class="w-full rounded-xl border border-white/20 bg-white/10 px-4 py-3 text-white placeholder:text-white/40 focus:border-indigo-400/60 focus:outline-none focus:ring-2 focus:ring-indigo-500/40"
                                id="name"
                                type="text"
                                name="name"
                                value="{{ old('name') }}"
                                required
                                autofocus
                                autocomplete="name"
                                placeholder="Your name"
                            >
                        </div>
                        <div class="mb-5">
                            <label class="block text-sm font-medium text-white/80 mb-2" for="email">Email *</label>
                            <input
                                class="w-full rounded-xl border border-white/20 bg-white/10 px-4 py-3 text-white placeholder:text-white/40 focus:border-indigo-400/60 focus:outline-none focus:ring-2 focus:ring-indigo-500/40"
                                id="email"
                                type="email"
                                name="email"
                                value="{{ old('email') }}"
                                required
                                autocomplete="email"
                                placeholder="you@gmail.com"
                                maxlength="255"
                            >
                            <p class="mt-1.5 text-xs text-white/55">Real inbox required — we check the domain and block disposable / temp mail.</p>
                        </div>
                        <div class="mb-5">
                            <label class="block text-sm font-medium text-white/80 mb-2" for="phone">Mobile number *</label>
                            <input
                                class="w-full rounded-xl border border-white/20 bg-white/10 px-4 py-3 text-white placeholder:text-white/40 focus:border-indigo-400/60 focus:outline-none focus:ring-2 focus:ring-indigo-500/40"
                                id="phone"
                                type="tel"
                                name="phone"
                                value="{{ old('phone') }}"
                                placeholder="9876543210 or +91 9876543210"
                                required
                                autocomplete="tel"
                                inputmode="tel"
                                maxlength="14"
                            >
                            <p class="mt-1.5 text-xs text-white/55">10-digit Indian mobile (first digit 6–9). You may enter <span class="text-white/70">+91</span> or spaces — we normalize it.</p>
                        </div>
                        <div class="mb-5">
                            <label class="block text-sm font-medium text-white/80 mb-2" for="password">Password *</label>
                            <div class="relative">
                                <input
                                    class="w-full rounded-xl border border-white/20 bg-white/10 px-4 py-3 pr-10 text-white placeholder:text-white/40 focus:border-indigo-400/60 focus:outline-none focus:ring-2 focus:ring-indigo-500/40"
                                    id="password"
                                    type="password"
                                    name="password"
                                    required
                                    autocomplete="new-password"
                                    placeholder="••••••••"
                                >
                                <button type="button" 
                                    onmousedown="document.getElementById('password').type='text'; this.querySelector('i').classList.replace('fa-eye', 'fa-eye-slash');" 
                                    onmouseup="document.getElementById('password').type='password'; this.querySelector('i').classList.replace('fa-eye-slash', 'fa-eye');" 
                                    onmouseleave="document.getElementById('password').type='password'; this.querySelector('i').classList.replace('fa-eye-slash', 'fa-eye');" 
                                    ontouchstart="document.getElementById('password').type='text'; this.querySelector('i').classList.replace('fa-eye', 'fa-eye-slash');" 
                                    ontouchend="document.getElementById('password').type='password'; this.querySelector('i').classList.replace('fa-eye-slash', 'fa-eye');" 
                                    class="absolute inset-y-0 right-0 flex items-center pr-3 text-white/50 hover:text-white focus:outline-none">
                                    <i class="fas fa-eye"></i>
                                </button>
                            </div>
                        </div>
                        <div class="mb-5">
                            <label class="block text-sm font-medium text-white/80 mb-2" for="password_confirmation">Confirm password *</label>
                            <div class="relative">
                                <input
                                    class="w-full rounded-xl border border-white/20 bg-white/10 px-4 py-3 pr-10 text-white placeholder:text-white/40 focus:border-indigo-400/60 focus:outline-none focus:ring-2 focus:ring-indigo-500/40"
                                    id="password_confirmation"
                                    type="password"
                                    name="password_confirmation"
                                    required
                                    autocomplete="new-password"
                                    placeholder="••••••••"
                                >
                                <button type="button" 
                                    onmousedown="document.getElementById('password_confirmation').type='text'; this.querySelector('i').classList.replace('fa-eye', 'fa-eye-slash');" 
                                    onmouseup="document.getElementById('password_confirmation').type='password'; this.querySelector('i').classList.replace('fa-eye-slash', 'fa-eye');" 
                                    onmouseleave="document.getElementById('password_confirmation').type='password'; this.querySelector('i').classList.replace('fa-eye-slash', 'fa-eye');" 
                                    ontouchstart="document.getElementById('password_confirmation').type='text'; this.querySelector('i').classList.replace('fa-eye', 'fa-eye-slash');" 
                                    ontouchend="document.getElementById('password_confirmation').type='password'; this.querySelector('i').classList.replace('fa-eye-slash', 'fa-eye');" 
                                    class="absolute inset-y-0 right-0 flex items-center pr-3 text-white/50 hover:text-white focus:outline-none">
                                    <i class="fas fa-eye"></i>
                                </button>
                            </div>
                        </div>
                        <div class="mb-6">
                            <label class="block text-sm font-medium text-white/80 mb-2" for="referral_code">Referral code (optional)</label>
                            <input
                                class="w-full rounded-xl border border-white/20 bg-white/10 px-4 py-3 text-white placeholder:text-white/40 focus:border-indigo-400/60 focus:outline-none focus:ring-2 focus:ring-indigo-500/40"
                                id="referral_code"
                                type="text"
                                name="referral_code"
                                value="{{ old('referral_code', request('ref')) }}"
                                placeholder="Friend's code"
                            >
                        </div>

                        <button type="submit" class="w-full flex items-center justify-center gap-2 rounded-lg bg-white px-4 py-3 text-base font-semibold text-indigo-700 shadow transition hover:bg-indigo-50">
                            <i class="fas fa-user-plus"></i>
                            Register
                        </button>

                        <p class="mt-6 text-center text-sm text-white/70">
                            Already have an account?
                            <a href="{{ route('client.login') }}" class="font-semibold text-white hover:underline">Login</a>
                        </p>
                    </form>
                </div>

                <p class="text-center mt-6 text-xs text-white/50">
                    <a href="{{ route('client.login') }}" class="text-indigo-200 hover:text-white">Sign in</a>
                    <span class="mx-2">·</span>
                    <a href="{{ route('public.home') }}" class="hover:text-white/80">Marketing site</a>
                    <span class="mx-2">·</span>
                    <a href="{{ route('public.privacy') }}" class="hover:text-white/70">Privacy</a>
                    <span class="mx-2">·</span>
                    <a href="{{ route('public.terms') }}" class="hover:text-white/70">Terms</a>
                </p>
            </div>
        </div>
    </div>
</body>
</html>
