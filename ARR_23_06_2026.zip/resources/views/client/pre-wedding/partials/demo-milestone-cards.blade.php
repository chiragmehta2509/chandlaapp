@foreach($milestones as $key => $m)
    @php
        $theme = $m['theme'] ?? '';
    @endphp
    <div class="bg-white rounded-2xl border border-slate-200/80 p-3 flex flex-col justify-between gap-3 shadow-sm relative overflow-hidden group">
        <span class="absolute top-2 right-2 z-10 inline-flex items-center gap-1 rounded-full bg-slate-900/75 text-white text-[8px] font-bold uppercase tracking-wider px-2 py-0.5 backdrop-blur-sm">
            <i class="fas fa-lock text-[7px]" aria-hidden="true"></i> Demo
        </span>
        
        <div class="text-center min-w-0">
            <h3 class="font-bold text-cb-navy text-xs truncate" title="{{ $m['label'] }}">{{ $m['label'] }}</h3>
            <p class="text-[10px] text-violet-600 font-medium mt-0.5 truncate">{{ $themeHints[$theme] ?? $theme }}</p>
        </div>

        <div class="relative rounded-xl overflow-hidden border border-slate-200 bg-slate-100 aspect-[9/16] w-full max-w-[140px] group mx-auto">
            <iframe
                src="{{ route('client.pre-wedding.thumbnail-preview', ['milestoneKey' => $key]) }}"
                title="{{ $m['label'] }} preview"
                loading="lazy"
                class="pointer-events-none absolute inset-0 h-full w-full border-0"
                referrerpolicy="no-referrer-when-downgrade"
            ></iframe>
        </div>
    </div>
@endforeach
