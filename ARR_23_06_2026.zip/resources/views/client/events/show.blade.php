@extends('layouts.client')

@section('title', $event->title)

@section('content')
<div class="mb-6">
    <a href="{{ route('client.events.index') }}" class="cb-link text-sm inline-flex items-center gap-2 mb-3">
        <i class="fas fa-arrow-left"></i>Back
    </a>
    <div class="flex flex-col gap-3 sm:flex-row sm:justify-between sm:items-start">
        <h1 class="cb-page-title pr-2">{{ $event->title }}</h1>
        <a href="{{ route('client.events.edit', $event->id) }}" class="cb-btn cb-btn-ghost w-full sm:w-auto shrink-0 justify-center border-slate-200">
            <i class="fas fa-edit"></i>Edit
        </a>
    </div>
</div>

<div class="grid grid-cols-1 lg:grid-cols-3 gap-6 items-start">
    <div class="lg:col-span-2">
        <div class="cb-card p-4">
            <h2 class="text-lg font-bold text-cb-navy mb-3">Event information</h2>
            <div class="space-y-2">
                {{-- Title --}}
                <div>
                    <label class="block text-sm font-medium text-gray-700">Title</label>
                    <p class="text-gray-900 font-semibold">{{ $event->title }}</p>
                </div>

                @if($event->description)
                <div>
                    <label class="block text-sm font-medium text-gray-700">Description</label>
                    <p class="text-gray-900 text-sm">{{ $event->description }}</p>
                </div>
                @endif

                {{-- Date / Time row --}}
                <div class="grid grid-cols-2 gap-3">
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Event Date</label>
                        <p class="text-gray-900 text-sm">{{ $event->event_date->format('M d, Y') }}</p>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Event Time</label>
                        <p class="text-gray-900 text-sm">{{ $event->event_time ? $event->event_time->format('h:i A') : '—' }}</p>
                    </div>
                </div>

                {{-- Venue --}}
                <div>
                    <label class="block text-sm font-medium text-gray-700">Venue</label>
                    <p class="text-gray-900 text-sm">{{ $event->venue ?: '—' }}</p>
                </div>

                {{-- Event Type / Status row --}}
                <div class="grid grid-cols-2 gap-3">
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Event Type</label>
                        <p class="text-gray-900 text-sm">
                            @if($event->eventType)
                                @if($event->eventType->color)
                                    <span class="inline-flex items-center">
                                        <span class="h-3 w-3 rounded-full mr-2" style="background-color: {{ $event->eventType->color }}"></span>
                                        {{ $event->eventType->name }}
                                    </span>
                                @else
                                    {{ $event->eventType->name }}
                                @endif
                            @else
                                —
                            @endif
                        </p>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Status</label>
                        <p class="mt-1">
                            @if($event->is_archived)
                                <span class="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-gray-100 text-gray-600">Archived</span>
                            @else
                                <span class="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-green-100 text-green-800">Active</span>
                            @endif
                        </p>
                    </div>
                </div>

                {{-- UPI / Direct GPay row --}}
                <div class="grid grid-cols-2 gap-3">
                    <div>
                        <label class="block text-sm font-medium text-gray-700">UPI ID</label>
                        <p class="text-gray-900 text-sm break-all">{{ $event->upi_id ?: '—' }}</p>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Direct GPay</label>
                        <p class="mt-1">
                            @if($event->hasDirectGpayQrUnlocked())
                                <span class="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-emerald-100 text-emerald-800"><i class="fas fa-check mr-1"></i>Unlocked</span>
                            @elseif($event->hasDirectGpayUnlockPending())
                                <span class="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-yellow-100 text-yellow-800"><i class="fas fa-clock mr-1"></i>Pending</span>
                            @else
                                <span class="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-gray-100 text-gray-600">Locked</span>
                            @endif
                        </p>
                    </div>
                </div>

                {{-- Totals row --}}
                <div class="grid grid-cols-2 gap-3">
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Total Chandlas</label>
                        <p class="text-gray-900 text-sm font-semibold">{{ $event->chandlas->count() }}</p>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Total Collected</label>
                        <p class="text-gray-900 text-sm font-semibold">₹{{ number_format($event->chandlas->sum('amount'), 2) }}</p>
                    </div>
                </div>

                {{-- Created --}}
                <div>
                    <label class="block text-sm font-medium text-gray-700">Created</label>
                    <p class="text-gray-500 text-sm">{{ $event->created_at->format('M d, Y h:i A') }}</p>
                </div>
            </div>
        </div>
    </div>

    <div>
        @php
            $chandlaCount = $event->chandlas->count();
            $freeLimit = min((int) ($event->free_entry_limit ?? 50), 50);
            $freeRemaining = max(0, $freeLimit - $chandlaCount);
            $plan = $event->pricing_plan ?? 'free';
            $extraEntries = max(0, $chandlaCount - $freeLimit);
            $perEntryPrice = $event->per_entry_price ?? 1;
            $unlimitedPrice = $event->unlimited_price ?? 500;
            $paygFee = $extraEntries * $perEntryPrice;
        @endphp
        <div class="cb-card p-4">
            <h3 class="text-lg font-bold text-gray-800 mb-3">Plan & Usage</h3>
            <div class="space-y-2">
                <div>
                    <p class="text-sm text-gray-600">Current Plan</p>
                    <p class="text-base font-semibold text-gray-900">
                        @if($plan === 'unlimited')
                            Unlimited (Per Event)
                        @elseif($plan === 'payg')
                            Pay-as-you-go
                        @else
                            Free
                        @endif
                    </p>
                </div>
                <div>
                    <p class="text-sm text-gray-600">Chandla Entries</p>
                    <p class="text-base font-semibold text-gray-900">{{ $chandlaCount }} used</p>
                </div>
                <div>
                    <p class="text-sm text-gray-600">Free Limit</p>
                    <p class="text-base font-semibold text-gray-900">{{ $freeLimit }} ({{ $freeRemaining }} remaining)</p>
                </div>
                @if($plan === 'payg')
                    <div>
                        <p class="text-sm text-gray-600">Extra Entries Fee</p>
                        <p class="text-base font-semibold text-gray-900">₹{{ number_format($paygFee, 2) }}</p>
                    </div>
                @elseif($plan === 'unlimited')
                    <div>
                        <p class="text-sm text-gray-600">Unlimited Plan Price</p>
                        <p class="text-base font-semibold text-gray-900">₹{{ number_format($unlimitedPrice, 2) }}</p>
                    </div>
                @endif
            </div>
            @if(isset($pendingPlanPayment))
                <div class="mt-4 bg-yellow-50 border border-yellow-200 text-yellow-800 px-4 py-3 rounded text-sm">
                    Unlimited plan payment submitted (Txn: {{ $pendingPlanPayment->transaction_id }}). Waiting for admin verification.
                </div>
            @endif
            <div class="mt-4 space-y-2">
                @if($plan === 'free')
                    <form method="POST" action="{{ route('client.events.plan.update', $event->id) }}">
                        @csrf
                        <input type="hidden" name="pricing_plan" value="payg">
                        <button type="submit" class="w-full cb-btn cb-btn-gold cb-btn--sm">
                            Upgrade to Pay-as-you-go (₹{{ number_format($perEntryPrice, 2) }}/entry)
                        </button>
                    </form>
                    @if(Auth::user()->free_event_credits > 0)
                        <form method="POST" action="{{ route('client.events.plan.update', $event->id) }}">
                            @csrf
                            <input type="hidden" name="pricing_plan" value="unlimited">
                            <input type="hidden" name="use_credit" value="1">
                            <button type="submit" class="w-full bg-teal-600 text-white px-4 py-2 rounded-lg hover:bg-teal-700 text-sm">
                                Use Free Event Credit ({{ Auth::user()->free_event_credits }} left)
                            </button>
                        </form>
                    @endif
                    <a href="{{ route('client.events.plan.payment', ['id' => $event->id, 'plan' => 'unlimited']) }}" class="block w-full text-center bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 text-sm">
                        Buy Unlimited for this Event (₹{{ number_format($unlimitedPrice, 2) }})
                    </a>
                @elseif($plan === 'payg')
                    @if(Auth::user()->free_event_credits > 0)
                        <form method="POST" action="{{ route('client.events.plan.update', $event->id) }}">
                            @csrf
                            <input type="hidden" name="pricing_plan" value="unlimited">
                            <input type="hidden" name="use_credit" value="1">
                            <button type="submit" class="w-full bg-teal-600 text-white px-4 py-2 rounded-lg hover:bg-teal-700 text-sm">
                                Use Free Event Credit ({{ Auth::user()->free_event_credits }} left)
                            </button>
                        </form>
                    @endif
                    <a href="{{ route('client.events.plan.payment', ['id' => $event->id, 'plan' => 'unlimited']) }}" class="block w-full text-center bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 text-sm">
                        Buy Unlimited for this Event (₹{{ number_format($unlimitedPrice, 2) }})
                    </a>
                @endif
            </div>
        </div>
    </div>
</div>

{{-- Chandlas table — full width --}}
<div class="cb-card p-4 sm:p-6 mt-6">
    <div class="flex flex-col gap-3 sm:gap-4 mb-4">
        <h2 class="text-lg font-bold text-cb-navy">Chandlas ({{ $event->chandlas->count() }})</h2>
        <div class="flex flex-wrap gap-2">
            <a href="{{ route('client.qrcode.show', $event->id) }}" class="cb-btn cb-btn--sm text-white bg-violet-600 hover:opacity-95 border-0">
                <i class="fas fa-qrcode"></i>QR
            </a>
            <a href="{{ route('client.events.chandlas.pdf', $event->id) }}" data-no-loader class="cb-btn cb-btn--sm text-white bg-slate-600 hover:opacity-95 border-0">
                <i class="fas fa-chart-bar"></i>Report
            </a>
            <a href="{{ route('client.cash-inventory.show', $event->id) }}" class="cb-btn cb-btn--sm text-white bg-amber-600 hover:opacity-95 border-0">
                <i class="fas fa-coins"></i>Cash
            </a>
            <a href="{{ route('client.gpay.upload', ['event_id' => $event->id]) }}" class="cb-btn cb-btn--sm text-white bg-emerald-600 hover:opacity-95 border-0">
                <i class="fas fa-camera"></i>GPay
            </a>
            <a href="{{ route('client.chandlas.create', ['event_id' => $event->id]) }}" class="cb-btn cb-btn-gold cb-btn--sm">
                <i class="fas fa-plus"></i>Add
            </a>
        </div>
    </div>
    @if($event->chandlas->count() > 0)
        {{-- Table search --}}
        <div class="mb-3">
            <div class="relative max-w-xs">
                <span class="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 text-sm" aria-hidden="true">
                    <i class="fas fa-search"></i>
                </span>
                <input
                    id="chandla-table-search"
                    type="search"
                    placeholder="Search chandlas…"
                    autocomplete="off"
                    class="cb-field w-full pl-9 pr-3 min-h-[2.25rem] text-sm"
                    oninput="chandlaTableFilter(this.value)"
                >
            </div>
        </div>
        <div class="overflow-x-auto rounded-lg border border-gray-200">
            <table id="chandla-table" class="w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Date</th>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Giver</th>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Category</th>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Payment</th>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Amount</th>
                    </tr>
                </thead>
                <tbody id="chandla-tbody" class="divide-y divide-gray-200">
                    @foreach($event->chandlas as $chandla)
                        <tr class="chandla-row hover:bg-slate-50/60 transition-colors {{ $chandla->payment_method === 'gpay' ? 'bg-teal-50/60' : '' }}">
                            <td class="px-4 py-3 whitespace-nowrap">
                                <div class="text-sm text-slate-800">{{ $chandla->received_date->format('M d, Y') }}</div>
                                <div class="text-xs text-slate-500">{{ $chandla->created_at->format('h:i A') }}</div>
                            </td>
                            <td class="px-4 py-3">
                                <div class="text-sm text-slate-800 font-semibold">{{ $chandla->giver_name }}</div>
                                @if($chandla->giver_phone)
                                    <div class="text-xs text-slate-500">{{ $chandla->giver_phone }}</div>
                                @endif
                            </td>
                            <td class="px-4 py-3">
                                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-sky-100 text-sky-800">
                                    {{ $chandla->category_label }}
                                </span>
                            </td>
                            <td class="px-4 py-3">
                                @if($chandla->category === 'gift')
                                    <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-violet-100 text-violet-800">
                                        {{ $chandla->gift_item_name ?: '—' }}
                                    </span>
                                @elseif($chandla->payment_method === 'gpay')
                                    <span class="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-teal-100 text-teal-800">
                                        <i class="fas fa-mobile-screen-button text-[0.6rem]"></i> GPay
                                    </span>
                                @else
                                    <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-emerald-100 text-emerald-800">
                                        {{ $chandla->payment_method_label }}
                                    </span>
                                @endif
                            </td>
                            <td class="px-4 py-3 whitespace-nowrap text-sm font-bold text-cb-navy">
                                @if($chandla->category === 'gift')
                                    @if($chandla->gift_received)
                                        <span class="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800">
                                            <i class="fas fa-check text-[0.6rem]"></i> Given
                                        </span>
                                    @else
                                        <span class="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-100 text-amber-800">
                                            <i class="fas fa-xmark text-[0.6rem]"></i> Not Given
                                        </span>
                                    @endif
                                @elseif($chandla->payment_method === 'gpay')
                                    <span class="text-teal-700">₹{{ number_format($chandla->amount, 2) }}</span>
                                @else
                                    ₹{{ number_format($chandla->amount, 2) }}
                                @endif
                            </td>
                        </tr>
                    @endforeach
                </tbody>
                <tfoot class="bg-gray-50">
                    <tr>
                        <td colspan="4" class="px-4 py-3 text-right text-sm font-bold text-gray-900">Total:</td>
                        <td class="px-4 py-3 text-sm font-bold text-gray-900">₹{{ number_format($event->chandlas->sum('amount'), 2) }}</td>
                    </tr>
                </tfoot>
            </table>
            <p id="chandla-no-results" class="hidden text-center text-sm text-slate-500 py-6">No results found.</p>
        </div>
        <script>
        function chandlaTableFilter(q) {
            var rows = document.querySelectorAll('#chandla-tbody .chandla-row');
            var term = q.toLowerCase().trim();
            var visible = 0;
            rows.forEach(function(row) {
                var text = row.textContent.toLowerCase();
                var show = term === '' || text.includes(term);
                row.style.display = show ? '' : 'none';
                if (show) visible++;
            });
            var noRes = document.getElementById('chandla-no-results');
            if (noRes) noRes.classList.toggle('hidden', visible > 0);
        }
        </script>
    @else
        <p class="text-gray-500 text-center py-4">No chandlas recorded yet</p>
    @endif
</div>  </div>
</div>
@endsection
