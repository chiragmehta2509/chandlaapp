@extends('layouts.client')

@section('title', ($packConfig['label'] ?? 'Pack') . ' — Checkout')

@section('content')
<div class="max-w-xl mx-auto py-4 sm:py-8">

    {{-- Header --}}
    <div class="mb-6">
        <a href="{{ route('client.plans') }}" class="inline-flex items-center gap-1.5 text-sm text-slate-500 hover:text-cb-navy transition-colors mb-4">
            <i class="fas fa-arrow-left text-xs"></i> Back to Plans
        </a>
        <h1 class="text-2xl font-bold text-cb-navy">Secure Checkout</h1>
        <p class="text-sm text-slate-500 mt-1">Your payment is processed by Razorpay — 100% secure.</p>
        @if($isTestMode)
            <div class="mt-3 inline-flex items-center gap-1.5 rounded-full bg-amber-100 border border-amber-200 text-amber-800 text-xs font-medium px-3 py-1.5">
                <i class="fas fa-flask"></i> Test Mode — no real money charged
            </div>
        @endif
    </div>

    {{-- Order summary card --}}
    <div class="rounded-2xl border border-slate-200/90 bg-white shadow-sm overflow-hidden mb-6">
        <div class="absolute-top-stripe h-1 bg-gradient-to-r from-amber-300 via-amber-400 to-amber-500 w-full"></div>
        <div class="p-6">
            <div class="flex items-start justify-between gap-4">
                <div>
                    <span class="inline-flex items-center rounded-full bg-amber-50 border border-amber-200 text-amber-800 text-xs font-semibold px-2.5 py-1 mb-3">
                        <i class="fas fa-box-open mr-1.5 text-[10px]"></i>Package
                    </span>
                    <h2 class="text-xl font-bold text-cb-navy">{{ $packConfig['label'] ?? ucfirst($configKey) }}</h2>
                </div>
                <div class="text-right shrink-0">
                    <div class="text-3xl font-extrabold text-cb-navy">₹{{ number_format($amountInr, 0) }}</div>
                    <div class="text-xs text-slate-500 mt-0.5">INR, one-time</div>
                </div>
            </div>

            {{-- Features list --}}
            @php
                $features = [
                    'celebration'      => ['Marriage invitation card','Pre-wedding photos card','Invitation video export'],
                    'ledger_duo'       => ['2 events on account','Unlimited chandla entries','Full PDF export'],
                    'family'           => ['2 events on account','Unlimited chandla + PDF','Up to 3 family editor accounts'],
                    'premium_bundle'   => ['Everything in all packs','Unlimited chandla + PDF','Family editors + invitation cards'],
                    'guest_pay_single' => ['1 event Direct GPay QR unlock','Unlimited chandla for that event','Full PDF export for that event'],
                ];
                $featureList = $features[$configKey] ?? [];
            @endphp
            @if($featureList)
                <ul class="mt-4 space-y-2 border-t border-slate-100 pt-4">
                    @foreach($featureList as $f)
                        <li class="flex items-center gap-2 text-sm text-slate-700">
                            <i class="fas fa-check-circle text-emerald-500 text-xs"></i>
                            {{ $f }}
                        </li>
                    @endforeach
                </ul>
            @endif
        </div>
    </div>

    {{-- Error message area --}}
    <div id="checkout-error" class="hidden mb-4 rounded-xl border border-rose-200 bg-rose-50 text-rose-900 px-4 py-3 text-sm">
        <i class="fas fa-exclamation-circle mr-1.5"></i>
        <span id="checkout-error-msg"></span>
        <button id="checkout-retry-btn" class="mt-3 w-full cb-btn cb-btn--navy cb-btn--sm justify-center hidden">
            <i class="fas fa-redo text-xs"></i> Try Again
        </button>
    </div>

    {{-- Pay button --}}
    <button
        id="pay-btn"
        type="button"
        class="cb-btn cb-btn-gold w-full justify-center text-base py-4 shadow-md ring-1 ring-amber-400/30 font-bold"
    >
        <i class="fas fa-lock text-sm" aria-hidden="true"></i>
        Pay ₹{{ number_format($amountInr, 0) }} with Razorpay
    </button>
    <p class="text-center text-xs text-slate-400 mt-3">
        <i class="fas fa-shield-halved text-slate-300 mr-1"></i>
        Payments are encrypted and processed securely by Razorpay
    </p>

</div>
@endsection

@push('scripts')
<script src="https://checkout.razorpay.com/v1/checkout.js"></script>
<script>
(function() {
    const payBtn     = document.getElementById('pay-btn');
    const errBox     = document.getElementById('checkout-error');
    const errMsg     = document.getElementById('checkout-error-msg');
    const retryBtn   = document.getElementById('checkout-retry-btn');

    const PACK        = @json($pack);
    const ORDER_URL   = @json(route('client.packs.order', $pack));
    const VERIFY_URL  = @json(route('client.packs.verify', $pack));
    const CSRF_TOKEN  = document.querySelector('meta[name="csrf-token"]')?.content || @json(csrf_token());

    function showError(msg, showRetry = true) {
        errMsg.textContent = msg;
        errBox.classList.remove('hidden');
        if (showRetry) {
            retryBtn.classList.remove('hidden');
        }
        payBtn.disabled = false;
        payBtn.innerHTML = '<i class="fas fa-lock text-sm"></i> Pay ₹{{ number_format($amountInr, 0) }} with Razorpay';
    }

    function hideError() {
        errBox.classList.add('hidden');
        retryBtn.classList.add('hidden');
    }

    async function startCheckout() {
        hideError();
        payBtn.disabled = true;
        payBtn.innerHTML = '<i class="fas fa-spinner fa-spin text-sm"></i> Creating order…';

        let orderData;
        try {
            const res = await fetch(ORDER_URL, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': CSRF_TOKEN,
                    'Accept': 'application/json',
                },
                body: JSON.stringify({}),
            });
            orderData = await res.json();
            if (!res.ok || orderData.error) {
                throw new Error(orderData.error || 'Could not create order.');
            }
        } catch (e) {
            showError(e.message || 'Network error. Please try again.');
            return;
        }

        const options = {
            key:         orderData.key_id,
            amount:      orderData.amount,
            currency:    orderData.currency || 'INR',
            order_id:    orderData.order_id,
            name:        'Chandla Book',
            description: '{{ $packConfig['label'] ?? $configKey }}',
            prefill: {
                name:    orderData.user_name  || '',
                email:   orderData.user_email || '',
                contact: orderData.user_phone || '',
            },
            theme: { color: '#92400E' },

            handler: async function(response) {
                payBtn.disabled = true;
                payBtn.innerHTML = '<i class="fas fa-spinner fa-spin text-sm"></i> Verifying…';
                try {
                    const vRes = await fetch(VERIFY_URL, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': CSRF_TOKEN,
                            'Accept': 'application/json',
                        },
                        body: JSON.stringify({
                            razorpay_order_id:   response.razorpay_order_id,
                            razorpay_payment_id: response.razorpay_payment_id,
                            razorpay_signature:  response.razorpay_signature,
                        }),
                    });
                    const vData = await vRes.json();
                    if (vData.success && vData.redirect_url) {
                        window.location.href = vData.redirect_url;
                    } else {
                        showError(vData.error || 'Verification failed. Contact support if money was debited.', true);
                    }
                } catch (e) {
                    showError('Network error during verification. Contact support with your payment ID: ' + response.razorpay_payment_id, false);
                }
            },

            modal: {
                ondismiss: function() {
                    payBtn.disabled = false;
                    payBtn.innerHTML = '<i class="fas fa-lock text-sm"></i> Pay ₹{{ number_format($amountInr, 0) }} with Razorpay';
                }
            },
        };

        const rzp = new Razorpay(options);
        rzp.on('payment.failed', function(resp) {
            showError('Payment failed: ' + (resp.error?.description || 'Unknown error'), true);
        });
        rzp.open();
    }

    payBtn.addEventListener('click', startCheckout);
    retryBtn.addEventListener('click', startCheckout);
})();
</script>
@endpush
