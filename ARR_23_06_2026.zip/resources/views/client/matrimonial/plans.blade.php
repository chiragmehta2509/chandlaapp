@extends('layouts.client')

@section('title', 'Matrimonial plans')

@section('content')
<div class="w-full min-w-0 max-w-4xl mx-auto">
    <a href="{{ route('client.matrimonial.index') }}" class="cb-link text-sm inline-flex items-center gap-2 mb-3 sm:mb-4 min-h-[44px] touch-manipulation">
        <i class="fa-solid fa-arrow-left" aria-hidden="true"></i> Find Partner
    </a>
    <h1 class="cb-page-title">Unlock full profiles</h1>
    <p class="cb-subtitle mt-1 break-words leading-relaxed">Complete payment on Razorpay. When it succeeds, your access is <strong>activated automatically</strong> (no admin step).</p>

    <div class="mt-4 rounded-lg border border-sky-200 bg-sky-50/90 px-3.5 sm:px-4 py-3 text-sm text-sky-950" role="status">
        <p class="font-medium">Use the same email and/or phone you use for Chandla Book.</p>
        <p class="mt-1 text-sky-900/90">Razorpay must send an email or phone that matches your account so we can attach the payment. If it doesn’t activate in a few minutes, check your Razorpay receipt email vs your profile.</p>
    </div>

    @if($active)
        <div class="mt-4 rounded-lg border border-emerald-200 bg-emerald-50 px-3.5 sm:px-4 py-3 text-sm text-emerald-900 break-words">
            You have an active plan until <strong>{{ $active->expiry_date->format('d M Y') }}</strong>.
        </div>
    @endif

    <h2 class="text-base sm:text-lg font-bold text-cb-navy mt-8 sm:mt-10 mb-3 sm:mb-4">Pay on Razorpay</h2>

    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-6">
        @foreach($plans as $key => $def)
            @php $link = $def['payment_link'] ?? null; @endphp
            <div class="cb-card p-4 sm:p-6 flex flex-col min-w-0">
                <h2 class="text-lg sm:text-xl font-bold text-cb-navy leading-tight break-words">{{ $def['label'] }}</h2>
                <p class="mt-2 text-2xl sm:text-3xl font-extrabold text-slate-900 tabular-nums">₹{{ number_format($def['price_inr'], 0) }}</p>
                <p class="text-sm text-slate-600 mt-1">Valid for <strong>{{ $def['months'] }}</strong> month(s) after activation</p>
                @if($link)
                    <a
                        href="{{ $link }}"
                        target="_blank"
                        rel="noopener noreferrer"
                        class="mt-auto pt-4 sm:pt-6 w-full min-h-[2.75rem] inline-flex items-center justify-center gap-2 cb-btn cb-btn-navy text-center touch-manipulation"
                    >Pay on Razorpay <i class="fa-solid fa-arrow-up-right-from-square text-sm opacity-90" aria-hidden="true"></i></a>
                @else
                    <p class="mt-4 text-sm text-amber-800">Payment link is not set for this plan (see <code class="text-xs">config/matrimonial.php</code> or <code class="text-xs">.env</code>).</p>
                @endif
            </div>
        @endforeach
    </div>

    <div class="mt-8 sm:mt-10 cb-card p-4 sm:p-5">
        <h3 class="text-sm font-bold text-cb-navy">For the site owner: webhook</h3>
        <p class="mt-2 text-xs sm:text-sm text-slate-600 break-words leading-relaxed">In <a href="https://dashboard.razorpay.com/" class="text-cb-navy underline" target="_blank" rel="noopener">Razorpay Dashboard</a> → <strong>Webhooks</strong>, add endpoint <code class="text-[0.7rem] sm:text-xs break-all block mt-1 p-1.5 bg-slate-100 rounded">{{ url('/webhooks/razorpay') }}</code> with a generated secret, set <code class="text-xs">RAZORPAY_WEBHOOK_SECRET</code> in <code class="text-xs">.env</code>, and enable events such as <strong>payment.captured</strong> (or your payment link success events).</p>
    </div>
</div>
@endsection
