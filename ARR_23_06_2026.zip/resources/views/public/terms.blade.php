@php
    $seoTitle = 'Terms of use — Chandla Book';
    $seoDesc = 'Terms of use for Chandla Book — acceptable use and limitations of the service.';
    $seoCanonical = url('/terms');
    $seoRobots = 'index, follow';
@endphp
@extends('layouts.public-guest')

@section('content')
<div class="max-w-3xl mx-auto pt-2 text-white/90 leading-relaxed">
    <h1 class="text-3xl font-bold text-white mb-6">Terms of use</h1>
    <p class="text-sm text-white/60 mb-8">Last updated {{ date('F j, Y') }}. Plain-language summary; replace or extend with counsel-approved terms for production.</p>

    <section class="space-y-6 text-sm sm:text-base">
        <div>
            <h2 class="text-lg font-semibold text-white mb-2">The service</h2>
            <p class="text-white/85">Chandla Book provides tools to manage event collections and related workflows &quot;as is&quot;. Features and pricing may evolve; material changes will be communicated where practical.</p>
        </div>
        <div>
            <h2 class="text-lg font-semibold text-white mb-2">Your responsibilities</h2>
            <p class="text-white/85">You are responsible for the accuracy of information you enter, compliance with applicable laws (including tax and financial reporting), and safekeeping of account credentials.</p>
        </div>
        <div>
            <h2 class="text-lg font-semibold text-white mb-2">Acceptable use</h2>
            <p class="text-white/85">Do not misuse the service for fraud, harassment, unlawful activity, or attempts to compromise security or other users’ data.</p>
        </div>
        <div>
            <h2 class="text-lg font-semibold text-white mb-2">Limitation of liability</h2>
            <p class="text-white/85">To the extent permitted by law, the service is provided without warranties of uninterrupted or error-free operation. Liability is limited as permitted by applicable law.</p>
        </div>
        <div>
            <h2 class="text-lg font-semibold text-white mb-2">Contact</h2>
            @php
                $termsMail = trim((string) config('chandlabook.support_email', ''));
                if ($termsMail === '') {
                    $termsMail = (string) config('mail.from.address', '');
                }
            @endphp
            @if ($termsMail !== '')
                <p class="text-white/85">Questions: <a href="mailto:{{ $termsMail }}" class="text-amber-200 underline hover:text-white">{{ $termsMail }}</a></p>
            @else
                <p class="text-white/85">Questions: configure support email in application settings.</p>
            @endif
        </div>
    </section>
</div>
@endsection
