@extends('layouts.client')

@section('title', 'Contact us')

@section('content')
@php
    $supportEmail = trim((string) config('chandlabook.support_email', ''));
    if ($supportEmail === '') {
        $supportEmail = trim((string) config('mail.from.address', ''));
    }
    $supportPhone = trim((string) config('chandlabook.support_phone', ''));
    $phoneDigits = $supportPhone !== '' ? preg_replace('/\D/', '', $supportPhone) : '';
    $telUri = $phoneDigits !== '' ? 'tel:+' . $phoneDigits : '#';
    $hasContact = $supportPhone !== '' || $supportEmail !== '';
@endphp

<div class="space-y-8 sm:space-y-10 pb-8">
    {{-- Hero --}}
    <div class="cb-card cb-card--hero relative overflow-hidden p-6 sm:p-8 lg:p-10">
        <div class="pointer-events-none absolute -right-20 -top-24 h-64 w-64 rounded-full bg-sky-400/20 blur-3xl" aria-hidden="true"></div>
        <div class="pointer-events-none absolute -bottom-28 -left-12 h-56 w-56 rounded-full bg-amber-400/18 blur-3xl" aria-hidden="true"></div>
        <div class="pointer-events-none absolute top-1/2 left-1/2 h-40 w-[110%] max-w-lg -translate-x-1/2 -translate-y-1/2 bg-[radial-gradient(ellipse_at_center,rgba(129,140,248,0.15),transparent_70%)]" aria-hidden="true"></div>

        <div class="relative grid gap-8 lg:grid-cols-[minmax(0,1fr)_auto] lg:items-end lg:gap-10">
            <div class="min-w-0">
                <p class="mb-4 inline-flex items-center gap-2 rounded-full bg-white/10 px-3 py-1.5 text-[0.65rem] font-bold uppercase tracking-[0.18em] text-indigo-100 ring-1 ring-white/15 backdrop-blur-sm sm:text-xs">
                    <i class="fa-solid fa-headset text-amber-300" aria-hidden="true"></i>
                    We're here to help
                </p>
                <h1 class="text-[1.65rem] font-bold leading-[1.15] tracking-tight text-white sm:text-3xl lg:text-4xl">
                    Talk to Chandla Book
                </h1>
                <p class="mt-4 max-w-xl text-sm leading-relaxed text-indigo-100/88 sm:text-base">
                    Billing, Razorpay packs, ledger questions, or invites — reach us on phone or email and we’ll point you in the right direction.
                </p>
                <div class="mt-6 flex flex-wrap gap-2.5">
                    <span class="inline-flex items-center gap-2 rounded-xl bg-emerald-500/15 px-3 py-2 text-xs font-semibold text-emerald-50 ring-1 ring-emerald-400/35 backdrop-blur-[2px]">
                        <i class="fa-solid fa-clock text-emerald-300" aria-hidden="true"></i>
                        Typical reply within a business day
                    </span>
                    <span class="inline-flex items-center gap-2 rounded-xl bg-white/10 px-3 py-2 text-xs font-semibold text-white/95 ring-1 ring-white/15 backdrop-blur-[2px]">
                        <i class="fa-solid fa-receipt text-amber-300" aria-hidden="true"></i>
                        Mention your account email when you write
                    </span>
                </div>
            </div>

            <div class="flex flex-col gap-3 sm:flex-row lg:flex-col lg:min-w-[13rem]">
                <a href="{{ route('client.faq') }}" class="cb-btn cb-btn--gold cb-btn--sm justify-center shadow-lg shadow-amber-900/30 lg:py-3">
                    <i class="fa-regular fa-circle-question" aria-hidden="true"></i>
                    Browse FAQ
                </a>
                <a href="{{ route('client.plans') }}" class="inline-flex items-center justify-center gap-2 rounded-xl border border-white/25 bg-white/5 px-4 py-2.5 text-sm font-semibold text-white backdrop-blur-sm transition hover:bg-white/12 focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-300/60">
                    <i class="fa-solid fa-tags text-amber-200/90" aria-hidden="true"></i>
                    Plans &amp; pricing
                </a>
            </div>
        </div>
    </div>

    {{-- Contact cards --}}
    <div class="relative">
        <div class="pointer-events-none absolute inset-x-0 -top-8 mx-auto h-40 max-w-xl rounded-full bg-gradient-to-r from-indigo-400/15 via-amber-300/12 to-teal-400/15 blur-3xl" aria-hidden="true"></div>
        <div class="relative mx-auto max-w-2xl rounded-[1.65rem] bg-gradient-to-br from-white via-indigo-50/35 to-amber-50/30 p-[1px] shadow-[0_28px_70px_-18px_rgba(26,54,70,0.22)] ring-1 ring-slate-200/70">
            <div class="rounded-[1.6rem] bg-white/90 backdrop-blur-md px-5 py-8 sm:px-8 sm:py-10">
                @if($hasContact)
                    <p class="text-center text-xs font-bold uppercase tracking-[0.2em] text-indigo-600 mb-2">Get in touch</p>
                    <p class="text-center text-[var(--cb-navy)] font-bold text-lg sm:text-xl mb-8">
                        Choose what works best for you
                    </p>

                    <ul class="grid gap-4 sm:gap-5">
                        @if($supportPhone !== '')
                            <li>
                                <a
                                    href="{{ $telUri }}"
                                    class="group flex gap-4 rounded-2xl border border-slate-200/90 bg-gradient-to-br from-white to-slate-50/80 p-4 sm:p-5 shadow-sm ring-1 ring-white transition hover:border-amber-200/80 hover:shadow-md hover:shadow-amber-900/5 focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--cb-gold)] focus-visible:ring-offset-2"
                                >
                                    <span class="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br from-amber-500 to-orange-600 text-white shadow-lg shadow-orange-900/25 transition group-hover:scale-[1.03]">
                                        <i class="fa-solid fa-phone text-xl" aria-hidden="true"></i>
                                    </span>
                                    <span class="min-w-0 flex-1 pt-0.5">
                                        <span class="block text-[0.65rem] font-bold uppercase tracking-wider text-slate-500 mb-1">Call us</span>
                                        <span class="block text-lg font-bold text-[var(--cb-navy)] tabular-nums leading-snug group-hover:text-[var(--cb-navy-soft)]">{{ $supportPhone }}</span>
                                        <span class="mt-1 inline-flex items-center gap-1 text-xs font-semibold text-emerald-700">
                                            <i class="fa-solid fa-phone-volume opacity-80" aria-hidden="true"></i>
                                            Tap to dial
                                        </span>
                                    </span>
                                    <span class="hidden sm:flex shrink-0 items-center text-slate-300 transition group-hover:text-amber-500">
                                        <i class="fa-solid fa-chevron-right" aria-hidden="true"></i>
                                    </span>
                                </a>
                            </li>
                        @endif
                        @if($supportEmail !== '')
                            <li>
                                <a
                                    href="mailto:{{ $supportEmail }}"
                                    class="group flex gap-4 rounded-2xl border border-slate-200/90 bg-gradient-to-br from-white to-indigo-50/40 p-4 sm:p-5 shadow-sm ring-1 ring-white transition hover:border-indigo-200/90 hover:shadow-md hover:shadow-indigo-900/5 focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--cb-navy)] focus-visible:ring-offset-2"
                                >
                                    <span class="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br from-[var(--cb-navy)] to-slate-800 text-white shadow-lg shadow-slate-900/25 transition group-hover:scale-[1.03]">
                                        <i class="fa-solid fa-envelope text-xl" aria-hidden="true"></i>
                                    </span>
                                    <span class="min-w-0 flex-1 pt-0.5">
                                        <span class="block text-[0.65rem] font-bold uppercase tracking-wider text-slate-500 mb-1">Email</span>
                                        <span class="block text-base sm:text-lg font-bold text-[var(--cb-navy)] break-all leading-snug">{{ $supportEmail }}</span>
                                        <span class="mt-1 inline-flex items-center gap-1 text-xs font-semibold text-indigo-700">
                                            <i class="fa-solid fa-paper-plane opacity-80" aria-hidden="true"></i>
                                            Opens your mail app
                                        </span>
                                    </span>
                                    <span class="hidden sm:flex shrink-0 items-center text-slate-300 transition group-hover:text-[var(--cb-navy)]">
                                        <i class="fa-solid fa-chevron-right" aria-hidden="true"></i>
                                    </span>
                                </a>
                            </li>
                        @endif
                    </ul>
                @else
                    <div class="rounded-2xl border border-amber-200 bg-gradient-to-br from-amber-50 to-orange-50/50 px-4 py-6 text-center">
                        <span class="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-xl bg-amber-100 text-amber-700">
                            <i class="fa-solid fa-screwdriver-wrench text-lg" aria-hidden="true"></i>
                        </span>
                        <p class="font-semibold text-amber-950">Contact details not configured</p>
                        <p class="mt-2 text-sm text-amber-900/85 leading-relaxed max-w-md mx-auto">
                            Add <span class="font-mono text-xs bg-white/70 px-1.5 py-0.5 rounded">CHANDLABOOK_SUPPORT_EMAIL</span> and/or phone via <span class="font-mono text-xs bg-white/70 px-1.5 py-0.5 rounded">CHANDLABOOK_SUPPORT_PHONE</span> in your environment (see <span class="font-mono text-xs">config/chandlabook.php</span>).
                        </p>
                    </div>
                @endif

                <div class="mt-8 rounded-xl border border-slate-100 bg-slate-50/80 px-4 py-4 sm:px-5">
                    <p class="text-xs font-semibold text-slate-700 mb-2">Before you reach out</p>
                    <p class="text-sm text-slate-600 leading-relaxed">
                        Many answers live in our <a href="{{ route('client.faq') }}" class="font-semibold text-[var(--cb-navy)] underline decoration-slate-300 underline-offset-2 hover:decoration-[var(--cb-gold)]">FAQ</a>
                        (packs, Direct GPay, referrals). For upgrades and checkout amounts, see
                        <a href="{{ route('client.plans') }}" class="font-semibold text-[var(--cb-navy)] underline decoration-slate-300 underline-offset-2 hover:decoration-[var(--cb-gold)]">Plans &amp; pricing</a>.
                    </p>
                </div>
            </div>
        </div>
    </div>

    {{-- Footer hint --}}
    <div class="cb-card relative overflow-hidden border border-[var(--cb-border)] p-5 sm:p-6 lg:flex lg:items-center lg:justify-between lg:gap-8">
        <div class="pointer-events-none absolute -right-12 top-0 h-32 w-32 rounded-full bg-indigo-500/10 blur-2xl" aria-hidden="true"></div>
        <div class="relative min-w-0">
            <p class="text-base font-bold text-[var(--cb-navy)]">Back to your dashboard</p>
            <p class="mt-1 text-sm text-slate-600">Continue managing events, ledger, and invitations.</p>
        </div>
        <div class="relative mt-4 flex flex-wrap gap-2 lg:mt-0 lg:shrink-0">
            <a href="{{ route('client.dashboard') }}" class="cb-btn cb-btn--navy cb-btn--sm">
                <i class="fa-solid fa-house" aria-hidden="true"></i>
                Home
            </a>
            <a href="{{ route('client.events.index') }}" class="cb-btn cb-btn--ghost cb-btn--sm">
                Events
            </a>
        </div>
    </div>
</div>
@endsection
