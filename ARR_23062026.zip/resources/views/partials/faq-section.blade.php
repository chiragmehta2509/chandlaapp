@php
    $faqDirectGpayHref = $faqDirectGpayHref ?? '#direct-gpay';
    $faqReferHref = $faqReferHref ?? '#refer';
@endphp
<section id="faq" class="bg-slate-50 text-slate-900 scroll-mt-20 {{ ($faqFlush ?? false) ? 'border-t border-slate-200/80' : 'border border-slate-200/80 rounded-xl' }}" aria-labelledby="faq-heading">
    <div class="max-w-3xl mx-auto px-6 py-12">
        <h2 id="faq-heading" class="text-2xl font-bold mb-6">Common questions</h2>
        <dl class="space-y-4">
            <div class="bg-white border border-slate-200 rounded-xl p-5">
                <dt class="font-semibold text-slate-900">What’s in the ₹{{ number_format((float) config('landing.celebration_pack_inr', 300), 0) }} celebration pack?</dt>
                <dd class="mt-2 text-slate-600 text-sm leading-relaxed">It bundles <strong>10 marriage invitation layouts</strong> (save PNG / print), <strong>one</strong> <strong>video</strong> export for sharing, and the <strong>pre‑wedding</strong> countdown studio with downloadable cards per milestone. It does <strong>not</strong> by itself raise your chandla entry cap past the free <strong>50</strong> — upgrade the ledger separately if you need more gift entries.</dd>
            </div>
            <div class="bg-white border border-slate-200 rounded-xl p-5">
                <dt class="font-semibold text-slate-900">What is the Guest pay pack (₹{{ number_format((float) config('landing.guest_pay_single_inr', 400), 0) }})?</dt>
                <dd class="mt-2 text-slate-600 text-sm leading-relaxed">One payment adds a <strong>credit</strong> on your account. In the client app, open <strong>Unlock Direct QR</strong> for <strong>one</strong> event and <strong>apply the credit</strong>. That event gets <strong>Direct GPay</strong> (your UPI / QR, pay‑to‑you link for <strong>any amount</strong>), <strong>unlimited chandla</strong> rows for that event only, and <strong>full event PDF</strong>. It does <strong>not</strong> include invitation / pre‑wedding studio.</dd>
            </div>
            <div class="bg-white border border-slate-200 rounded-xl p-5">
                <dt class="font-semibold text-slate-900">What is the Host Duo pack (₹{{ number_format((float) config('landing.host_duo_pack_inr', 500), 0) }})?</dt>
                <dd class="mt-2 text-slate-600 text-sm leading-relaxed">It unlocks <strong>two events</strong> on your account with <strong>unlimited chandla</strong> entries and normal PDF export — <strong>without</strong> the marriage invitation, video, or pre‑wedding studio (those stay in the Celebration / Complete host packs).</dd>
            </div>
            <div class="bg-white border border-slate-200 rounded-xl p-5">
                <dt class="font-semibold text-slate-900">What does the Complete host pack (₹{{ number_format((float) config('landing.premium_bundle_inr', 700), 0) }}) include?</dt>
                <dd class="mt-2 text-slate-600 text-sm leading-relaxed">It includes <strong>everything in the Celebration pack</strong>, <strong>3 events</strong> on your account, <strong>account-wide unlimited chandla</strong> (same class as Host Duo for the ledger), and <strong>full event PDF</strong> workflows. You can still buy <strong>Guest pay</strong> credits or use the in-app Direct GPay unlock (currently ₹{{ number_format((float) config('services.direct_gpay_unlock.amount', 400), 0) }} per event) when you need pay-to-you QR on extra events.</dd>
            </div>
            <div class="bg-white border border-slate-200 rounded-xl p-5">
                <dt class="font-semibold text-slate-900">How does “Direct GPay / pay to you” work?</dt>
                <dd class="mt-2 text-slate-600 text-sm leading-relaxed">For an event you add <strong>your UPI or an uploaded static QR</strong>. We generate a <strong>dedicated scannable pay QR and link</strong> so <strong>guests pay you directly</strong> (they choose the amount), and the app records the line in your ledger. Unlock either with the <strong>in‑app per‑event fee</strong> or a <strong>₹{{ number_format((float) config('landing.guest_pay_single_inr', 400), 0) }} Guest pay pack</strong> credit — see the <a href="{{ $faqDirectGpayHref }}" class="text-indigo-600 font-medium hover:underline">Direct GPay section on the plans page</a>.</dd>
            </div>
            <div class="bg-white border border-slate-200 rounded-xl p-5">
                <dt class="font-semibold text-slate-900">When do I get a referral reward?</dt>
                <dd class="mt-2 text-slate-600 text-sm leading-relaxed">When your referred contact <strong>completes a qualifying payment</strong> in the app, you can receive a <strong>free event with unlimited entries + full PDF</strong> — as described in the <a href="{{ $faqReferHref }}" class="text-indigo-600 font-medium hover:underline">Refer &amp; earn</a> section on our website.</dd>
            </div>
        </dl>
    </div>
</section>
