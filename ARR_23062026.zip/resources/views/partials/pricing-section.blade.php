<section id="pricing" class="relative w-full min-w-0 max-w-full {{ ($pricingNestClient ?? false) ? 'bg-transparent' : 'bg-gradient-to-b from-slate-100 via-slate-50 to-white' }} text-slate-900 scroll-mt-24 {{ ($pricingInset ?? false) ? 'overflow-hidden rounded-xl border border-slate-200/80 shadow-sm' : (($pricingNestClient ?? false) ? '' : 'overflow-hidden') }}">
    <div class="absolute inset-0 bg-[radial-gradient(ellipse_80%_50%_at_50%_-20%,rgba(99,102,241,0.12),transparent)] pointer-events-none {{ ($pricingInset ?? false) ? 'rounded-xl' : '' }}" aria-hidden="true"></div>
    <div class="max-w-6xl mx-auto w-full min-w-0 px-4 sm:px-6 py-14 relative {{ trim($pricingInnerClass ?? '') }}">
        <div class="text-center max-w-2xl mx-auto mb-10">
            <p class="text-xs font-bold uppercase tracking-[0.2em] text-indigo-600 mb-3">Pricing</p>
            <h2 class="text-3xl md:text-4xl font-bold text-slate-900 tracking-tight">Plans &amp; what’s included</h2>
            <p class="text-slate-600 mt-4 text-base leading-relaxed">Start <strong>free</strong>, then upgrade on Razorpay — <span class="text-indigo-700 font-semibold">Celebration</span> for social graphics, <span class="text-amber-800 font-semibold">Guest pay (one event)</span> for Direct UPI/QR + unlimited chandla + PDF on a single event, <span class="text-sky-700 font-semibold">Host Duo</span> for two full ledgers, <span class="text-violet-700 font-semibold">Family</span> to add 3 co-managers, or <span class="text-emerald-700 font-semibold">Complete host</span> for everything in one.</p>
        </div>

        {{-- Comparison matrix: min-w-0 + inner overflow-x-auto keeps wide grid from stretching the whole page --}}
        <div class="mt-2 w-full min-w-0 max-w-full rounded-2xl bg-white/90 backdrop-blur-sm shadow-xl shadow-slate-200/60 ring-1 ring-slate-200/80 {{ ($pricingNestClient ?? false) ? 'shadow-[0_22px_56px_-18px_rgba(26,54,70,0.16)] ring-indigo-100/70' : '' }}">
            <div
                class="w-full min-w-0 max-w-full overflow-x-auto overscroll-x-contain rounded-2xl touch-pan-x [-webkit-overflow-scrolling:touch]"
                role="region"
                aria-label="Compare plans side by side"
            >
                <div class="min-w-[1320px] grid grid-cols-[minmax(200px,1.1fr)_repeat(6,minmax(0,1fr))] text-sm">
                    {{-- Header row --}}
                    <div class="p-4 md:p-5 bg-slate-50/90 border-b border-slate-200/80 flex items-end">
                        <span class="font-semibold text-slate-700 flex items-center gap-2">
                            <span class="flex h-8 w-8 items-center justify-center rounded-lg bg-slate-200/80 text-slate-600"><i class="fas fa-table-list text-xs" aria-hidden="true"></i></span>
                            Compare
                        </span>
                    </div>
                    <div class="relative p-4 md:p-5 text-center border-b border-slate-200/80 bg-gradient-to-b from-slate-100 to-slate-50">
                        <div class="text-xs font-semibold uppercase tracking-wide text-slate-500 mb-1">Starter</div>
                        <div class="text-lg font-bold text-slate-900">Free</div>
                        <div class="text-2xl font-black text-slate-800 mt-1 tabular-nums">₹0</div>
                    </div>
                    <div class="relative p-4 md:p-5 text-center border-b border-l border-slate-200/80 bg-gradient-to-b from-indigo-500 to-indigo-600 text-white shadow-inner">
                        <div class="text-xs font-semibold uppercase tracking-wide text-indigo-100 mb-1">Social</div>
                        <div class="text-lg font-bold leading-tight">Celebration pack</div>
                        <div class="text-2xl font-black mt-1 tabular-nums">₹{{ number_format((float) config('landing.celebration_pack_inr', 300), 0) }}</div>
                    </div>
                    <div class="relative p-4 md:p-5 text-center border-b border-l border-slate-200/80 bg-gradient-to-b from-amber-500 to-orange-600 text-white shadow-inner">
                        <div class="text-xs font-semibold uppercase tracking-wide text-amber-100 mb-1">One event</div>
                        <div class="text-lg font-bold leading-tight">Guest pay</div>
                        <div class="text-2xl font-black mt-1 tabular-nums">₹{{ number_format((float) config('landing.guest_pay_single_inr', 400), 0) }}</div>
                    </div>
                    <div class="relative p-4 md:p-5 text-center border-b border-l border-slate-200/80 bg-gradient-to-b from-sky-500 to-cyan-600 text-white shadow-inner">
                        <div class="text-xs font-semibold uppercase tracking-wide text-sky-100 mb-1">Ledger</div>
                        <div class="text-lg font-bold leading-tight">Host Duo pack</div>
                        <div class="text-2xl font-black mt-1 tabular-nums">₹{{ number_format((float) config('landing.host_duo_pack_inr', 500), 0) }}</div>
                    </div>
                    <div class="relative p-4 md:p-5 pt-8 md:pt-9 text-center border-b border-l border-slate-200/80 bg-gradient-to-b from-violet-500 to-fuchsia-600 text-white shadow-inner">
                        <span class="absolute top-2 left-1/2 -translate-x-1/2 whitespace-nowrap rounded-full bg-amber-400 text-amber-950 text-[0.65rem] font-bold px-2.5 py-0.5 shadow-md z-10">Most popular</span>
                        <div class="text-xs font-semibold uppercase tracking-wide text-violet-100 mb-1">Family</div>
                        <div class="text-lg font-bold leading-tight">Family pack</div>
                        <div class="text-2xl font-black mt-1 tabular-nums">₹{{ number_format((float) config('packs.family.amount_inr', 600), 0) }}</div>
                    </div>
                    <div class="relative p-4 md:p-5 pt-8 md:pt-9 text-center border-b border-l border-slate-200/80 bg-gradient-to-b from-emerald-500 to-teal-600 text-white shadow-inner">
                        <span class="absolute top-2 right-3 rounded-full bg-white/25 text-white text-[0.65rem] font-bold px-2 py-0.5 backdrop-blur-sm z-10 border border-white/20">Best value</span>
                        <div class="text-xs font-semibold uppercase tracking-wide text-emerald-100 mb-1">All-in-one</div>
                        <div class="text-lg font-bold leading-tight">Complete host pack</div>
                        <div class="text-2xl font-black mt-1 tabular-nums">₹{{ number_format((float) config('landing.premium_bundle_inr', 700), 0) }}</div>
                    </div>

                    {{-- Row: Wedding suite --}}
                    <div class="p-4 md:px-5 md:py-4 border-b border-slate-100 bg-white font-medium text-slate-800 flex items-center gap-2">
                        <span class="flex h-7 w-7 shrink-0 items-center justify-center rounded-md bg-rose-100 text-rose-600 text-xs"><i class="fas fa-heart" aria-hidden="true"></i></span>
                        <span>Wedding suite <span class="text-slate-500 font-normal">· invites, video, pre‑wedding</span></span>
                    </div>
                    <div class="p-4 md:py-4 border-b border-slate-100 bg-slate-50/50 text-center text-slate-500 flex items-center justify-center">Demo only</div>
                    <div class="p-4 md:py-4 border-b border-l border-slate-100 bg-indigo-50/50 text-center text-indigo-950 font-medium flex flex-col items-center justify-center gap-0.5 px-2 py-3 leading-tight">
                        <span><strong class="text-base">10</strong> styles</span>
                        <span class="text-xs text-indigo-900/90"><strong>1</strong> video · PNGs</span>
                    </div>
                    <div class="p-4 md:py-4 border-b border-l border-slate-100 bg-amber-50/50 text-center text-slate-400 flex items-center justify-center"><span class="inline-flex h-8 w-8 items-center justify-center rounded-full bg-slate-200/60 text-slate-500 text-xs">—</span></div>
                    <div class="p-4 md:py-4 border-b border-l border-slate-100 bg-sky-50/40 text-center text-slate-400 flex items-center justify-center"><span class="inline-flex h-8 w-8 items-center justify-center rounded-full bg-slate-200/60 text-slate-500 text-xs">—</span></div>
                    <div class="p-4 md:py-4 border-b border-l border-slate-100 bg-violet-50/40 text-center text-slate-400 flex items-center justify-center"><span class="inline-flex h-8 w-8 items-center justify-center rounded-full bg-slate-200/60 text-slate-500 text-xs">—</span></div>
                    <div class="p-4 md:py-4 border-b border-l border-slate-100 bg-emerald-50/40 text-center text-emerald-950 font-medium flex flex-col items-center justify-center gap-0.5 px-2 py-3 leading-tight">
                        <span><strong class="text-base">10</strong> styles</span>
                        <span class="text-xs text-emerald-900/90"><strong>1</strong> video · PNGs</span>
                    </div>

                    {{-- Row: Events --}}
                    <div class="p-4 md:px-5 md:py-4 border-b border-slate-100 bg-white font-medium text-slate-800 flex items-center gap-2">
                        <span class="flex h-7 w-7 shrink-0 items-center justify-center rounded-md bg-violet-100 text-violet-600 text-xs"><i class="fas fa-calendar-check" aria-hidden="true"></i></span>
                        Events on your account
                    </div>
                    <div class="p-4 md:py-4 border-b border-slate-100 bg-slate-50/50 text-center flex items-center justify-center"><span class="inline-flex items-center justify-center rounded-lg bg-white px-3 py-1 font-semibold text-slate-800 shadow-sm ring-1 ring-slate-200/80">1</span></div>
                    <div class="p-4 md:py-4 border-b border-l border-slate-100 bg-indigo-50/50 text-center text-slate-600 flex flex-col items-center justify-center gap-0.5 text-sm px-2">
                        <span class="font-semibold text-slate-800">1</span>
                        <span class="text-xs text-slate-500 leading-tight">ledger as free</span>
                    </div>
                    <div class="p-4 md:py-4 border-b border-l border-slate-100 bg-amber-50/50 text-center text-amber-950 text-sm font-medium flex flex-col items-center justify-center gap-0.5 px-2">
                        <span>1 event</span>
                        <span class="text-xs font-normal text-amber-800/85 leading-tight">pack credit</span>
                    </div>
                    <div class="p-4 md:py-4 border-b border-l border-slate-100 bg-sky-50/40 text-center flex items-center justify-center"><span class="inline-flex items-center justify-center rounded-lg bg-sky-600 text-white px-3 py-1 font-bold shadow-md shadow-sky-600/25">2 · full</span></div>
                    <div class="p-4 md:py-4 border-b border-l border-slate-100 bg-violet-50/40 text-center flex items-center justify-center"><span class="inline-flex items-center justify-center rounded-lg bg-violet-600 text-white px-3 py-1 font-bold shadow-md shadow-violet-600/25">2 · full</span></div>
                    <div class="p-4 md:py-4 border-b border-l border-slate-100 bg-emerald-50/40 text-center flex items-center justify-center"><span class="inline-flex items-center justify-center rounded-lg bg-emerald-600 text-white px-3 py-1 font-bold shadow-md shadow-emerald-600/25">3 events</span></div>

                    {{-- Row: Chandla --}}
                    <div class="p-4 md:px-5 md:py-4 border-b border-slate-100 bg-white font-medium text-slate-800 flex items-center gap-2">
                        <span class="flex h-7 w-7 shrink-0 items-center justify-center rounded-md bg-amber-100 text-amber-700 text-xs"><i class="fas fa-book" aria-hidden="true"></i></span>
                        Chandla / ledger entries
                    </div>
                    <div class="p-4 md:py-4 border-b border-slate-100 bg-slate-50/50 text-center flex items-center justify-center">Max <strong>50</strong> total</div>
                    <div class="p-4 md:py-4 border-b border-l border-slate-100 bg-indigo-50/50 text-center text-slate-600 text-sm flex items-center justify-center">Free-tier cap</div>
                    <div class="p-4 md:py-4 border-b border-l border-slate-100 bg-amber-50/50 text-center flex items-center justify-center"><span class="font-bold text-amber-900">Unlimited · 1 event</span></div>
                    <div class="p-4 md:py-4 border-b border-l border-slate-100 bg-sky-50/40 text-center flex items-center justify-center"><span class="font-bold text-sky-700">Unlimited</span></div>
                    <div class="p-4 md:py-4 border-b border-l border-slate-100 bg-violet-50/40 text-center flex items-center justify-center"><span class="font-bold text-violet-700">Unlimited</span></div>
                    <div class="p-4 md:py-4 border-b border-l border-slate-100 bg-emerald-50/40 text-center flex items-center justify-center"><span class="font-bold text-emerald-700">Unlimited</span></div>

                    {{-- Row: Family members --}}
                    <div class="p-4 md:px-5 md:py-4 border-b border-slate-100 bg-white font-medium text-slate-800 flex items-center gap-2">
                        <span class="flex h-7 w-7 shrink-0 items-center justify-center rounded-md bg-violet-100 text-violet-600 text-xs"><i class="fas fa-people-group" aria-hidden="true"></i></span>
                        <span>Family members <span class="text-slate-500 font-normal">· sub-accounts on your data</span></span>
                    </div>
                    <div class="p-4 md:py-4 border-b border-slate-100 bg-slate-50/50 text-center text-slate-600 text-sm flex flex-col items-center justify-center gap-0.5 px-2 leading-tight">
                        <span class="font-semibold text-slate-800">3</span>
                        <span class="text-xs text-slate-500">viewers</span>
                    </div>
                    <div class="p-4 md:py-4 border-b border-l border-slate-100 bg-indigo-50/50 text-center text-slate-700 text-sm flex flex-col items-center justify-center gap-0.5 px-2 leading-tight">
                        <span class="font-semibold text-indigo-900">3</span>
                        <span class="text-xs text-indigo-800/80">viewers</span>
                    </div>
                    <div class="p-4 md:py-4 border-b border-l border-slate-100 bg-amber-50/50 text-center text-amber-900 text-sm flex flex-col items-center justify-center gap-0.5 px-2 leading-tight">
                        <span class="font-semibold">3</span>
                        <span class="text-xs text-amber-800/80">viewers</span>
                    </div>
                    <div class="p-4 md:py-4 border-b border-l border-slate-100 bg-sky-50/40 text-center text-sky-900 text-sm flex flex-col items-center justify-center gap-0.5 px-2 leading-tight">
                        <span class="font-semibold">3</span>
                        <span class="text-xs text-sky-800/80">viewers</span>
                    </div>
                    <div class="p-4 md:py-4 border-b border-l border-slate-100 bg-violet-50/40 text-center flex items-center justify-center"><span class="inline-flex items-center justify-center rounded-lg bg-violet-600 text-white px-3 py-1 font-bold shadow-md shadow-violet-600/25">3 editors</span></div>
                    <div class="p-4 md:py-4 border-b border-l border-slate-100 bg-emerald-50/40 text-center flex items-center justify-center"><span class="inline-flex items-center justify-center rounded-lg bg-emerald-600 text-white px-3 py-1 font-bold shadow-md shadow-emerald-600/25">3 editors</span></div>

                    {{-- Row: PDF --}}
                    <div class="p-4 md:px-5 md:py-4 bg-white font-medium text-slate-800 flex items-start gap-2 min-w-0">
                        <span class="flex h-7 w-7 shrink-0 items-center justify-center rounded-md bg-emerald-100 text-emerald-600 text-xs"><i class="fas fa-file-pdf" aria-hidden="true"></i></span>
                        <span class="min-w-0 leading-snug">Full event <strong>PDF</strong><span class="text-slate-600 font-normal"> export &amp; email</span></span>
                    </div>
                    <div class="p-4 md:py-4 bg-slate-50/50 text-center text-slate-600 text-sm flex items-center justify-center">Within free limits</div>
                    <div class="p-4 md:py-4 border-l border-slate-100 bg-indigo-50/50 text-center text-slate-500 text-sm flex items-center justify-center">Per tier</div>
                    <div class="p-4 md:py-4 border-l border-slate-100 bg-amber-50/50 text-center flex items-center justify-center"><span class="inline-flex h-9 w-9 items-center justify-center rounded-full bg-emerald-500 text-white shadow-lg shadow-emerald-500/30"><i class="fas fa-check text-sm" aria-hidden="true"></i></span></div>
                    <div class="p-4 md:py-4 border-l border-slate-100 bg-sky-50/40 text-center flex items-center justify-center"><span class="inline-flex h-9 w-9 items-center justify-center rounded-full bg-emerald-500 text-white shadow-lg shadow-emerald-500/30"><i class="fas fa-check text-sm" aria-hidden="true"></i></span></div>
                    <div class="p-4 md:py-4 border-l border-slate-100 bg-violet-50/40 text-center flex items-center justify-center"><span class="inline-flex h-9 w-9 items-center justify-center rounded-full bg-emerald-500 text-white shadow-lg shadow-emerald-500/30"><i class="fas fa-check text-sm" aria-hidden="true"></i></span></div>
                    <div class="p-4 md:py-4 border-l border-slate-100 bg-emerald-50/40 text-center flex items-center justify-center"><span class="inline-flex h-9 w-9 items-center justify-center rounded-full bg-emerald-500 text-white shadow-lg shadow-emerald-500/30"><i class="fas fa-check text-sm" aria-hidden="true"></i></span></div>
                </div>
            </div>
        </div>

        <p class="mt-2 text-center text-[0.65rem] font-medium uppercase tracking-wider text-slate-400 sm:hidden">Swipe sideways to compare all columns</p>

        <p class="text-center text-sm text-slate-600 mt-6 max-w-2xl mx-auto leading-relaxed"><strong class="text-slate-800">Razorpay checkout:</strong> use the <strong>same email or phone</strong> as your Chandla Book account so packs and credits unlock automatically after payment.</p>

        <div class="text-center mt-12 mb-8">
            <p class="text-xs font-bold uppercase tracking-[0.22em] text-indigo-600 mb-2">Pick your pack</p>
            <h3 class="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight">Choose what fits your celebration</h3>
            <p class="text-sm text-slate-500 mt-2">All plans charged once on Razorpay — no subscriptions.</p>
        </div>

        @php
            $celebPrice = (float) config('landing.celebration_pack_inr', 300);
            $guestPrice = (float) config('landing.guest_pay_single_inr', 400);
            $hostDuoPrice = (float) config('landing.host_duo_pack_inr', 500);
            $familyPrice = (float) config('packs.family.amount_inr', 600);
            $bundlePrice = (float) config('landing.premium_bundle_inr', 700);

            $user = Auth::user();
            $planLevel = $user ? $user->planLevel() : 0;
        @endphp

        <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5 sm:gap-6 items-stretch">
            {{-- Free plan --}}
            <div class="group relative flex flex-col bg-white rounded-2xl border border-slate-200/90 p-6 sm:p-7 shadow-sm hover:shadow-lg hover:border-slate-300 transition-all duration-300">
                <div class="flex items-center gap-3 mb-5">
                    <div class="h-11 w-11 rounded-xl bg-slate-100 text-slate-600 flex items-center justify-center shrink-0">
                        <i class="fas fa-seedling text-lg" aria-hidden="true"></i>
                    </div>
                    <div class="min-w-0">
                        <p class="text-[0.7rem] font-bold uppercase tracking-wider text-slate-500">Forever free</p>
                        <h3 class="text-lg font-bold text-slate-900 leading-tight">Free plan</h3>
                    </div>
                </div>
                <div class="flex items-baseline gap-1.5 mb-4">
                    <span class="text-4xl font-black text-slate-900 tabular-nums">₹0</span>
                    <span class="text-sm text-slate-400 font-medium">/ forever</span>
                </div>
                <p class="text-slate-600 text-sm leading-relaxed mb-5"><strong>1 event</strong> and up to <strong>50 chandla entries</strong> in total. Use core ledger, inventory, and PDF export.</p>
                <ul class="space-y-2.5 text-slate-700 text-sm flex-1">
                    <li class="flex gap-2.5"><i class="fas fa-check text-emerald-500 mt-0.5 shrink-0" aria-hidden="true"></i><span>1 event · 50-entry account cap</span></li>
                    <li class="flex gap-2.5"><i class="fas fa-check text-emerald-500 mt-0.5 shrink-0" aria-hidden="true"></i><span>Reports &amp; export on free tier</span></li>
                    <li class="flex gap-2.5"><i class="fas fa-check text-emerald-500 mt-0.5 shrink-0" aria-hidden="true"></i><span>Cash &amp; cover ledger basics</span></li>
                    <li class="flex gap-2.5"><i class="fas fa-check text-emerald-500 mt-0.5 shrink-0" aria-hidden="true"></i><span><strong>3 family viewers</strong> — read-only</span></li>
                </ul>
                @auth
                    <a href="{{ route('client.dashboard') }}" class="mt-6 inline-flex items-center justify-center gap-2 w-full px-4 py-3 rounded-xl border border-slate-300 text-slate-800 font-semibold hover:border-slate-400 hover:bg-slate-50 transition">
                        Go to dashboard <i class="fas fa-arrow-right text-xs opacity-70" aria-hidden="true"></i>
                    </a>
                @else
                    <a href="{{ route('client.register') }}" class="mt-6 inline-flex items-center justify-center gap-2 w-full px-4 py-3 rounded-xl border border-slate-300 text-slate-800 font-semibold hover:border-slate-400 hover:bg-slate-50 transition">
                        Start free <i class="fas fa-arrow-right text-xs opacity-70" aria-hidden="true"></i>
                    </a>
                @endauth
            </div>

            {{-- Celebration pack --}}
            <div class="group relative flex flex-col bg-gradient-to-br from-white via-indigo-50/30 to-violet-50/40 rounded-2xl border-2 border-indigo-500 p-6 sm:p-7 shadow-xl shadow-indigo-500/15 hover:shadow-2xl hover:shadow-indigo-500/20 hover:-translate-y-1 transition-all duration-300 overflow-hidden">
                <div class="absolute inset-x-0 top-0 h-1.5 bg-gradient-to-r from-indigo-500 via-violet-500 to-purple-500" aria-hidden="true"></div>
                <div class="flex items-center gap-3 mb-5 mt-1">
                    <div class="h-11 w-11 rounded-xl bg-gradient-to-br from-indigo-500 to-violet-600 text-white flex items-center justify-center shrink-0 shadow-md shadow-indigo-500/30">
                        <i class="fas fa-wand-magic-sparkles text-lg" aria-hidden="true"></i>
                    </div>
                    <div class="min-w-0">
                        <p class="text-[0.7rem] font-bold uppercase tracking-wider text-indigo-600">Invites · video · pre-wedding</p>
                        <h3 class="text-lg font-bold text-slate-900 leading-tight">Celebration pack</h3>
                    </div>
                </div>
                <div class="flex items-baseline gap-1.5 mb-4">
                    <span class="text-4xl font-black text-slate-900 tabular-nums">₹{{ number_format($celebPrice, 0) }}</span>
                    <span class="text-sm text-slate-500 font-medium">one-time</span>
                </div>
                <p class="text-slate-600 text-sm leading-relaxed mb-5">Ten printable invitation layouts, one cinematic story video, and the full pre-wedding countdown studio.</p>
                <ul class="space-y-2.5 text-slate-700 text-sm flex-1">
                    <li class="flex gap-2.5"><i class="fas fa-check text-indigo-600 mt-0.5 shrink-0" aria-hidden="true"></i><span><strong>10</strong> invitation designs — PNG &amp; print</span></li>
                    <li class="flex gap-2.5"><i class="fas fa-check text-indigo-600 mt-0.5 shrink-0" aria-hidden="true"></i><span><strong>1</strong> cinematic video for Reels / status</span></li>
                    <li class="flex gap-2.5"><i class="fas fa-check text-indigo-600 mt-0.5 shrink-0" aria-hidden="true"></i><span><strong>Pre-wedding</strong> studio — milestone PNGs</span></li>
                </ul>
                @auth
                    @if($planLevel === 1)
                        <span class="mt-6 inline-flex items-center justify-center gap-2 w-full px-4 py-3 rounded-xl bg-emerald-50 text-emerald-700 font-bold border border-emerald-300/80 cursor-default">
                            <i class="fas fa-circle-check text-emerald-600" aria-hidden="true"></i> Your pack
                        </span>
                    @elseif($planLevel > 1)
                        <span class="mt-6 inline-flex items-center justify-center gap-2 w-full px-4 py-3 rounded-xl bg-slate-100 text-slate-400 font-bold border border-slate-200 cursor-not-allowed">
                            <i class="fas fa-ban text-xs" aria-hidden="true"></i> Included in higher plan
                        </span>
                    @else
                        <a href="{{ route('client.packs.celebration.pay') }}" data-loader="payment" class="mt-6 inline-flex items-center justify-center gap-2 w-full px-4 py-3 rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 text-white font-bold shadow-lg shadow-indigo-500/30 hover:from-indigo-500 hover:to-violet-500 hover:shadow-xl hover:shadow-indigo-500/40 transition-all">
                            <i class="fas fa-bolt text-xs" aria-hidden="true"></i> Pay ₹{{ number_format($celebPrice, 0) }}
                        </a>
                    @endif
                @else
                    <a href="{{ route('client.register') }}" class="mt-6 inline-flex items-center justify-center gap-2 w-full px-4 py-3 rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 text-white font-bold shadow-lg shadow-indigo-500/30 hover:from-indigo-500 hover:to-violet-500 transition-all">
                        Create account &amp; pay
                    </a>
                @endauth
            </div>

            {{-- Guest pay pack --}}
            <div class="group relative flex flex-col bg-white rounded-2xl border border-amber-200 p-6 sm:p-7 shadow-md shadow-amber-500/5 hover:shadow-xl hover:shadow-amber-500/10 hover:border-amber-300 hover:-translate-y-0.5 transition-all duration-300 overflow-hidden">
                <div class="absolute inset-x-0 top-0 h-1.5 bg-gradient-to-r from-amber-500 to-orange-500" aria-hidden="true"></div>
                <div class="flex items-center gap-3 mb-5 mt-1">
                    <div class="h-11 w-11 rounded-xl bg-gradient-to-br from-amber-500 to-orange-600 text-white flex items-center justify-center shrink-0 shadow-md shadow-amber-500/30">
                        <i class="fas fa-qrcode text-lg" aria-hidden="true"></i>
                    </div>
                    <div class="min-w-0">
                        <p class="text-[0.7rem] font-bold uppercase tracking-wider text-amber-700">One event · UPI / QR</p>
                        <h3 class="text-lg font-bold text-slate-900 leading-tight">Guest pay pack</h3>
                    </div>
                </div>
                <div class="flex items-baseline gap-1.5 mb-4">
                    <span class="text-4xl font-black text-slate-900 tabular-nums">₹{{ number_format($guestPrice, 0) }}</span>
                    <span class="text-sm text-slate-500 font-medium">one-time</span>
                </div>
                <p class="text-slate-600 text-sm leading-relaxed mb-5">Pay once → get a credit. Apply on any event to share your <strong>pay-to-you QR</strong> with guests.</p>
                <ul class="space-y-2.5 text-slate-700 text-sm flex-1">
                    <li class="flex gap-2.5"><i class="fas fa-check text-amber-600 mt-0.5 shrink-0" aria-hidden="true"></i><span>Direct GPay unlock for <strong>1 event</strong></span></li>
                    <li class="flex gap-2.5"><i class="fas fa-check text-amber-600 mt-0.5 shrink-0" aria-hidden="true"></i><span><strong>Unlimited</strong> chandla entries on that event</span></li>
                    <li class="flex gap-2.5"><i class="fas fa-check text-amber-600 mt-0.5 shrink-0" aria-hidden="true"></i><span>Full event <strong>PDF</strong> + email</span></li>
                </ul>
                @auth
                    @if($planLevel === 2)
                        <span class="mt-6 inline-flex items-center justify-center gap-2 w-full px-4 py-3 rounded-xl bg-emerald-50 text-emerald-700 font-bold border border-emerald-300/80 cursor-default">
                            <i class="fas fa-circle-check text-emerald-600" aria-hidden="true"></i> Your pack
                        </span>
                    @elseif($planLevel > 2)
                        <span class="mt-6 inline-flex items-center justify-center gap-2 w-full px-4 py-3 rounded-xl bg-slate-100 text-slate-400 font-bold border border-slate-200 cursor-not-allowed">
                            <i class="fas fa-ban text-xs" aria-hidden="true"></i> Included in higher plan
                        </span>
                    @else
                        <a href="{{ route('client.packs.guest-pay-single.pay') }}" data-loader="payment" class="mt-6 inline-flex items-center justify-center gap-2 w-full px-4 py-3 rounded-xl bg-gradient-to-r from-amber-600 to-orange-600 text-white font-bold shadow-md shadow-amber-500/25 hover:from-amber-500 hover:to-orange-500 hover:shadow-lg transition-all">
                            <i class="fas fa-bolt text-xs" aria-hidden="true"></i> Pay ₹{{ number_format($guestPrice, 0) }}
                        </a>
                    @endif
                @else
                    <a href="{{ route('client.register') }}" class="mt-6 inline-flex items-center justify-center gap-2 w-full px-4 py-3 rounded-xl border-2 border-amber-500 text-amber-800 font-bold hover:bg-amber-50 transition">
                        Create account &amp; pay
                    </a>
                @endauth
            </div>

            {{-- Host Duo pack --}}
            <div class="group relative flex flex-col bg-white rounded-2xl border border-sky-200 p-6 sm:p-7 shadow-md shadow-sky-500/5 hover:shadow-xl hover:shadow-sky-500/10 hover:border-sky-300 hover:-translate-y-0.5 transition-all duration-300 overflow-hidden">
                <div class="absolute inset-x-0 top-0 h-1.5 bg-gradient-to-r from-sky-400 to-cyan-500" aria-hidden="true"></div>
                <div class="flex items-center gap-3 mb-5 mt-1">
                    <div class="h-11 w-11 rounded-xl bg-gradient-to-br from-sky-500 to-cyan-600 text-white flex items-center justify-center shrink-0 shadow-md shadow-sky-500/30">
                        <i class="fas fa-book-open text-lg" aria-hidden="true"></i>
                    </div>
                    <div class="min-w-0">
                        <p class="text-[0.7rem] font-bold uppercase tracking-wider text-sky-600">Ledger · two events</p>
                        <h3 class="text-lg font-bold text-slate-900 leading-tight">Host Duo pack</h3>
                    </div>
                </div>
                <div class="flex items-baseline gap-1.5 mb-4">
                    <span class="text-4xl font-black text-slate-900 tabular-nums">₹{{ number_format($hostDuoPrice, 0) }}</span>
                    <span class="text-sm text-slate-500 font-medium">one-time</span>
                </div>
                <p class="text-slate-600 text-sm leading-relaxed mb-5">Two events with <strong>unlimited chandla</strong> entries — perfect when you only need the gift ledger and PDFs.</p>
                <ul class="space-y-2.5 text-slate-700 text-sm flex-1">
                    <li class="flex gap-2.5"><i class="fas fa-check text-sky-600 mt-0.5 shrink-0" aria-hidden="true"></i><span><strong>2 events</strong> at full account allowance</span></li>
                    <li class="flex gap-2.5"><i class="fas fa-check text-sky-600 mt-0.5 shrink-0" aria-hidden="true"></i><span><strong>Unlimited</strong> chandla rows (per app rules)</span></li>
                    <li class="flex gap-2.5"><i class="fas fa-check text-sky-600 mt-0.5 shrink-0" aria-hidden="true"></i><span>Full event <strong>PDF</strong> where supported</span></li>
                    <li class="flex gap-2.5"><i class="fas fa-check text-sky-600 mt-0.5 shrink-0" aria-hidden="true"></i><span><strong>3 family viewers</strong> — read-only access</span></li>
                </ul>
                @auth
                    @if($planLevel === 3)
                        <span class="mt-6 inline-flex items-center justify-center gap-2 w-full px-4 py-3 rounded-xl bg-emerald-50 text-emerald-700 font-bold border border-emerald-300/80 cursor-default">
                            <i class="fas fa-circle-check text-emerald-600" aria-hidden="true"></i> Your pack
                        </span>
                    @elseif($planLevel > 3)
                        <span class="mt-6 inline-flex items-center justify-center gap-2 w-full px-4 py-3 rounded-xl bg-slate-100 text-slate-400 font-bold border border-slate-200 cursor-not-allowed">
                            <i class="fas fa-ban text-xs" aria-hidden="true"></i> Included in higher plan
                        </span>
                    @else
                        <a href="{{ route('client.packs.host-duo.pay') }}" data-loader="payment" class="mt-6 inline-flex items-center justify-center gap-2 w-full px-4 py-3 rounded-xl bg-gradient-to-r from-sky-500 to-cyan-600 text-white font-bold shadow-md shadow-sky-500/25 hover:from-sky-400 hover:to-cyan-500 hover:shadow-lg transition-all">
                            <i class="fas fa-bolt text-xs" aria-hidden="true"></i> Pay ₹{{ number_format($hostDuoPrice, 0) }}
                        </a>
                    @endif
                @else
                    <a href="{{ route('client.register') }}" class="mt-6 inline-flex items-center justify-center gap-2 w-full px-4 py-3 rounded-xl border-2 border-sky-500 text-sky-700 font-bold hover:bg-sky-50 transition">
                        Create account &amp; pay
                    </a>
                @endauth
            </div>

            {{-- Family pack — NEW (₹600): editors --}}
            <div class="group relative flex flex-col bg-gradient-to-br from-violet-50/40 via-white to-fuchsia-50/30 rounded-2xl border-2 border-violet-500 p-6 sm:p-7 shadow-xl shadow-violet-500/15 hover:shadow-2xl hover:shadow-violet-500/25 hover:-translate-y-1 transition-all duration-300 overflow-hidden">
                <div class="absolute inset-x-0 top-0 h-1.5 bg-gradient-to-r from-violet-500 via-fuchsia-500 to-pink-500" aria-hidden="true"></div>
                <div class="absolute top-3 right-3">
                    <span class="inline-flex items-center gap-1 rounded-full bg-gradient-to-r from-violet-600 to-fuchsia-600 text-white text-[0.65rem] font-bold uppercase tracking-wider px-2.5 py-1 shadow-md shadow-violet-500/30">
                        <i class="fas fa-star text-[0.55rem]" aria-hidden="true"></i> Most popular
                    </span>
                </div>
                <div class="flex items-center gap-3 mb-5 mt-2">
                    <div class="h-11 w-11 rounded-xl bg-gradient-to-br from-violet-500 to-fuchsia-600 text-white flex items-center justify-center shrink-0 shadow-md shadow-violet-500/30">
                        <i class="fas fa-shield-halved text-lg" aria-hidden="true"></i>
                    </div>
                    <div class="min-w-0">
                        <p class="text-[0.7rem] font-bold uppercase tracking-wider text-violet-700">Ledger · 3 co-managers</p>
                        <h3 class="text-lg font-bold text-slate-900 leading-tight">Family pack</h3>
                    </div>
                </div>
                <div class="flex items-baseline gap-1.5 mb-4">
                    <span class="text-4xl font-black text-slate-900 tabular-nums">₹{{ number_format($familyPrice, 0) }}</span>
                    <span class="text-sm text-slate-500 font-medium">one-time</span>
                </div>
                <p class="text-slate-600 text-sm leading-relaxed mb-5">Everything in Host Duo, <strong>plus 3 family members with full access</strong> who can add and edit on your account — perfect for joint family hosting.</p>
                <ul class="space-y-2.5 text-slate-700 text-sm flex-1">
                    <li class="flex gap-2.5"><i class="fas fa-check text-violet-600 mt-0.5 shrink-0" aria-hidden="true"></i><span><strong>3 family editors</strong> — full add &amp; edit access</span></li>
                    <li class="flex gap-2.5"><i class="fas fa-check text-violet-600 mt-0.5 shrink-0" aria-hidden="true"></i><span><strong>2 events</strong> at full account allowance</span></li>
                    <li class="flex gap-2.5"><i class="fas fa-check text-violet-600 mt-0.5 shrink-0" aria-hidden="true"></i><span><strong>Unlimited</strong> chandla rows</span></li>
                    <li class="flex gap-2.5"><i class="fas fa-check text-violet-600 mt-0.5 shrink-0" aria-hidden="true"></i><span>Full event <strong>PDF</strong></span></li>
                    <li class="flex gap-2.5"><i class="fas fa-circle-info text-violet-400 mt-0.5 shrink-0 text-xs" aria-hidden="true"></i><span class="text-xs text-slate-500">Editors can't delete, manage family, or buy plans</span></li>
                </ul>
                @auth
                    @if($planLevel === 4)
                        <span class="mt-6 inline-flex items-center justify-center gap-2 w-full px-4 py-3 rounded-xl bg-emerald-50 text-emerald-700 font-bold border border-emerald-300/80 cursor-default">
                            <i class="fas fa-circle-check text-emerald-600" aria-hidden="true"></i> Your pack
                        </span>
                    @elseif($planLevel > 4)
                        <span class="mt-6 inline-flex items-center justify-center gap-2 w-full px-4 py-3 rounded-xl bg-slate-100 text-slate-400 font-bold border border-slate-200 cursor-not-allowed">
                            <i class="fas fa-ban text-xs" aria-hidden="true"></i> Included in higher plan
                        </span>
                    @else
                        <a href="{{ route('client.packs.family.pay') }}" data-loader="payment" class="mt-6 inline-flex items-center justify-center gap-2 w-full px-4 py-3 rounded-xl bg-gradient-to-r from-violet-600 to-fuchsia-600 text-white font-bold shadow-lg shadow-violet-500/30 hover:from-violet-500 hover:to-fuchsia-500 hover:shadow-xl hover:shadow-violet-500/40 transition-all">
                            <i class="fas fa-bolt text-xs" aria-hidden="true"></i> Pay ₹{{ number_format($familyPrice, 0) }}
                        </a>
                    @endif
                @else
                    <a href="{{ route('client.register') }}" class="mt-6 inline-flex items-center justify-center gap-2 w-full px-4 py-3 rounded-xl border-2 border-violet-500 text-violet-700 font-bold hover:bg-violet-50 transition">
                        Create account &amp; pay
                    </a>
                @endauth
            </div>

            {{-- Complete host pack — BEST VALUE --}}
            <div class="group relative flex flex-col bg-gradient-to-br from-emerald-50/40 via-white to-teal-50/30 rounded-2xl border-2 border-emerald-500 p-6 sm:p-7 shadow-xl shadow-emerald-500/15 hover:shadow-2xl hover:shadow-emerald-500/25 hover:-translate-y-1 transition-all duration-300 overflow-hidden md:col-span-2 xl:col-span-1">
                <div class="absolute inset-x-0 top-0 h-1.5 bg-gradient-to-r from-emerald-400 via-teal-500 to-cyan-500" aria-hidden="true"></div>
                <div class="absolute top-3 right-3">
                    <span class="inline-flex items-center gap-1 rounded-full bg-gradient-to-r from-emerald-600 to-teal-600 text-white text-[0.65rem] font-bold uppercase tracking-wider px-2.5 py-1 shadow-md shadow-emerald-500/30">
                        <i class="fas fa-crown text-[0.55rem]" aria-hidden="true"></i> Best value
                    </span>
                </div>
                <div class="flex items-center gap-3 mb-5 mt-2">
                    <div class="h-11 w-11 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 text-white flex items-center justify-center shrink-0 shadow-md shadow-emerald-500/30">
                        <i class="fas fa-gem text-lg" aria-hidden="true"></i>
                    </div>
                    <div class="min-w-0">
                        <p class="text-[0.7rem] font-bold uppercase tracking-wider text-emerald-700">All-in-one</p>
                        <h3 class="text-lg font-bold text-slate-900 leading-tight">Complete host pack</h3>
                    </div>
                </div>
                <div class="flex items-baseline gap-1.5 mb-4">
                    <span class="text-4xl font-black text-slate-900 tabular-nums">₹{{ number_format($bundlePrice, 0) }}</span>
                    <span class="text-sm text-slate-500 font-medium">one-time</span>
                    <span class="ml-auto text-[0.65rem] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full">SAVE ₹{{ number_format($celebPrice + $hostDuoPrice - $bundlePrice, 0) }}</span>
                </div>
                <p class="text-slate-600 text-sm leading-relaxed mb-5">Celebration pack <strong>+</strong> Host Duo ledger combined. Social graphics and a full ledger in one payment.</p>
                <ul class="space-y-2.5 text-slate-700 text-sm flex-1">
                    <li class="flex gap-2.5"><i class="fas fa-check text-emerald-600 mt-0.5 shrink-0" aria-hidden="true"></i><span>All Celebration features (10 styles · 1 video · pre-wedding)</span></li>
                    <li class="flex gap-2.5"><i class="fas fa-check text-emerald-600 mt-0.5 shrink-0" aria-hidden="true"></i><span><strong>3 events</strong> on your account</span></li>
                    <li class="flex gap-2.5"><i class="fas fa-check text-emerald-600 mt-0.5 shrink-0" aria-hidden="true"></i><span><strong>Unlimited</strong> chandla entries</span></li>
                    <li class="flex gap-2.5"><i class="fas fa-check text-emerald-600 mt-0.5 shrink-0" aria-hidden="true"></i><span><strong>3 family editors</strong> — full add &amp; edit access</span></li>
                    <li class="flex gap-2.5"><i class="fas fa-check text-emerald-600 mt-0.5 shrink-0" aria-hidden="true"></i><span>Full event <strong>PDF</strong> export &amp; email</span></li>
                </ul>
                @auth
                    @if($planLevel === 5)
                        <span class="mt-6 inline-flex items-center justify-center gap-2 w-full px-4 py-3 rounded-xl bg-emerald-50 text-emerald-700 font-bold border border-emerald-300/80 cursor-default">
                            <i class="fas fa-circle-check text-emerald-600" aria-hidden="true"></i> Your pack
                        </span>
                    @else
                        <a href="{{ route('client.packs.bundle.pay') }}" data-loader="payment" class="mt-6 inline-flex items-center justify-center gap-2 w-full px-4 py-3 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 text-white font-bold shadow-lg shadow-emerald-500/30 hover:from-emerald-500 hover:to-teal-500 hover:shadow-xl hover:shadow-emerald-500/40 transition-all">
                            <i class="fas fa-bolt text-xs" aria-hidden="true"></i> Pay ₹{{ number_format($bundlePrice, 0) }}
                        </a>
                    @endif
                @else
                    <a href="{{ route('client.register') }}" class="mt-6 inline-flex items-center justify-center gap-2 w-full px-4 py-3 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 text-white font-bold shadow-lg shadow-emerald-500/30 hover:from-emerald-500 hover:to-teal-500 transition-all">
                        Create account &amp; pay
                    </a>
                @endauth
            </div>
        </div>

        <div id="direct-gpay" class="mt-10 scroll-mt-24 rounded-2xl border-2 border-emerald-200/90 bg-gradient-to-br from-emerald-50 via-white to-teal-50/40 p-6 md:p-8 shadow-[0_16px_40px_-20px_rgba(5,150,105,0.25)] ring-1 ring-emerald-100/80 {{ ($pricingNestClient ?? false) ? 'md:shadow-[0_20px_48px_-18px_rgba(5,150,105,0.22)]' : 'shadow-sm' }}">
            <div class="flex flex-col md:flex-row md:items-start gap-4 md:gap-8">
                <div class="h-12 w-12 rounded-xl bg-emerald-600 text-white flex items-center justify-center shrink-0 shadow-md">
                    <i class="fas fa-mobile-screen text-xl" aria-hidden="true"></i>
                </div>
                <div class="flex-1">
                    <p class="text-xs font-bold uppercase tracking-widest text-emerald-800 mb-1">Direct guest payments (per event add‑on)</p>
                    <h3 class="text-xl md:text-2xl font-bold text-slate-900 mb-2">Your UPI or QR on file — we give you a pay‑to‑you QR &amp; link</h3>
                    <p class="text-slate-600 text-sm md:text-base leading-relaxed">Turn on the <strong>Direct GPay / UPI</strong> feature for a given event: you <strong>enter your UPI ID</strong> or <strong>upload a scanner / static QR</strong> image. The system <strong>generates a new payment QR / link</strong> for that event. <strong>Anyone can pay you directly</strong> (any amount they choose) — no extra hop through our accounts. <strong>Full event export &amp; PDF email / download</strong> is included in the same workflow. Either pay the in-app per-event unlock fee or buy the <strong>₹{{ number_format((float) config('landing.guest_pay_single_inr', 400), 0) }} Guest pay pack</strong> on the pricing table and <strong>apply one credit</strong> on the unlock screen.</p>
                    <ul class="mt-4 grid sm:grid-cols-2 gap-2 text-sm text-slate-700 list-none">
                        <li class="flex gap-2"><i class="fas fa-circle-check text-emerald-600 mt-0.5 shrink-0" aria-hidden="true"></i><span>UPI or uploaded QR for receiving</span></li>
                        <li class="flex gap-2"><i class="fas fa-circle-check text-emerald-600 mt-0.5 shrink-0" aria-hidden="true"></i><span>Scannable “pay the host” QR <strong>for that event</strong></span></li>
                        <li class="flex gap-2"><i class="fas fa-circle-check text-emerald-600 mt-0.5 shrink-0" aria-hidden="true"></i><span>GPAY GPAY category &amp; ledger in app</span></li>
                        <li class="flex gap-2"><i class="fas fa-circle-check text-emerald-600 mt-0.5 shrink-0" aria-hidden="true"></i><span>Same <strong>full-event PDF / email</strong> as other paid options</span></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>
