<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    @include('public.partials.seo')
    @include('public.partials.jsonld')
    <link rel="stylesheet" href="{{ asset('css/tailwind.css') }}?v=2">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-slate-950 text-white">
    <div class="bg-gradient-to-br from-indigo-950 via-purple-900 to-slate-950">
        <header class="max-w-6xl mx-auto px-6 py-6 flex items-center justify-between">
            <div class="flex items-center">
                <img src="{{ asset('images/chandla-favicon.png') }}" alt="Chandla Book" class="h-14 w-auto mr-3" decoding="async">
                <span class="text-2xl font-bold text-white">Chandla Book</span>
            </div>
            <div class="flex flex-wrap items-center gap-2 sm:gap-3">
                <a href="{{ route('public.contact') }}" class="px-4 py-2 text-white/80 hover:text-white font-semibold">Contact</a>
                <a href="{{ route('client.login') }}" class="px-4 py-2 text-white/80 hover:text-white font-semibold">Login</a>
                <a href="{{ route('client.register') }}" class="px-4 py-2 bg-white text-indigo-700 rounded-lg hover:bg-indigo-50 font-semibold">Get Started</a>
            </div>
        </header>

        <section class="max-w-6xl mx-auto px-6 py-12">
            {{-- Full-width headline --}}
            <div class="text-center mb-10">
                <div class="inline-flex items-center gap-2 bg-white/10 text-white/90 px-3 py-1 rounded-full text-sm mb-4">
                    <i class="fas fa-sparkles"></i>
                    Smart event collection platform
                </div>
                <h1 class="text-3xl sm:text-4xl md:text-5xl font-bold leading-tight whitespace-nowrap overflow-hidden text-ellipsis">
                    Track every rupee, every note, and every guest in one beautiful dashboard.
                </h1>
                <p class="mt-4 text-white/80 text-lg">
                    Cash, Cover, Gift, UPI proofs, PDFs, inventory, and admin reports — built for real Indian events.
                </p>
            </div>
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-10 items-start">
                {{-- LEFT: price cards + bundle note + CTA buttons --}}
                <div class="flex flex-col gap-5">
                    @php
                        $dgpayInr = (float) config('services.direct_gpay_unlock.amount', 400);
                    @endphp

                    {{-- Price cards --}}
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div class="rounded-2xl bg-gradient-to-br from-amber-500/25 to-orange-600/20 border border-amber-400/40 p-5 shadow-lg shadow-amber-900/20">
                            <div class="flex items-center gap-2 text-amber-200 text-xs font-semibold uppercase tracking-wider mb-2">
                                <i class="fas fa-heart text-amber-300" aria-hidden="true"></i> Social sharing
                            </div>
                            <div class="text-3xl md:text-4xl font-extrabold text-white tabular-nums">₹{{ number_format((float) config('landing.celebration_pack_inr', 300), 0) }}</div>
                            <p class="mt-2 text-white/90 text-sm leading-relaxed font-medium"><strong>Celebration pack</strong> — <strong>10</strong> invitation looks, <strong>one</strong> video, and <strong>pre‑wedding</strong> PNG studio. Razorpay after sign-in.</p>
                        </div>
                        <div class="rounded-2xl bg-gradient-to-br from-amber-500/20 to-emerald-600/20 border border-emerald-400/35 p-5 shadow-lg shadow-emerald-900/20">
                            <div class="flex items-center gap-2 text-emerald-200 text-xs font-semibold uppercase tracking-wider mb-2">
                                <i class="fas fa-qrcode text-emerald-300" aria-hidden="true"></i> Guest pay · one event
                            </div>
                            <div class="text-3xl md:text-4xl font-extrabold text-white tabular-nums">₹{{ number_format((float) config('landing.guest_pay_single_inr', 400), 0) }}</div>
                            <p class="mt-2 text-white/90 text-sm leading-relaxed font-medium"><strong>Guest pay pack</strong> — credit for <strong>one</strong> event: <strong>Direct GPay</strong> to your UPI (any amount from guests), <strong>unlimited chandla</strong> on that event, <strong>full PDF</strong>. Or unlock per event in-app (currently ₹{{ number_format($dgpayInr, 0) }}).</p>
                        </div>
                    </div>

                    {{-- Bundle note --}}
                    <p class="text-sm text-white/70">Ledger bundles: <strong class="text-white/90">Host Duo</strong> ₹{{ number_format((float) config('landing.host_duo_pack_inr', 500), 0) }} (2 events) · <strong class="text-white/90">Complete host</strong> ₹{{ number_format((float) config('landing.premium_bundle_inr', 700), 0) }} (invites + 3 events) — <a href="#pricing" class="text-amber-200 hover:text-white underline decoration-white/30">see pricing</a>.</p>

                    {{-- CTA buttons --}}
                    <div class="flex flex-wrap items-center gap-3">
                        <a href="{{ route('client.register') }}" class="px-6 py-3 bg-white text-indigo-700 rounded-lg hover:bg-indigo-50 font-semibold">
                            Start Free
                        </a>
                        <a href="#pricing" class="px-6 py-3 border border-white/30 rounded-lg hover:bg-white/10 font-medium">
                            View Plans
                        </a>
                        @php
                            $shareSiteUrl = url('/');
                            $waShareText = rawurlencode('Chandla Book — event chandla ledger & guest payments for Indian occasions. '.$shareSiteUrl);
                        @endphp
                        <a href="https://wa.me/?text={{ $waShareText }}" target="_blank" rel="noopener noreferrer" class="inline-flex items-center px-6 py-3 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-semibold shadow-lg shadow-emerald-900/30">
                            <i class="fab fa-whatsapp mr-2" aria-hidden="true"></i> Share on WhatsApp
                        </a>
                    </div>
                    <a href="#features" class="text-white/60 hover:text-white text-sm">Explore Features →</a>
                </div>

                {{-- RIGHT: Live Snapshot + plan comparison bar --}}
                <div class="flex flex-col gap-5">
                    <div class="bg-white/10 backdrop-blur rounded-2xl p-6 border border-white/20">
                        <div class="flex items-center justify-between mb-4">
                            <h3 class="text-xl font-semibold">Live Snapshot</h3>
                            <span class="text-xs text-white/70">Last 24 hours</span>
                        </div>
                        <div class="space-y-4">
                            <div class="bg-white/10 rounded-xl p-4">
                                <div class="flex items-center justify-between text-sm text-white/80">
                                    <span>Total Collected</span>
                                    <span class="font-semibold">₹1,52,400</span>
                                </div>
                                <div class="mt-2 h-2 bg-white/10 rounded-full overflow-hidden">
                                    <div class="h-full w-3/4 bg-emerald-400 rounded-full"></div>
                                </div>
                            </div>
                            <div class="grid grid-cols-2 gap-4">
                                <div class="bg-white/10 rounded-xl p-4">
                                    <div class="text-xs text-white/70">Cash on hand</div>
                                    <div class="text-xl font-bold">₹38,920</div>
                                </div>
                                <div class="bg-white/10 rounded-xl p-4">
                                    <div class="text-xs text-white/70">Pending change</div>
                                    <div class="text-xl font-bold">₹1,120</div>
                                </div>
                            </div>
                            <div class="bg-white/10 rounded-xl p-4 text-sm text-white/80">
                                <i class="fas fa-check text-emerald-400 mr-2"></i>
                                Inventory auto-updates with every cash entry.
                            </div>
                        </div>
                    </div>

                    {{-- Plan comparison bar --}}
                    <div class="grid grid-cols-3 gap-3 text-center">
                        <div class="bg-white/10 rounded-xl py-4 px-1 ring-1 ring-white/10">
                            <div class="text-2xl font-bold">1</div>
                            <div class="text-xs text-white/80 font-medium mt-1">event on <span class="text-white">Free</span></div>
                            <div class="text-[0.7rem] text-white/60 mt-1 leading-tight">max <strong class="text-white/90">50</strong> chandla</div>
                        </div>
                        <div class="bg-white/10 rounded-xl py-4 px-1 ring-1 ring-amber-400/30">
                            <div class="text-2xl font-bold text-amber-200">₹{{ number_format((float) config('landing.celebration_pack_inr', 300), 0) }}</div>
                            <div class="text-xs text-white/80 mt-1">Celebration</div>
                            <div class="text-[0.7rem] text-white/60 mt-1">invites · video · pre‑wedding</div>
                        </div>
                        <div class="bg-white/10 rounded-xl py-4 px-1 ring-1 ring-emerald-400/30">
                            <div class="text-2xl font-bold text-emerald-200">₹{{ number_format((float) config('landing.guest_pay_single_inr', 400), 0) }}</div>
                            <div class="text-xs text-white/80 mt-1">Guest pay</div>
                            <div class="text-[0.7rem] text-white/60 mt-1">1 event · UPI + PDF</div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>


    <section class="bg-slate-900 text-white border-y border-white/10">
        <div class="max-w-6xl mx-auto px-6 py-12">
            <h2 class="text-2xl md:text-3xl font-bold text-center mb-8">What you get at a glance</h2>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div class="rounded-2xl bg-white/5 border border-white/10 p-6 md:p-8">
                    <div class="text-4xl font-black text-amber-300 tabular-nums mb-2">₹{{ number_format((float) config('landing.celebration_pack_inr', 300), 0) }}</div>
                    <h3 class="text-xl font-semibold mb-3">Marriage invitation for social media</h3>
                    <ul class="space-y-2 text-white/80 text-sm leading-relaxed">
                        <li><i class="fas fa-check text-amber-400 mr-2"></i>One beautiful card — <strong>10+ layouts</strong> including Heritage gold, Minimal bloom, royal, garden, midnight glam &amp; more</li>
                        <li><i class="fas fa-check text-amber-400 mr-2"></i>Photo, schedule of events, venue &amp; dates</li>
                        <li><i class="fas fa-check text-amber-400 mr-2"></i>Print or save as PDF — perfect for <strong>WhatsApp, Instagram, Facebook</strong></li>
                    </ul>
                    <div class="mt-6 pt-6 border-t border-white/10">
                        <p class="text-xs font-semibold text-amber-200/90 uppercase tracking-wider mb-3">Layout previews (demo)</p>
                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                            @php
                                $demoCoupleSrc = asset('images/marriage-demo-couple.jpg').'?v=6';
                            @endphp
                            <figure class="m-0 min-w-0 w-full">
                                <div class="rounded-xl overflow-hidden border border-amber-500/30 bg-slate-950/50 shadow-lg w-full">
                                    <div class="bg-gradient-to-b from-[#fffef9] to-[#ede6d8] text-center px-2 pt-3 pb-2 border-b border-amber-800/20">
                                        <p class="text-[0.55rem] sm:text-[0.6rem] tracking-[0.2em] text-amber-950/80 font-serif font-medium">WEDDING INVITATION</p>
                                        <p class="text-[0.5rem] sm:text-[0.55rem] mt-0.5 italic text-amber-900/60 font-serif">Together with our families</p>
                                        <div class="h-px w-16 mx-auto my-1.5 bg-gradient-to-r from-transparent via-amber-600/70 to-transparent"></div>
                                    </div>
                                    <div class="p-1.5 sm:p-2 bg-gradient-to-br from-amber-500/30 to-amber-900/30 w-full">
                                        <div class="w-full min-w-0 overflow-hidden rounded-lg bg-amber-950/20 h-40 sm:h-48">
                                            <img
                                                src="{{ $demoCoupleSrc }}"
                                                alt="Sample couple photo, Heritage style"
                                                class="h-full w-full object-cover object-center"
                                                width="200"
                                                height="267"
                                                loading="lazy"
                                                decoding="async"
                                            />
                                        </div>
                                    </div>
                                    <p class="text-center text-sm sm:text-base font-serif text-amber-950/95 py-1.5 bg-[#fffef9]/95">Barbie &amp; Ken</p>
                                </div>
                                <figcaption class="text-center text-xs text-amber-200/85 font-medium mt-2">Heritage gold</figcaption>
                            </figure>
                            <figure class="m-0 min-w-0 w-full">
                                <div class="rounded-2xl overflow-hidden border border-slate-400/20 bg-slate-900/80 shadow-lg w-full">
                                    <div class="h-1.5 w-full bg-gradient-to-r from-fuchsia-500 via-violet-500 to-cyan-400"></div>
                                    <div class="px-2 pt-2 pb-1 text-center bg-white text-slate-900">
                                        <p class="text-[0.5rem] sm:text-[0.55rem] tracking-[0.18em] text-slate-500 font-semibold">WE INVITE YOU TO CELEBRATE</p>
                                        <p class="text-lg sm:text-xl font-serif font-semibold text-slate-900 mt-1">Barbie</p>
                                        <p class="text-sm font-bold bg-gradient-to-r from-violet-600 via-pink-600 to-cyan-600 bg-clip-text text-transparent">&amp;</p>
                                        <p class="text-lg sm:text-xl font-serif font-semibold text-slate-900">Ken</p>
                                    </div>
                                    <div class="p-1.5 sm:p-2 bg-slate-100 w-full">
                                        <div class="w-full min-w-0 h-32 sm:h-36 overflow-hidden rounded-xl border-2 border-slate-200">
                                            <img
                                                src="{{ $demoCoupleSrc }}"
                                                alt="Sample couple photo, Minimal style"
                                                class="h-full w-full object-cover object-center"
                                                width="200"
                                                height="160"
                                                loading="lazy"
                                                decoding="async"
                                            />
                                        </div>
                                    </div>
                                    <p class="text-center text-[0.6rem] tracking-wider text-slate-500 font-semibold py-1.5 bg-white">WHEN - WHERE</p>
                                </div>
                                <figcaption class="text-center text-xs text-amber-200/85 font-medium mt-2">Minimal bloom</figcaption>
                            </figure>
                        </div>
                    </div>
                </div>
                <div class="rounded-2xl bg-white/5 border border-white/10 p-6 md:p-8">
                    <div class="text-4xl font-black text-emerald-300 tabular-nums mb-2">₹{{ number_format((float) config('landing.guest_pay_single_inr', 400), 0) }}</div>
                    <h3 class="text-xl font-semibold mb-3">Guest pay pack — ledger + “pay to you” for <strong>one</strong> event</h3>
                    <ul class="space-y-2 text-white/80 text-sm leading-relaxed">
                        <li><i class="fas fa-check text-emerald-400 mr-2" aria-hidden="true"></i><strong>₹{{ number_format((float) config('landing.guest_pay_single_inr', 400), 0) }} one-time</strong> → one <strong>credit</strong>; apply it on <strong>Unlock Direct QR</strong> in the app for the event you choose.</li>
                        <li><i class="fas fa-check text-emerald-400 mr-2" aria-hidden="true"></i><strong>Unlimited chandla</strong> on that event, <strong>full event PDF</strong> export &amp; email, plus <strong>Direct GPay</strong>: your UPI / QR → guests pay <strong>any amount</strong> straight to you.</li>
                        <li><i class="fas fa-check text-emerald-400 mr-2" aria-hidden="true"></i>Alternatively, unlock Direct GPay per event in-app for <strong>₹{{ number_format((float) config('services.direct_gpay_unlock.amount', 400), 0) }}</strong> (see checkout for current amount).</li>
                        <li><i class="fas fa-check text-emerald-400 mr-2" aria-hidden="true"></i><strong>Host Duo</strong> / <strong>Complete host</strong> cover <strong>2 or 3 events</strong> with account-wide unlimited chandla — see the pricing table.</li>
                    </ul>

                    {{-- Feature previews --}}
                    <div class="mt-6 pt-6 border-t border-white/10">
                        <p class="text-xs font-semibold text-emerald-200/90 uppercase tracking-wider mb-3">Feature previews (demo)</p>
                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">

                            {{-- Card 1: Direct GPay / QR unlock --}}
                            <figure class="m-0 min-w-0 w-full">
                                <div class="rounded-xl overflow-hidden border border-emerald-500/30 bg-slate-950/50 shadow-lg w-full">
                                    {{-- header bar --}}
                                    <div class="bg-gradient-to-r from-emerald-700 to-teal-700 px-3 py-2 flex items-center gap-2">
                                        <div class="h-2 w-2 rounded-full bg-white/40"></div>
                                        <p class="text-[0.55rem] tracking-[0.18em] text-white/90 font-semibold uppercase">Direct GPay · Unlocked</p>
                                    </div>
                                    {{-- body --}}
                                    <div class="bg-slate-900 px-3 pt-3 pb-2 flex flex-col items-center gap-2">
                                        {{-- fake QR grid --}}
                                        <div class="w-20 h-20 sm:w-24 sm:h-24 rounded-lg border-2 border-emerald-400/60 bg-white p-1 flex items-center justify-center shadow-md shadow-emerald-900/40">
                                            <svg viewBox="0 0 21 21" class="w-full h-full" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <!-- QR finder squares -->
                                                <rect x="1" y="1" width="6" height="6" rx="0.5" fill="#0f172a"/>
                                                <rect x="2" y="2" width="4" height="4" rx="0.3" fill="white"/>
                                                <rect x="3" y="3" width="2" height="2" fill="#0f172a"/>
                                                <rect x="14" y="1" width="6" height="6" rx="0.5" fill="#0f172a"/>
                                                <rect x="15" y="2" width="4" height="4" rx="0.3" fill="white"/>
                                                <rect x="16" y="3" width="2" height="2" fill="#0f172a"/>
                                                <rect x="1" y="14" width="6" height="6" rx="0.5" fill="#0f172a"/>
                                                <rect x="2" y="15" width="4" height="4" rx="0.3" fill="white"/>
                                                <rect x="3" y="16" width="2" height="2" fill="#0f172a"/>
                                                <!-- data dots -->
                                                <rect x="9" y="1" width="1" height="1" fill="#0f172a"/>
                                                <rect x="11" y="1" width="1" height="1" fill="#0f172a"/>
                                                <rect x="9" y="3" width="2" height="1" fill="#0f172a"/>
                                                <rect x="9" y="5" width="1" height="2" fill="#0f172a"/>
                                                <rect x="11" y="4" width="2" height="1" fill="#0f172a"/>
                                                <rect x="8" y="8" width="1" height="2" fill="#0f172a"/>
                                                <rect x="10" y="8" width="2" height="1" fill="#0f172a"/>
                                                <rect x="13" y="8" width="1" height="2" fill="#0f172a"/>
                                                <rect x="15" y="8" width="2" height="1" fill="#0f172a"/>
                                                <rect x="18" y="9" width="2" height="1" fill="#0f172a"/>
                                                <rect x="8" y="11" width="2" height="1" fill="#0f172a"/>
                                                <rect x="11" y="11" width="1" height="2" fill="#0f172a"/>
                                                <rect x="14" y="11" width="2" height="2" fill="#0f172a"/>
                                                <rect x="17" y="11" width="1" height="1" fill="#0f172a"/>
                                                <rect x="8" y="14" width="1" height="2" fill="#0f172a"/>
                                                <rect x="10" y="14" width="2" height="1" fill="#0f172a"/>
                                                <rect x="13" y="15" width="1" height="2" fill="#0f172a"/>
                                                <rect x="15" y="14" width="2" height="1" fill="#0f172a"/>
                                                <rect x="18" y="15" width="2" height="2" fill="#0f172a"/>
                                                <rect x="8" y="17" width="1" height="2" fill="#0f172a"/>
                                                <rect x="11" y="18" width="2" height="1" fill="#0f172a"/>
                                                <rect x="15" y="17" width="1" height="2" fill="#0f172a"/>
                                                <rect x="18" y="18" width="2" height="1" fill="#0f172a"/>
                                            </svg>
                                        </div>
                                        <p class="text-[0.6rem] text-emerald-300/90 font-semibold tracking-wide">Scan &amp; Pay Any Amount</p>
                                        <div class="w-full rounded-md bg-emerald-600/20 border border-emerald-500/30 py-1 text-center">
                                            <span class="text-[0.6rem] text-emerald-200 font-medium">UPI · GPay · PhonePe · Paytm</span>
                                        </div>
                                    </div>
                                </div>
                                <figcaption class="text-center text-xs text-emerald-200/85 font-medium mt-2">Direct GPay QR</figcaption>
                            </figure>

                            {{-- Card 2: Full event PDF export --}}
                            <figure class="m-0 min-w-0 w-full">
                                <div class="rounded-xl overflow-hidden border border-teal-500/30 bg-slate-950/50 shadow-lg w-full">
                                    {{-- header bar --}}
                                    <div class="bg-gradient-to-r from-teal-700 to-cyan-700 px-3 py-2 flex items-center gap-2">
                                        <div class="h-2 w-2 rounded-full bg-white/40"></div>
                                        <p class="text-[0.55rem] tracking-[0.18em] text-white/90 font-semibold uppercase">Event PDF · Export</p>
                                    </div>
                                    {{-- body mimics a PDF page --}}
                                    <div class="bg-white px-2.5 pt-2.5 pb-2 flex flex-col gap-1.5">
                                        <div class="flex items-center justify-between">
                                            <span class="text-[0.5rem] font-bold text-slate-700 uppercase tracking-wider">Chandla Ledger</span>
                                            <span class="text-[0.45rem] text-slate-400">Event Report</span>
                                        </div>
                                        <div class="h-px bg-slate-200"></div>
                                        {{-- row entries --}}
                                        @foreach([['Ramesh Sharma','Cash','₹1,100'],['Sunil Verma','Cover','₹501'],['Priya Patel','Gift','Saree'],['Kavita Joshi','UPI','₹2,000'],['Anil Kumar','Cash','₹500']] as $row)
                                        <div class="flex items-center gap-1 text-[0.45rem] text-slate-600">
                                            <span class="w-3 h-3 rounded-full bg-teal-100 border border-teal-300 flex items-center justify-center shrink-0">
                                                <i class="fas fa-user text-teal-600" style="font-size:0.3rem"></i>
                                            </span>
                                            <span class="flex-1 truncate font-medium text-slate-700">{{ $row[0] }}</span>
                                            <span class="text-slate-400">{{ $row[1] }}</span>
                                            <span class="font-semibold text-teal-700 ml-auto">{{ $row[2] }}</span>
                                        </div>
                                        @endforeach
                                        <div class="h-px bg-slate-200 mt-0.5"></div>
                                        <div class="flex justify-between text-[0.5rem] font-bold text-slate-800 pt-0.5">
                                            <span>Total</span>
                                            <span class="text-teal-700">₹4,101 + Gift</span>
                                        </div>
                                        <div class="mt-1 rounded bg-teal-600 text-white text-center py-0.5">
                                            <span class="text-[0.5rem] font-semibold tracking-wide">Download PDF &amp; Email</span>
                                        </div>
                                    </div>
                                </div>
                                <figcaption class="text-center text-xs text-emerald-200/85 font-medium mt-2">Full event PDF</figcaption>
                            </figure>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section id="features" class="relative overflow-hidden bg-slate-100 text-slate-900">
        <div class="max-w-6xl mx-auto px-6 relative" style="padding-top:5rem;padding-bottom:5rem">
            <div class="flex flex-col lg:flex-row lg:items-end lg:justify-between gap-8">
                <div class="max-w-xl">
                    <p class="text-xs font-bold uppercase tracking-[0.2em] text-indigo-600 mb-3">Features</p>
                    <h2 class="text-3xl md:text-4xl font-bold text-slate-900 tracking-tight">Built for real Indian events</h2>
                    <p class="text-slate-600 mt-3 text-base leading-relaxed">Ledger, guests, social-ready invites, and pre‑wedding graphics — in one calm dashboard.</p>
                </div>
                <a href="{{ route('client.register') }}" class="inline-flex items-center justify-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 text-white font-semibold shadow-lg shadow-indigo-500/25 hover:from-indigo-500 hover:to-violet-500 transition-all shrink-0">
                    <i class="fas fa-sparkles text-sm opacity-90" aria-hidden="true"></i>
                    Create free account
                </a>
            </div>
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-7 mt-12">
                <div class="group relative flex flex-col h-full rounded-2xl border border-slate-200/90 bg-white/95 p-6 md:p-7 shadow-md shadow-slate-200/50 ring-1 ring-white/60 transition-all duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-indigo-500/10 hover:border-indigo-200/70">
                    <div class="absolute inset-x-0 top-0 h-1 rounded-t-2xl bg-gradient-to-r from-indigo-500 via-violet-500 to-purple-500 opacity-90 group-hover:opacity-100" aria-hidden="true"></div>
                    <div class="mb-5 inline-flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-indigo-500 to-indigo-700 text-white shadow-lg shadow-indigo-500/35">
                        <i class="fas fa-coins text-lg" aria-hidden="true"></i>
                    </div>
                    <h3 class="font-bold text-lg text-slate-900 mb-2 tracking-tight">Cash inventory management</h3>
                    <p class="text-slate-600 text-sm leading-relaxed flex-1">Track every <strong>₹1 to ₹500</strong> note, opening balance, and change returned.</p>
                </div>
                <div class="group relative flex flex-col h-full rounded-2xl border border-slate-200/90 bg-white/95 p-6 md:p-7 shadow-md shadow-slate-200/50 ring-1 ring-white/60 transition-all duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-emerald-500/10 hover:border-emerald-200/70">
                    <div class="absolute inset-x-0 top-0 h-1 rounded-t-2xl bg-gradient-to-r from-emerald-500 to-teal-500 opacity-90 group-hover:opacity-100" aria-hidden="true"></div>
                    <div class="mb-5 inline-flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 text-white shadow-lg shadow-emerald-500/35">
                        <i class="fas fa-file-pdf text-lg" aria-hidden="true"></i>
                    </div>
                    <h3 class="font-bold text-lg text-slate-900 mb-2 tracking-tight">One‑click PDFs</h3>
                    <p class="text-slate-600 text-sm leading-relaxed flex-1">Separate pages for <strong>Cash</strong>, <strong>Cover</strong>, and <strong>Gift</strong> with totals and summaries.</p>
                </div>
                <div class="group relative flex flex-col h-full rounded-2xl border border-slate-200/90 bg-white/95 p-6 md:p-7 shadow-md shadow-slate-200/50 ring-1 ring-white/60 transition-all duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-violet-500/10 hover:border-violet-200/70">
                    <div class="absolute inset-x-0 top-0 h-1 rounded-t-2xl bg-gradient-to-r from-violet-500 to-fuchsia-500 opacity-90 group-hover:opacity-100" aria-hidden="true"></div>
                    <div class="mb-5 inline-flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-violet-500 to-purple-600 text-white shadow-lg shadow-violet-500/35">
                        <i class="fas fa-qrcode text-lg" aria-hidden="true"></i>
                    </div>
                    <h3 class="font-bold text-lg text-slate-900 mb-2 tracking-tight">QR + UPI proof</h3>
                    <p class="text-slate-600 text-sm leading-relaxed flex-1">Generate QR, upload <strong>GPay</strong> proof, and verify UPI transactions.</p>
                </div>
                <div class="group relative flex flex-col h-full rounded-2xl border border-slate-200/90 bg-white/95 p-6 md:p-7 shadow-md shadow-slate-200/50 ring-1 ring-white/60 transition-all duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-amber-500/10 hover:border-amber-200/70">
                    <div class="absolute inset-x-0 top-0 h-1 rounded-t-2xl bg-gradient-to-r from-amber-500 to-orange-500 opacity-90 group-hover:opacity-100" aria-hidden="true"></div>
                    <div class="mb-5 inline-flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-amber-500 to-orange-600 text-white shadow-lg shadow-amber-500/35">
                        <i class="fas fa-users text-lg" aria-hidden="true"></i>
                    </div>
                    <h3 class="font-bold text-lg text-slate-900 mb-2 tracking-tight">Guest &amp; event tracking</h3>
                    <p class="text-slate-600 text-sm leading-relaxed flex-1"><strong>50</strong> entries total on Free. <strong>Guest pay pack</strong> removes the cap for <strong>one</strong> event; <strong>Host Duo</strong> / <strong>Complete host</strong> unlock unlimited chandla for <strong>all covered events</strong>. Filters, search, one ledger per event.</p>
                </div>
                <div class="group relative flex flex-col h-full rounded-2xl border border-slate-200/90 bg-white/95 p-6 md:p-7 shadow-md shadow-slate-200/50 ring-1 ring-white/60 transition-all duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-rose-500/10 hover:border-rose-200/70">
                    <div class="absolute inset-x-0 top-0 h-1 rounded-t-2xl bg-gradient-to-r from-rose-500 to-pink-500 opacity-90 group-hover:opacity-100" aria-hidden="true"></div>
                    <div class="mb-5 inline-flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-rose-500 to-pink-600 text-white shadow-lg shadow-rose-500/35">
                        <i class="fas fa-envelope-open-text text-lg" aria-hidden="true"></i>
                    </div>
                    <h3 class="font-bold text-lg text-slate-900 mb-2 tracking-tight">Invitation creation</h3>
                    <p class="text-slate-600 text-sm leading-relaxed flex-1">One shared form powers <strong>10+ print styles</strong> — save PNGs, print, and share a <strong>story‑ready video</strong> for WhatsApp, Instagram &amp; Reels (with the Celebration pack).</p>
                </div>
                <div class="group relative flex flex-col h-full rounded-2xl border border-slate-200/90 bg-white/95 p-6 md:p-7 shadow-md shadow-slate-200/50 ring-1 ring-white/60 transition-all duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-fuchsia-500/10 hover:border-fuchsia-200/70">
                    <div class="absolute inset-x-0 top-0 h-1 rounded-t-2xl bg-gradient-to-r from-fuchsia-500 to-purple-600 opacity-90 group-hover:opacity-100" aria-hidden="true"></div>
                    <div class="mb-5 inline-flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-fuchsia-500 to-purple-600 text-white shadow-lg shadow-fuchsia-500/35">
                        <i class="fas fa-photo-film text-lg" aria-hidden="true"></i>
                    </div>
                    <h3 class="font-bold text-lg text-slate-900 mb-2 tracking-tight">Pre‑wedding image + video</h3>
                    <p class="text-slate-600 text-sm leading-relaxed flex-1">Upload a photo per countdown milestone, get a <strong>styled card</strong> for each theme, and download <strong>high‑res PNGs</strong>; pair with your invitation <strong>video export</strong> for a full social suite.</p>
                </div>
                <div class="group relative flex flex-col h-full rounded-2xl border border-slate-200/90 bg-white/95 p-6 md:p-7 shadow-md shadow-slate-200/50 ring-1 ring-white/60 transition-all duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-cyan-500/10 hover:border-cyan-200/70">
                    <div class="absolute inset-x-0 top-0 h-1 rounded-t-2xl bg-gradient-to-r from-cyan-500 to-slate-600 opacity-90 group-hover:opacity-100" aria-hidden="true"></div>
                    <div class="mb-5 inline-flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-slate-600 to-slate-800 text-white shadow-lg shadow-slate-600/35">
                        <i class="fas fa-lock text-lg" aria-hidden="true"></i>
                    </div>
                    <h3 class="font-bold text-lg text-slate-900 mb-2 tracking-tight">Secure &amp; verified</h3>
                    <p class="text-slate-600 text-sm leading-relaxed flex-1">Verification controls for payments and <strong>audit-ready</strong> reports.</p>
                </div>
                <div class="group relative flex flex-col h-full rounded-2xl border border-slate-200/90 bg-white/95 p-6 md:p-7 shadow-md shadow-slate-200/50 ring-1 ring-white/60 transition-all duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-indigo-500/10 hover:border-indigo-200/70">
                    <div class="absolute inset-x-0 top-0 h-1 rounded-t-2xl bg-gradient-to-r from-indigo-500 via-violet-500 to-purple-500 opacity-90 group-hover:opacity-100" aria-hidden="true"></div>
                    <div class="mb-5 inline-flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-indigo-500 to-indigo-700 text-white shadow-lg shadow-indigo-500/35">
                        <i class="fas fa-user-shield text-lg" aria-hidden="true"></i>
                    </div>
                    <h3 class="font-bold text-lg text-slate-900 mb-2 tracking-tight">Multi‑Admin Access</h3>
                    <p class="text-slate-600 text-sm leading-relaxed flex-1">Add trusted family members to safely help log cash entries simultaneously from different counters during rush hour.</p>
                </div>
                <div class="group relative flex flex-col h-full rounded-2xl border border-slate-200/90 bg-white/95 p-6 md:p-7 shadow-md shadow-slate-200/50 ring-1 ring-white/60 transition-all duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-rose-500/10 hover:border-rose-200/70">
                    <div class="absolute inset-x-0 top-0 h-1 rounded-t-2xl bg-gradient-to-r from-rose-500 to-pink-500 opacity-90 group-hover:opacity-100" aria-hidden="true"></div>
                    <div class="mb-5 inline-flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-rose-500 to-pink-600 text-white shadow-lg shadow-rose-500/35">
                        <i class="fas fa-chart-pie text-lg" aria-hidden="true"></i>
                    </div>
                    <h3 class="font-bold text-lg text-slate-900 mb-2 tracking-tight">Analytics &amp; Insights</h3>
                    <p class="text-slate-600 text-sm leading-relaxed flex-1">Get real-time insights into top contributors, cash vs UPI breakdowns, and beautifully visualized collection metrics.</p>
                </div>
            </div>
        </div>
    </section>

    {{-- ===== TRUSTED BY MARQUEE ===== --}}
    <section class="bg-slate-900 border-y border-white/10 py-10 overflow-hidden">
        <div class="max-w-6xl mx-auto px-6 mb-8 text-center">
            <p class="text-xs font-bold uppercase tracking-[0.2em] text-indigo-400 mb-2">Trusted By</p>
            <h2 class="text-2xl md:text-3xl font-bold text-white">Hosts across India use Chandla Book</h2>
        </div>
        <style>
            .cb-marquee-track {
                display: flex;
                width: max-content;
                animation: cb-marquee-scroll 28s linear infinite;
            }
            .cb-marquee-track:hover { animation-play-state: paused; }
            @keyframes cb-marquee-scroll {
                0%   { transform: translateX(0); }
                100% { transform: translateX(-50%); }
            }
            .cb-marquee-logo {
                display: inline-flex;
                align-items: center;
                gap: 0.6rem;
                padding: 0.6rem 1.5rem;
                margin: 0 0.75rem;
                border-radius: 999px;
                background: rgba(255,255,255,0.05);
                border: 1px solid rgba(255,255,255,0.10);
                white-space: nowrap;
                filter: grayscale(100%) opacity(0.55);
                transition: filter 0.3s ease, background 0.3s ease;
                cursor: default;
            }
            .cb-marquee-logo:hover {
                filter: grayscale(0%) opacity(1);
                background: rgba(255,255,255,0.10);
            }
            .cb-marquee-logo-icon {
                width: 2rem; height: 2rem;
                border-radius: 8px;
                display: flex; align-items: center; justify-content: center;
                font-weight: 800; font-size: 0.75rem; color: #fff;
                flex-shrink: 0;
            }
            .cb-marquee-logo-name { font-size: 0.85rem; font-weight: 600; color: #e2e8f0; letter-spacing: 0.01em; }
        </style>
        <div class="relative">
            {{-- left/right fade gradients --}}
            <div class="pointer-events-none absolute left-0 top-0 h-full w-16 z-10 bg-gradient-to-r from-slate-900 to-transparent" aria-hidden="true"></div>
            <div class="pointer-events-none absolute right-0 top-0 h-full w-16 z-10 bg-gradient-to-l from-slate-900 to-transparent" aria-hidden="true"></div>
            <div class="overflow-hidden" aria-label="Companies using Chandla Book" role="list">
                <div class="cb-marquee-track">
                    @php
                    $cbLogos = [
                        ['name' => 'Mehta Events',    'bg' => '#4f46e5', 'init' => 'ME'],
                        ['name' => 'Sharma Caterers', 'bg' => '#0891b2', 'init' => 'SC'],
                        ['name' => 'Patel Mandaps',   'bg' => '#059669', 'init' => 'PM'],
                        ['name' => 'Royal Occasions', 'bg' => '#b45309', 'init' => 'RO'],
                        ['name' => 'Gupta Decors',    'bg' => '#7c3aed', 'init' => 'GD'],
                        ['name' => 'Joshi Weddings',  'bg' => '#db2777', 'init' => 'JW'],
                        ['name' => 'Verma & Sons',    'bg' => '#0f766e', 'init' => 'VS'],
                        ['name' => 'Agarwal Banquets','bg' => '#c2410c', 'init' => 'AB'],
                    ];
                    @endphp
                    @foreach(array_merge($cbLogos, $cbLogos) as $logo)
                        <div class="cb-marquee-logo" role="listitem">
                            <span class="cb-marquee-logo-icon" style="background:{{ $logo['bg'] }}">{{ $logo['init'] }}</span>
                            <span class="cb-marquee-logo-name">{{ $logo['name'] }}</span>
                        </div>
                    @endforeach
                </div>
            </div>
        </div>
    </section>

    {{-- ===== TESTIMONIALS (dark theme) ===== --}}
    <section class="bg-slate-950 text-white border-t border-white/10" style="padding-top:5rem;padding-bottom:5rem">
        <div class="max-w-6xl mx-auto px-6">
            <div class="text-center" style="margin-bottom:5rem">
                <p class="text-xs font-bold uppercase tracking-[0.2em] text-indigo-400 mb-4">Testimonials</p>
                <h2 class="text-3xl md:text-4xl font-bold text-white mb-5">Loved by hosts across India</h2>
                <p class="text-white/60 text-lg max-w-xl mx-auto">See how Chandla Book is transforming event collections.</p>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div class="bg-white/5 border border-white/10 p-8 rounded-2xl shadow-lg relative hover:-translate-y-1 transition-transform duration-300">
                    <div class="text-amber-400 mb-4 text-sm flex gap-1">
                        <i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i>
                    </div>
                    <p class="text-white/80 italic mb-6">"Managing chandla during my brother's wedding used to be a headache with notebooks. This app made it so simple to track every envelope and UPI payment. The PDF export saved us hours of calculation!"</p>
                    <div class="flex items-center gap-3">
                        <div class="w-10 h-10 rounded-full bg-indigo-600/70 text-indigo-100 flex items-center justify-center font-bold">R</div>
                        <div>
                            <div class="font-bold text-white text-sm">Rajesh Kumar</div>
                            <div class="text-xs text-white/50">Delhi</div>
                        </div>
                    </div>
                </div>
                <div class="bg-white/5 border border-white/10 p-8 rounded-2xl shadow-lg relative hover:-translate-y-1 transition-transform duration-300">
                    <div class="text-amber-400 mb-4 text-sm flex gap-1">
                        <i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i>
                    </div>
                    <p class="text-white/80 italic mb-6">"The Direct GPay feature is a game-changer. Guests could just scan and pay directly to my UPI, and it auto-updated in the ledger. No more matching transaction screenshots manually."</p>
                    <div class="flex items-center gap-3">
                        <div class="w-10 h-10 rounded-full bg-emerald-600/70 text-emerald-100 flex items-center justify-center font-bold">S</div>
                        <div>
                            <div class="font-bold text-white text-sm">Sneha Patel</div>
                            <div class="text-xs text-white/50">Ahmedabad</div>
                        </div>
                    </div>
                </div>
                <div class="bg-white/5 border border-white/10 p-8 rounded-2xl shadow-lg relative hover:-translate-y-1 transition-transform duration-300">
                    <div class="text-amber-400 mb-4 text-sm flex gap-1">
                        <i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i>
                    </div>
                    <p class="text-white/80 italic mb-6">"I got the Celebration pack for my daughter's reception. The invitation designs were stunning, and sharing them on WhatsApp was incredibly easy. Highly recommend for any Indian function."</p>
                    <div class="flex items-center gap-3">
                        <div class="w-10 h-10 rounded-full bg-rose-600/70 text-rose-100 flex items-center justify-center font-bold">A</div>
                        <div>
                            <div class="font-bold text-white text-sm">Amit Sharma</div>
                            <div class="text-xs text-white/50">Mumbai</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="bg-white text-slate-900">
        <div class="max-w-6xl mx-auto px-6 py-12">
            <h2 class="text-3xl font-bold mb-6">How it works</h2>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div class="p-6 rounded-2xl border bg-slate-50">
                    <div class="text-sm text-slate-500">Step 01</div>
                    <h3 class="font-semibold mb-2">Create Event</h3>
                    <p class="text-slate-600">Add date, venue, and event type in seconds.</p>
                </div>
                <div class="p-6 rounded-2xl border bg-slate-50">
                    <div class="text-sm text-slate-500">Step 02</div>
                    <h3 class="font-semibold mb-2">Collect Contributions</h3>
                    <p class="text-slate-600">Record Cash/Cover/Gift with exact note quantities.</p>
                </div>
                <div class="p-6 rounded-2xl border bg-slate-50">
                    <div class="text-sm text-slate-500">Step 03</div>
                    <h3 class="font-semibold mb-2">Report &amp; export</h3>
                    <p class="text-slate-600">Download event PDFs, email reports, and optional <strong>Direct GPay</strong> guest links when your plan includes them.</p>
                </div>
            </div>
        </div>
    </section>

    @include('partials.pricing-section')

    <section id="refer" class="bg-white text-slate-900 scroll-mt-20" style="padding-top:2rem;">
        <div class="max-w-6xl mx-auto px-6 py-12">
            <div class="text-center max-w-2xl mx-auto mb-10">
                <h2 class="text-3xl font-bold mb-2">Refer &amp; earn</h2>
                <p class="text-slate-600">When someone signs up with <strong>your code</strong> and later <strong>completes a qualifying payment</strong> (e.g. an upgrade in the app), you earn a reward — see below.</p>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-8 items-stretch">
                <div class="rounded-2xl border-2 border-indigo-200 bg-indigo-50/50 p-6 md:p-8">
                    <div class="flex items-center gap-3 mb-4">
                        <div class="h-12 w-12 rounded-xl bg-indigo-600 text-white flex items-center justify-center shadow">
                            <i class="fas fa-gift" aria-hidden="true"></i>
                        </div>
                        <h3 class="text-xl font-bold text-slate-900">What you receive</h3>
                    </div>
                    <p class="text-slate-700 leading-relaxed">If a <strong>referred user makes a payment</strong> (as defined in the app), the <strong>referrer is credited with <span class="text-indigo-700">1 free event</span></strong> that includes:</p>
                    <ul class="mt-4 space-y-2 text-slate-800 text-sm list-none">
                        <li class="flex gap-2"><i class="fas fa-check text-indigo-600 mt-0.5 shrink-0" aria-hidden="true"></i><span><strong>Unlimited chandla entries</strong> for that event (same class as a paid “unlimited” event)</span></li>
                        <li class="flex gap-2"><i class="fas fa-check text-indigo-600 mt-0.5 shrink-0" aria-hidden="true"></i><span><strong>Full event PDF</strong> — export, download, and email the complete report (per app support)</span></li>
                    </ul>
                    <p class="text-xs text-slate-500 mt-4">Eligibility, timing, and which payments count are confirmed in the app and may change; this is a plain-language summary.</p>
                </div>
                <div class="rounded-2xl border-2 border-indigo-200 bg-indigo-50/50 p-6 md:p-8">
                    <div class="flex items-center gap-3 mb-4">
                        <div class="h-12 w-12 rounded-xl bg-indigo-600 text-white flex items-center justify-center shadow shrink-0">
                            <i class="fas fa-share-nodes" aria-hidden="true"></i>
                        </div>
                        <h3 class="text-xl font-bold text-slate-900">Your referral code (after sign‑up)</h3>
                    </div>
                    <p class="text-slate-700 leading-relaxed mb-6">Log in to the client area — your code appears on the <strong>dashboard</strong> for you to copy and share.</p>
                    <div class="rounded-xl bg-white/60 p-5 border border-dashed border-indigo-300 text-center shadow-sm">
                        <div class="text-xs text-indigo-600 font-bold uppercase tracking-widest mb-2">Example format</div>
                        <div class="font-mono text-2xl text-indigo-900 font-bold tracking-wider">REF-8K2P7QX</div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    @include('partials.faq-section', ['faqFlush' => true])

    <section class="bg-indigo-600 text-white">
        <div class="max-w-6xl mx-auto px-6 py-10 flex flex-col md:flex-row items-center justify-between gap-6">
            <div>
                <h2 class="text-3xl font-bold">Create your first event today</h2>
                <p class="text-indigo-100 mt-2">Free: 1 event · 50 entries · Paid: Celebration ₹{{ number_format((float) config('landing.celebration_pack_inr', 300), 0) }} · Guest pay (1 event) ₹{{ number_format((float) config('landing.guest_pay_single_inr', 400), 0) }} · Host Duo ₹{{ number_format((float) config('landing.host_duo_pack_inr', 500), 0) }} · Complete host ₹{{ number_format((float) config('landing.premium_bundle_inr', 700), 0) }}. <a href="#faq" class="text-white font-medium underline decoration-white/50 hover:decoration-white">Read FAQs</a></p>
            </div>
            <a href="{{ route('client.register') }}" class="shrink-0 px-6 py-3 bg-white text-indigo-700 rounded-lg font-semibold shadow-lg hover:bg-indigo-50 transition-colors">
                Create free account
            </a>
        </div>
    </section>

    <footer class="bg-slate-950 text-white/70 border-t border-white/10">
        <div class="max-w-6xl mx-auto px-6 py-6 text-sm flex flex-col md:flex-row justify-between">
            <div>© {{ date('Y') }} Chandla Book. All rights reserved.</div>
            <div class="flex flex-wrap gap-4 justify-end">
                <a href="#features" class="hover:text-white">Features</a>
                <a href="#pricing" class="hover:text-white">Plans</a>
                <a href="#faq" class="hover:text-white">FAQ</a>
                <a href="{{ route('public.contact') }}" class="hover:text-white">Contact</a>
                <a href="{{ route('public.privacy') }}" class="hover:text-white">Privacy</a>
                <a href="{{ route('public.terms') }}" class="hover:text-white">Terms</a>
                <a href="{{ route('client.login') }}" class="hover:text-white">Login</a>
                <a href="{{ route('client.register') }}" class="hover:text-white">Register</a>
            </div>
        </div>
    </footer>
</body>
</html>
