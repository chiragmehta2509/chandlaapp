@extends('layouts.admin')

@section('title', 'Payment Details')

@section('content')
<div class="mb-6">
    <a href="{{ route('admin.payments.index') }}" class="text-indigo-600 hover:text-indigo-800 mb-4 inline-block">
        <i class="fas fa-arrow-left mr-2"></i>Back to Payments
    </a>
    <h1 class="text-3xl font-bold text-gray-800">Payment Details</h1>
</div>

<div class="bg-white rounded-lg shadow p-6 max-w-2xl">
    <div class="grid grid-cols-2 gap-6">
        <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Transaction ID</label>
            <p class="text-gray-900 font-mono">{{ $payment->transaction_id }}</p>
        </div>
        <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Order ID</label>
            <p class="text-gray-900 font-mono">{{ $payment->razorpay_order_id ?? 'N/A' }}</p>
        </div>
        <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">User</label>
            <p class="text-gray-900">{{ $payment->user->name }}</p>
        </div>
        <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Amount</label>
            <p class="text-gray-900 text-2xl font-bold">₹{{ number_format($payment->amount, 2) }}</p>
        </div>
        <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Status</label>
            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium 
                {{ $payment->status === 'completed' ? 'bg-green-100 text-green-800' : 
                   ($payment->status === 'failed' ? 'bg-red-100 text-red-800' : 'bg-yellow-100 text-yellow-800') }}">
                {{ ucfirst($payment->status) }}
            </span>
        </div>
        <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Payment Method</label>
            <p class="text-gray-900">{{ $payment->payment_method ?? 'UPI' }}</p>
        </div>
        <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Event</label>
            <p class="text-gray-900">{{ $payment->event->title ?? 'N/A' }}</p>
        </div>
        <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Payment type</label>
            <p class="text-gray-900">{{ $payment->metadata['type'] ?? '—' }}</p>
        </div>
        <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Plan / extra</label>
            <p class="text-gray-900">
                @if(data_get($payment->metadata, 'type') === 'direct_gpay_unlock')
                    <span class="text-violet-700">Direct GPay per event</span>
                    @if($payment->event)
                        — <strong>{{ $payment->event->title }}</strong>
                    @endif
                    — <strong>Mark Completed</strong> only after UPI is verified
                @elseif(data_get($payment->metadata, 'type') === 'matrimonial_plan')
                    @php $mp = data_get($payment->metadata, 'matrimonial_plan'); @endphp
                    <span class="text-rose-700">Find Partner (Matrimonial)</span>
                    @if($mp)
                        — plan <strong>{{ $mp }}</strong>
                        @if(config('matrimonial.plans.'.$mp.'.label')) ({{ config('matrimonial.plans.'.$mp.'.label') }}) @endif
                    @endif
                    — <strong>Mark Completed</strong> only after UPI amount is verified
                @else
                    {{ data_get($payment->metadata, 'plan') ?? (($invId = data_get($payment->metadata, 'marriage_invitation_id')) ? 'Marriage card #'.$invId : 'N/A') }}
                @endif
            </p>
        </div>
        <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Created At</label>
            <p class="text-gray-900">{{ $payment->created_at->format('M d, Y h:i A') }}</p>
        </div>
        <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Updated At</label>
            <p class="text-gray-900">{{ $payment->updated_at->format('M d, Y h:i A') }}</p>
        </div>
    </div>
    @if($payment->status === 'pending')
        <div class="mt-6 flex gap-2">
            <form method="POST" action="{{ route('admin.payments.verify', $payment->id) }}">
                @csrf
                <input type="hidden" name="status" value="completed">
                <button type="submit" class="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700">
                    Mark Completed
                </button>
            </form>
            <form method="POST" action="{{ route('admin.payments.verify', $payment->id) }}">
                @csrf
                <input type="hidden" name="status" value="failed">
                <button type="submit" class="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700">
                    Mark Failed
                </button>
            </form>
        </div>
    @endif
</div>
@endsection
