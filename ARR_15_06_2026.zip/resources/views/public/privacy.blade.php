<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Privacy policy for Chandla Book — how we handle account data and payments.">
    <meta name="robots" content="index, follow">
    <link rel="canonical" href="{{ url('/privacy') }}">
    <title>Privacy policy — Chandla Book</title>
    <link rel="stylesheet" href="{{ asset('css/tailwind.css') }}?v=2">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="min-h-screen bg-gradient-to-br from-indigo-950 via-purple-900 to-slate-950 text-white">
    <header class="max-w-3xl mx-auto px-6 py-6 flex items-center justify-between">
        <a href="{{ route('public.home') }}" class="flex items-center gap-2 text-white font-semibold hover:text-white/90">
            <img src="{{ asset('images/chandla-favicon.png') }}" alt="Chandla Book" width="36" height="36" class="h-9 w-auto">
            Chandla Book
        </a>
        <a href="{{ route('public.home') }}" class="text-sm text-white/75 hover:text-white">← Home</a>
    </header>

    <article class="max-w-3xl mx-auto px-6 pb-16 text-white/90 leading-relaxed">
        <h1 class="text-3xl font-bold text-white mb-6">Privacy policy</h1>
        <p class="text-sm text-white/60 mb-8">Last updated {{ date('F j, Y') }}. This summary describes typical practices for this service; refine with your lawyer for your jurisdiction.</p>

        <section class="space-y-6 text-sm sm:text-base">
            <div>
                <h2 class="text-lg font-semibold text-white mb-2">What we collect</h2>
                <p class="text-white/85">Account details you provide (such as name, email, and phone), event and ledger information you enter, payment-related identifiers needed to operate features, and technical logs needed for security and reliability.</p>
            </div>
            <div>
                <h2 class="text-lg font-semibold text-white mb-2">Payments</h2>
                <p class="text-white/85">Online payments may be processed by Razorpay or similar providers. Card and UPI details are handled according to those providers’ policies; we typically receive confirmation metadata needed to unlock paid features—not full card numbers.</p>
            </div>
            <div>
                <h2 class="text-lg font-semibold text-white mb-2">How we use information</h2>
                <p class="text-white/85">To run the service (accounts, events, ledger, exports), communicate with you about your account, prevent fraud or abuse, and comply with applicable law.</p>
            </div>
            <div>
                <h2 class="text-lg font-semibold text-white mb-2">Retention</h2>
                <p class="text-white/85">We keep data as long as your account is active and as needed for legal, accounting, or dispute purposes. You may request deletion of personal data subject to lawful exceptions.</p>
            </div>
            <div>
                <h2 class="text-lg font-semibold text-white mb-2">Contact</h2>
                @php
                    $privacyMail = trim((string) config('chandlabook.support_email', ''));
                    if ($privacyMail === '') {
                        $privacyMail = (string) config('mail.from.address', '');
                    }
                @endphp
                @if ($privacyMail !== '')
                    <p class="text-white/85">Questions: <a href="mailto:{{ $privacyMail }}" class="text-amber-200 underline hover:text-white">{{ $privacyMail }}</a></p>
                @else
                    <p class="text-white/85">Questions: use the contact option shown on the marketing site or in-app once support email is configured.</p>
                @endif
            </div>
        </section>

        <p class="mt-10 text-xs text-white/50">
            <a href="{{ route('public.terms') }}" class="underline hover:text-white/80">Terms of use</a>
            <span class="mx-2">·</span>
            <a href="{{ route('public.home') }}" class="underline hover:text-white/80">Home</a>
        </p>
    </article>
</body>
</html>
