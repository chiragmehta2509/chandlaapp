@php
    $seoTitle = 'Chandla Book — Event chandla ledger & guest payments';
    $seoDesc = 'Chandla Book — cash, cover, gift & UPI ledger for Indian events. Free tier, Celebration pack, Guest pay (one event), Host Duo, Complete host. PDFs, inventory, Direct GPay to your UPI.';
    $ogImage = asset('images/chandla-logo.png');
@endphp
<link rel="canonical" href="{{ url('/') }}">
<meta property="og:type" content="website">
<meta property="og:url" content="{{ url('/') }}">
<meta property="og:title" content="{{ $seoTitle }}">
<meta property="og:description" content="{{ $seoDesc }}">
<meta property="og:image" content="{{ $ogImage }}">
<meta property="og:locale" content="en_IN">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="{{ $seoTitle }}">
<meta name="twitter:description" content="{{ $seoDesc }}">
<meta name="twitter:image" content="{{ $ogImage }}">
