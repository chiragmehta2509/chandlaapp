@php
    $celebrationInr = number_format((float) config('landing.celebration_pack_inr', 300), 0);
    $guestPayInr = number_format((float) config('landing.guest_pay_single_inr', 400), 0);
    $hostDuoInr = number_format((float) config('landing.host_duo_pack_inr', 500), 0);
    $premiumInr = number_format((float) config('landing.premium_bundle_inr', 700), 0);
    $dgUnlockInr = number_format((float) config('services.direct_gpay_unlock.amount', 400), 0);

    $faqPairs = [
        [
            'q' => "What’s in the ₹{$celebrationInr} celebration pack?",
            'a' => 'It bundles 10 marriage invitation layouts (save PNG / print), one video export for sharing, and the pre‑wedding countdown studio with downloadable cards per milestone. It does not by itself raise your chandla entry cap past the free 50 — upgrade the ledger separately if you need more gift entries.',
        ],
        [
            'q' => "What is the Guest pay pack (₹{$guestPayInr})?",
            'a' => 'One payment adds a credit on your account. In the client app, open Unlock Direct QR for one event and apply the credit. That event gets Direct GPay (your UPI / QR, pay‑to‑you link for any amount), unlimited chandla rows for that event only, and full event PDF. It does not include invitation / pre‑wedding studio.',
        ],
        [
            'q' => "What is the Host Duo pack (₹{$hostDuoInr})?",
            'a' => 'It unlocks two events on your account with unlimited chandla entries and normal PDF export — without the marriage invitation, video, or pre‑wedding studio (those stay in the Celebration / Complete host packs).',
        ],
        [
            'q' => "What does the Complete host pack (₹{$premiumInr}) include?",
            'a' => 'It includes everything in the Celebration pack, 3 events on your account, account-wide unlimited chandla (same class as Host Duo for the ledger), and full event PDF workflows. You can still buy Guest pay credits or use the in-app Direct GPay unlock (currently ₹'.$dgUnlockInr.' per event) when you need pay-to-you QR on extra events.',
        ],
        [
            'q' => 'How does “Direct GPay / pay to you” work?',
            'a' => 'For an event you add your UPI or an uploaded static QR. We generate a dedicated scannable pay QR and link so guests pay you directly (they choose the amount), and the app records the line in your ledger. Unlock either with the in‑app per‑event fee or a ₹'.$guestPayInr.' Guest pay pack credit.',
        ],
        [
            'q' => 'When do I get a referral reward?',
            'a' => 'When your referred contact completes a qualifying payment in the app, you can receive a free event with unlimited entries + full PDF — as described in the Refer & earn section on this page.',
        ],
    ];

    $faqEntities = [];
    foreach ($faqPairs as $pair) {
        $faqEntities[] = [
            '@type' => 'Question',
            'name' => $pair['q'],
            'acceptedAnswer' => [
                '@type' => 'Answer',
                'text' => $pair['a'],
            ],
        ];
    }

    $schema = [
        '@context' => 'https://schema.org',
        '@graph' => [
            [
                '@type' => 'Organization',
                'name' => 'Chandla Book',
                'url' => url('/'),
                'logo' => asset('images/chandla-logo.png'),
                'description' => 'Cash, cover, gift & UPI ledger for Indian events — PDFs, inventory, Direct GPay.',
            ],
            [
                '@type' => 'FAQPage',
                'mainEntity' => $faqEntities,
            ],
        ],
    ];
@endphp
<script type="application/ld+json">
{!! json_encode($schema, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT) !!}
</script>
