<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Terms of use for Chandla Book — acceptable use and limitations of the service.">
    <meta name="robots" content="index, follow">
    <link rel="canonical" href="{{ url('/terms') }}">
    <title>Terms of use — Chandla Book</title>
    <link rel="stylesheet" href="{{ asset('css/tailwind.css') }}?v=2">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="min-h-screen bg-gradient-to-br from-indigo-950 via-purple-900 to-slate-950 text-white">
    <header class="max-w-3xl mx-auto px-6 py-6 flex items-center justify-between">
        <a href="{{ route('public.home') }}" class="flex items-center gap-2 text-white font-semibold hover:text-white/90">
            <img src="{{ asset('images/chandla-favicon.png') }}" alt="Chandla Book" width="36" height="36" class="h-9 w-auto">
            Chandla Book
        </a>
        <a href="{{ route('public.home') }}" class="text-sm text-white/75 hover:text-white">← Home</a>
    </header>

    <article class="max-w-3xl mx-auto px-6 pb-16 text-white/90 leading-relaxed">
        <h1 class="text-3xl font-bold text-white mb-6">Terms of use</h1>
        <p class="text-sm text-white/60 mb-8">Last updated {{ date('F j, Y') }}. Plain-language summary; replace or extend with counsel-approved terms for production.</p>

        <section class="space-y-6 text-sm sm:text-base">
            <div>
                <h2 class="text-lg font-semibold text-white mb-2">The service</h2>
                <p class="text-white/85">Chandla Book provides tools to manage event collections and related workflows &quot;as is&quot;. Features and pricing may evolve; material changes will be communicated where practical.</p>
            </div>
            <div>
                <h2 class="text-lg font-semibold text-white mb-2">Your responsibilities</h2>
                <p class="text-white/85">You are responsible for the accuracy of information you enter, compliance with applicable laws (including tax and financial reporting), and safekeeping of account credentials.</p>
            </div>
            <div>
                <h2 class="text-lg font-semibold text-white mb-2">Acceptable use</h2>
                <p class="text-white/85">Do not misuse the service for fraud, harassment, unlawful activity, or attempts to compromise security or other users’ data.</p>
            </div>
            <div>
                <h2 class="text-lg font-semibold text-white mb-2">Limitation of liability</h2>
                <p class="text-white/85">To the extent permitted by law, the service is provided without warranties of uninterrupted or error-free operation. Liability is limited as permitted by applicable law.</p>
            </div>
            <div>
                <h2 class="text-lg font-semibold text-white mb-2">Contact</h2>
                @php
                    $termsMail = trim((string) config('chandlabook.support_email', ''));
                    if ($termsMail === '') {
                        $termsMail = (string) config('mail.from.address', '');
                    }
                @endphp
                @if ($termsMail !== '')
                    <p class="text-white/85">Questions: <a href="mailto:{{ $termsMail }}" class="text-amber-200 underline hover:text-white">{{ $termsMail }}</a></p>
                @else
                    <p class="text-white/85">Questions: configure support email in application settings.</p>
                @endif
            </div>
        </section>

        <p class="mt-10 text-xs text-white/50">
            <a href="{{ route('public.privacy') }}" class="underline hover:text-white/80">Privacy policy</a>
            <span class="mx-2">·</span>
            <a href="{{ route('public.home') }}" class="underline hover:text-white/80">Home</a>
        </p>
    </article>
</body>
</html>
