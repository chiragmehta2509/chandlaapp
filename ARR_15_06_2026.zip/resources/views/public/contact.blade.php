@extends('layouts.public-guest')

@section('omit_footer_marketing_link')
@endsection

@push('head')
<meta name="description" content="Contact Chandla Book — phone and email for billing, Razorpay packs, and product questions.">
<meta name="robots" content="index, follow">
<link rel="canonical" href="{{ url('/contact') }}">
@endpush

@section('page_title', 'Contact us — Chandla Book')

@section('content')
@php
    $supportEmail = trim((string) config('chandlabook.support_email', ''));
    if ($supportEmail === '') {
        $supportEmail = trim((string) config('mail.from.address', ''));
    }
    $supportPhone = trim((string) config('chandlabook.support_phone', ''));
    $phoneDigits = $supportPhone !== '' ? preg_replace('/\D/', '', $supportPhone) : '';
    $telUri = $phoneDigits !== '' ? 'tel:+' . $phoneDigits : '#';
    $hasContact = true;
@endphp

<div class="max-w-4xl mx-auto pt-2">
    <p class="inline-flex items-center gap-2 rounded-full bg-white/10 px-3 py-1 text-[0.65rem] font-bold uppercase tracking-[0.18em] text-white/90 ring-1 ring-white/15 mb-4">
        <i class="fa-solid fa-headset text-amber-300" aria-hidden="true"></i>
        We're here to help
    </p>
    <h1 class="text-3xl sm:text-4xl font-bold text-white tracking-tight mb-3">
        Contact us
    </h1>
    <p class="text-white/75 text-sm sm:text-base leading-relaxed mb-8">
        Billing, Razorpay packs, ledger questions, or invites — reach us on phone or email and we’ll point you in the right direction.
    </p>

    @if($hasContact)
        <div class="rounded-2xl border border-white/15 bg-white/[0.06] backdrop-blur-sm p-5 sm:p-6 shadow-xl shadow-black/20">
            <p class="text-center text-[0.65rem] font-bold uppercase tracking-[0.2em] text-indigo-200 mb-6">Get in touch</p>
            <ul class="grid sm:grid-cols-2 gap-4">
                @if($supportPhone !== '')
                    <li>
                        <a
                            href="{{ $telUri }}"
                            class="group flex gap-4 rounded-xl border border-white/15 bg-white/[0.08] p-4 transition hover:bg-white/[0.12] hover:border-amber-400/35 focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-300/70 focus-visible:ring-offset-2 focus-visible:ring-offset-indigo-950"
                        >
                            <span class="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-amber-500 to-orange-600 text-white shadow-lg shadow-orange-900/40">
                                <i class="fa-solid fa-phone" aria-hidden="true"></i>
                            </span>
                            <span class="min-w-0 flex-1 pt-0.5">
                                <span class="block text-[0.65rem] font-bold uppercase tracking-wider text-white/55 mb-0.5">Call us</span>
                                <span class="block text-lg font-bold text-white tabular-nums whitespace-nowrap">{{ $supportPhone }}</span>
                                <span class="mt-1 text-xs font-semibold text-emerald-300/95">Tap to dial</span>
                            </span>
                            <span class="hidden sm:flex shrink-0 items-center text-white/30 group-hover:text-amber-300">
                                <i class="fa-solid fa-chevron-right" aria-hidden="true"></i>
                            </span>
                        </a>
                    </li>
                @endif
                @if($supportEmail !== '')
                    <li>
                        <a
                            href="mailto:{{ $supportEmail }}"
                            class="group flex gap-4 rounded-xl border border-white/15 bg-white/[0.08] p-4 transition hover:bg-white/[0.12] hover:border-indigo-300/35 focus:outline-none focus-visible:ring-2 focus-visible:ring-indigo-300/70 focus-visible:ring-offset-2 focus-visible:ring-offset-indigo-950"
                        >
                            <span class="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-indigo-500 to-slate-700 text-white shadow-lg shadow-indigo-950/40">
                                <i class="fa-solid fa-envelope" aria-hidden="true"></i>
                            </span>
                            <span class="min-w-0 flex-1 pt-0.5">
                                <span class="block text-[0.65rem] font-bold uppercase tracking-wider text-white/55 mb-0.5">Email</span>
                                <span class="block text-base font-bold text-white truncate">{{ $supportEmail }}</span>
                                <span class="mt-1 text-xs font-semibold text-indigo-200">Opens your mail app</span>
                            </span>
                            <span class="hidden sm:flex shrink-0 items-center text-white/30 group-hover:text-indigo-200">
                                <i class="fa-solid fa-chevron-right" aria-hidden="true"></i>
                            </span>
                        </a>
                    </li>
                @endif
                <li>
                    <a
                        href="tel:+918200067737"
                        class="group flex gap-4 rounded-xl border border-white/15 bg-white/[0.08] p-4 transition hover:bg-white/[0.12] hover:border-amber-400/35 focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-300/70 focus-visible:ring-offset-2 focus-visible:ring-offset-indigo-950"
                    >
                        <span class="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-amber-500 to-orange-600 text-white shadow-lg shadow-orange-900/40">
                            <i class="fa-solid fa-phone" aria-hidden="true"></i>
                        </span>
                        <span class="min-w-0 flex-1 pt-0.5">
                            <span class="block text-[0.65rem] font-bold uppercase tracking-wider text-white/55 mb-0.5">Call us (Alternative)</span>
                            <span class="block text-lg font-bold text-white tabular-nums whitespace-nowrap">+91 8200067737</span>
                            <span class="mt-1 text-xs font-semibold text-emerald-300/95">Tap to dial</span>
                        </span>
                        <span class="hidden sm:flex shrink-0 items-center text-white/30 group-hover:text-amber-300">
                            <i class="fa-solid fa-chevron-right" aria-hidden="true"></i>
                        </span>
                    </a>
                </li>
                <li>
                    <a
                        href="mailto:info.ksky@gmail.com"
                        class="group flex gap-4 rounded-xl border border-white/15 bg-white/[0.08] p-4 transition hover:bg-white/[0.12] hover:border-indigo-300/35 focus:outline-none focus-visible:ring-2 focus-visible:ring-indigo-300/70 focus-visible:ring-offset-2 focus-visible:ring-offset-indigo-950"
                    >
                        <span class="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-indigo-500 to-slate-700 text-white shadow-lg shadow-indigo-950/40">
                            <i class="fa-solid fa-envelope" aria-hidden="true"></i>
                        </span>
                        <span class="min-w-0 flex-1 pt-0.5">
                            <span class="block text-[0.65rem] font-bold uppercase tracking-wider text-white/55 mb-0.5">Email (Alternative)</span>
                            <span class="block text-base font-bold text-white truncate">info.ksky@gmail.com</span>
                            <span class="mt-1 text-xs font-semibold text-indigo-200">Opens your mail app</span>
                        </span>
                        <span class="hidden sm:flex shrink-0 items-center text-white/30 group-hover:text-indigo-200">
                            <i class="fa-solid fa-chevron-right" aria-hidden="true"></i>
                        </span>
                    </a>
                </li>
            </ul>
        </div>
    @else
        <div class="rounded-2xl border border-amber-400/25 bg-amber-500/10 px-5 py-6 text-center">
            <span class="mx-auto mb-3 flex h-11 w-11 items-center justify-center rounded-xl bg-amber-400/20 text-amber-200">
                <i class="fa-solid fa-screwdriver-wrench" aria-hidden="true"></i>
            </span>
            <p class="font-semibold text-white">Contact details not configured</p>
            <p class="mt-2 text-sm text-white/75 leading-relaxed">
                Add <span class="font-mono text-xs bg-white/10 px-1.5 py-0.5 rounded">CHANDLABOOK_SUPPORT_EMAIL</span> and/or <span class="font-mono text-xs bg-white/10 px-1.5 py-0.5 rounded">CHANDLABOOK_SUPPORT_PHONE</span> in your environment.
            </p>
        </div>
    @endif

    <div class="mt-8 rounded-xl border border-white/10 bg-white/[0.04] px-4 py-4 text-sm text-white/70 leading-relaxed">
        <p class="font-semibold text-white/90 mb-2">Before you reach out</p>
        <p>
            Many answers live on our
            <a href="{{ url('/#faq') }}" class="font-semibold text-white underline decoration-white/35 underline-offset-2 hover:decoration-amber-300/80">FAQ</a>.
            For packs and pricing, see
            <a href="{{ url('/#pricing') }}" class="font-semibold text-white underline decoration-white/35 underline-offset-2 hover:decoration-amber-300/80">Plans</a>.
        </p>
    </div>

    @auth
        <p class="mt-8 text-center text-sm text-white/55">
            Signed in?
            <a href="{{ route('client.contact') }}" class="font-semibold text-white underline hover:text-amber-200">Account contact page</a>
        </p>
    @endauth
</div>
@endsection
