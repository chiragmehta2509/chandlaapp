@extends('layouts.client')

@section('title', 'Unlock Direct GPay — ' . $event->title)

@section('content')
<div class="mb-6">
    <a href="{{ route('client.events.index') }}" class="cb-link text-sm inline-flex items-center gap-2 mb-2">← Back to events</a>
    <h1 class="cb-page-title">Direct GPay for this event</h1>
    <p class="text-base font-semibold text-cb-navy mb-1">{{ $event->title }}</p>
    <p class="cb-subtitle">₹{{ number_format($amount, 0) }} one-time for <strong>this</strong> event — or use a <strong>₹{{ number_format($guestPayPackInr, 0) }} Guest pay pack</strong> credit if you already bought that plan. After unlock, add your UPI or QR; guests can pay <strong>any amount</strong> to you via the generated link / QR.</p>
</div>

@if ($errors->has('pack'))
    <div class="cb-alert cb-alert--error mb-4 max-w-2xl" role="alert">{{ $errors->first('pack') }}</div>
@endif

@if(($guestPayPackCredits ?? 0) > 0)
    <div class="cb-card p-5 sm:p-6 max-w-2xl mb-6 border-2 border-amber-200 bg-amber-50/80">
        <h2 class="text-lg font-bold text-cb-navy mb-2">Use Guest pay pack credit</h2>
        <p class="text-sm text-slate-700 mb-4">You have <strong>{{ (int) $guestPayPackCredits }}</strong> credit{{ (int) $guestPayPackCredits === 1 ? '' : 's' }}. Applying uses <strong>one</strong> credit for <strong>this</strong> event: Direct GPay unlock, <strong>unlimited chandla</strong> for this event, and full event PDF.</p>
        <form method="POST" action="{{ route('client.events.direct-gpay-unlock.redeem-guest-pay-pack', $event) }}" class="inline">
            @csrf
            <button type="submit" class="cb-btn bg-amber-600 hover:bg-amber-700 text-white border-0 w-full sm:w-auto min-h-[2.75rem] touch-manipulation">
                Apply 1 pack credit to this event
            </button>
        </form>
    </div>
@endif

@if(!empty($keyId))
    <div class="cb-card p-5 sm:p-6 max-w-2xl mb-6">
        <h2 class="text-lg font-bold text-cb-navy mb-2">Pay with Razorpay</h2>
        <p class="text-sm text-slate-600 mb-4">Card, UPI, netbanking, or wallets. Your event unlocks as soon as payment is confirmed. (Pack buyers: pay ₹{{ number_format($guestPayPackInr, 0) }} on the site first, then use “Apply pack credit” above.)</p>
        <button type="button" id="rzp-dgpay-btn" class="cb-btn cb-btn-navy w-full sm:w-auto min-h-[2.75rem] touch-manipulation">
            Pay ₹{{ number_format($amount, 0) }} with Razorpay
        </button>
    </div>

    <form id="rzp-dgpay-verify-form" method="POST" action="{{ route('client.events.direct-gpay-unlock.razorpay.verify', $event) }}" class="hidden">
        @csrf
        <input type="hidden" name="razorpay_order_id" id="rzp-dgpay-oid" value="">
        <input type="hidden" name="razorpay_payment_id" id="rzp-dgpay-pid" value="">
        <input type="hidden" name="razorpay_signature" id="rzp-dgpay-sig" value="">
    </form>
@else
    <div class="mt-4 cb-alert cb-alert--error" role="alert">Razorpay is not configured. Add <code class="text-xs">RAZORPAY_KEY_ID</code> and <code class="text-xs">RAZORPAY_KEY_SECRET</code> in <code class="text-xs">.env</code>.</div>
@endif

{{-- Manual UPI (QR + admin verification) — replaced by Razorpay above; uncomment only if you restore that flow
<div class="grid grid-cols-1 lg:grid-cols-2 gap-6 max-w-5xl">
    <div class="cb-card p-5 sm:p-6">
        <h2 class="text-lg font-bold text-cb-navy mb-4">Pay with UPI</h2>
        ...
    </div>
    <div class="cb-card p-5 sm:p-6">
        <h2 class="text-lg font-bold text-cb-navy mb-4">Submit transaction ID</h2>
        ...
    </div>
</div>
--}}
@endsection

@push('scripts')
@if(!empty($keyId))
<script src="https://checkout.razorpay.com/v1/checkout.js"></script>
<script>
(function () {
    var orderUrl = @json(route('client.events.direct-gpay-unlock.razorpay.order', $event));
    var token = @json(csrf_token());
    var name = @json(Auth::user()->name ?? 'Organizer');
    var email = @json(Auth::user()->email ?? '');
    var btn = document.getElementById('rzp-dgpay-btn');
    if (!btn) return;
    var originalHtml = btn.innerHTML;
    btn.addEventListener('click', function () {
        btn.disabled = true;
        btn.setAttribute('aria-busy', 'true');
        btn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i> Opening checkout…';
        fetch(orderUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                'X-CSRF-TOKEN': token,
                'X-Requested-With': 'XMLHttpRequest',
            },
            body: JSON.stringify({}),
        })
        .then(function (r) { return r.json().then(function (j) { return { ok: r.ok, j: j }; }); })
        .then(function (res) {
            if (!res.ok) {
                btn.disabled = false;
                btn.removeAttribute('aria-busy');
                btn.innerHTML = originalHtml;
                alert(res.j.message || 'Could not start payment.');
                return;
            }
            btn.disabled = false;
            btn.removeAttribute('aria-busy');
            btn.innerHTML = originalHtml;
            var opt = {
                key: res.j.key_id,
                order_id: res.j.order_id,
                amount: res.j.amount,
                currency: 'INR',
                name: 'Chandla Book',
                description: 'Direct GPay unlock — ' + @json($event->title),
                prefill: { name: name, email: email },
                theme: { color: '#1A3646' },
                handler: function (response) {
                    document.getElementById('rzp-dgpay-oid').value = response.razorpay_order_id;
                    document.getElementById('rzp-dgpay-pid').value = response.razorpay_payment_id;
                    document.getElementById('rzp-dgpay-sig').value = response.razorpay_signature;
                    document.getElementById('rzp-dgpay-verify-form').submit();
                },
            };
            var rzp = new Razorpay(opt);
            rzp.open();
        })
        .catch(function () {
            btn.disabled = false;
            btn.removeAttribute('aria-busy');
            btn.innerHTML = originalHtml;
            alert('Network error. Try again.');
        });
    });
})();
</script>
@endif
@endpush
