@extends('layouts.client')

@section('title', 'Plans & pricing')

@section('content')
<div class="space-y-8 sm:space-y-10 pb-8 w-full min-w-0 max-w-full overflow-x-hidden">
    {{-- Hero --}}
    <div class="cb-card cb-card--hero relative overflow-hidden p-6 sm:p-8 lg:p-10">
        <div class="pointer-events-none absolute -right-24 -top-28 h-72 w-72 rounded-full bg-violet-500/25 blur-3xl" aria-hidden="true"></div>
        <div class="pointer-events-none absolute -bottom-32 -left-16 h-64 w-64 rounded-full bg-amber-400/15 blur-3xl" aria-hidden="true"></div>
        <div class="pointer-events-none absolute top-1/2 left-1/2 h-48 w-full max-w-4xl -translate-x-1/2 -translate-y-1/2 bg-[radial-gradient(ellipse_at_center,rgba(251,191,36,0.08),transparent_65%)]" aria-hidden="true"></div>

        <div class="relative grid gap-8 lg:grid-cols-[minmax(0,1fr)_auto] lg:items-end lg:gap-10">
            <div class="min-w-0">
                <p class="mb-4 inline-flex items-center gap-2 rounded-full bg-white/10 px-3 py-1.5 text-[0.65rem] font-bold uppercase tracking-[0.18em] text-indigo-100 ring-1 ring-white/15 backdrop-blur-sm sm:text-xs">
                    <i class="fa-solid fa-wand-magic-sparkles text-amber-300" aria-hidden="true"></i>
                    Upgrade anytime · Razorpay
                </p>
                <h1 class="text-[1.65rem] font-bold leading-[1.15] tracking-tight text-white sm:text-3xl lg:text-4xl">
                    Plans built for weddings &amp; celebrations
                </h1>
                <p class="mt-4 max-w-xl text-sm leading-relaxed text-indigo-100/88 sm:text-base">
                    Compare packs below, then pay in one tap. Use the <strong class="font-semibold text-white">same email or phone</strong> as this account so credits unlock right after checkout.
                </p>

                <div class="mt-6 flex flex-wrap gap-2.5">
                    <span class="inline-flex items-center gap-2 rounded-xl bg-emerald-500/15 px-3 py-2 text-xs font-semibold text-emerald-50 ring-1 ring-emerald-400/35 backdrop-blur-[2px]">
                        <i class="fa-solid fa-shield-halved text-emerald-300" aria-hidden="true"></i>
                        Secure checkout
                    </span>
                    <span class="inline-flex items-center gap-2 rounded-xl bg-white/10 px-3 py-2 text-xs font-semibold text-white/95 ring-1 ring-white/15 backdrop-blur-[2px]">
                        <i class="fa-solid fa-bolt text-amber-300" aria-hidden="true"></i>
                        Instant unlock on payment
                    </span>
                    <span class="inline-flex items-center gap-2 rounded-xl bg-white/10 px-3 py-2 text-xs font-semibold text-white/95 ring-1 ring-white/15 backdrop-blur-[2px]">
                        <i class="fa-solid fa-table-columns text-indigo-200" aria-hidden="true"></i>
                        Ledger · invites · Direct GPay
                    </span>
                </div>
            </div>

            <div class="flex flex-col gap-3 sm:flex-row lg:flex-col lg:min-w-[13.5rem]">
                <a
                    href="#pricing"
                    class="cb-btn cb-btn--gold cb-btn--sm justify-center shadow-lg shadow-amber-900/30 lg:py-3"
                >
                    <i class="fa-solid fa-arrow-down" aria-hidden="true"></i>
                    View packs
                </a>
                <a
                    href="{{ route('client.contact') }}"
                    class="inline-flex items-center justify-center gap-2 rounded-xl border border-white/25 bg-white/5 px-4 py-2.5 text-sm font-semibold text-white backdrop-blur-sm transition hover:bg-white/12 focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-300/60"
                >
                    <i class="fa-solid fa-headset text-amber-200/90" aria-hidden="true"></i>
                    Talk to us
                </a>
                <a
                    href="{{ route('client.faq') }}"
                    class="inline-flex items-center justify-center gap-2 rounded-xl px-4 py-2 text-sm font-medium text-indigo-100/85 transition hover:text-white hover:underline decoration-white/35 underline-offset-4 lg:justify-start lg:px-4 lg:py-1"
                >
                    Common questions
                    <i class="fa-solid fa-arrow-right text-[0.65rem] opacity-80" aria-hidden="true"></i>
                </a>
            </div>
        </div>
    </div>

    {{-- Pricing surface --}}
    <div class="relative w-full min-w-0 max-w-full">
        <div class="pointer-events-none absolute inset-x-0 -top-10 mx-auto h-48 max-w-3xl rounded-full bg-gradient-to-r from-indigo-400/20 via-amber-300/15 to-teal-400/20 blur-3xl" aria-hidden="true"></div>
        <div class="relative w-full min-w-0 max-w-full rounded-[1.65rem] bg-gradient-to-br from-white via-indigo-50/40 to-amber-50/35 p-[1px] shadow-[0_28px_70px_-18px_rgba(26,54,70,0.28)] ring-1 ring-slate-200/70">
            <div class="rounded-[1.6rem] bg-white/85 backdrop-blur-md overflow-hidden w-full min-w-0 max-w-full">
                @include('partials.pricing-section', [
                    'pricingInset' => false,
                    'pricingNestClient' => true,
                    'pricingInnerClass' => 'py-10 sm:py-12 lg:py-14',
                ])
            </div>
        </div>
    </div>

    {{-- Bottom reassurance --}}
    <div class="cb-card relative overflow-hidden border border-[var(--cb-border)] p-5 sm:p-6 lg:flex lg:items-center lg:justify-between lg:gap-8">
        <div class="pointer-events-none absolute -right-16 top-0 h-40 w-40 rounded-full bg-[var(--cb-gold)]/8 blur-2xl" aria-hidden="true"></div>
        <div class="relative min-w-0">
            <p class="text-base font-bold text-[var(--cb-navy)]">Not sure which pack fits?</p>
            <p class="mt-1.5 text-sm leading-relaxed text-slate-600 max-w-lg">
                Start free with one event, or grab <strong class="font-semibold text-slate-800">Celebration</strong> for invites &amp; pre-wedding, <strong class="font-semibold text-slate-800">Guest pay</strong> for Direct UPI on one event, or <strong class="font-semibold text-slate-800">Complete host</strong> for the full bundle.
            </p>
        </div>
        <div class="relative mt-5 flex flex-wrap gap-2 lg:mt-0 lg:shrink-0">
            <a href="{{ route('client.faq') }}" class="cb-btn cb-btn--navy cb-btn--sm">
                <i class="fa-regular fa-circle-question" aria-hidden="true"></i>
                FAQ
            </a>
            <a href="{{ route('client.contact') }}" class="cb-btn cb-btn--ghost cb-btn--sm">
                Contact us
            </a>
        </div>
    </div>
</div>
@endsection
