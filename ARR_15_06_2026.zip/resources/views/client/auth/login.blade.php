<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Chandla Book</title>
    <link rel="stylesheet" href="{{ asset('css/tailwind.css') }}?v=2">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="min-h-screen bg-slate-950 text-white">
    <div class="min-h-screen bg-gradient-to-br from-indigo-950 via-purple-900 to-slate-950 flex flex-col">
        <header class="max-w-6xl w-full mx-auto px-4 sm:px-6 py-4 flex items-center justify-between">
            <a href="{{ route('public.home') }}" class="flex items-center gap-2 sm:gap-3 group">
                <img src="{{ asset('images/chandla-favicon.png') }}" alt="Chandla Book" class="h-10 sm:h-12 w-auto">
                <span class="text-lg sm:text-2xl font-bold text-white group-hover:text-white/90">Chandla Book</span>
            </a>
            <a href="{{ route('public.home') }}" class="text-sm text-white/80 hover:text-white font-medium">
                ← Home
            </a>
        </header>

        <div class="flex-1 flex items-center justify-center px-4 py-8 sm:py-12">
            <div class="w-full max-w-md">
                <div class="bg-white/10 backdrop-blur-md rounded-2xl border border-white/20 p-6 sm:p-8 shadow-xl">
                    <div class="text-center mb-8">
                        <h1 class="text-2xl sm:text-3xl font-bold text-white">Welcome back</h1>
                        <p class="text-white/70 mt-2 text-sm sm:text-base">Sign in to your account</p>
                    </div>

                    @if($errors->any())
                        <div class="mb-4 rounded-lg border border-red-400/50 bg-red-500/20 px-4 py-3 text-sm text-red-100">
                            <ul class="list-disc list-inside space-y-1">
                                @foreach($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                        </div>
                    @endif
                    @if(session('status'))
                        <div class="mb-4 rounded-lg border border-emerald-400/50 bg-emerald-500/20 px-4 py-3 text-sm text-emerald-100">
                            {{ session('status') }}
                        </div>
                    @endif

                    <form method="POST" action="{{ route('client.login') }}">
                        @csrf
                        <div class="mb-5">
                            <label class="block text-sm font-medium text-white/80 mb-2" for="login">Email or phone</label>
                            <input
                                class="w-full rounded-xl border border-white/20 bg-white/10 px-4 py-3 text-white placeholder:text-white/40 focus:border-indigo-400/60 focus:outline-none focus:ring-2 focus:ring-indigo-500/40"
                                id="login"
                                type="text"
                                name="login"
                                value="{{ old('login', \Illuminate\Support\Facades\Cookie::get('remembered_login')) }}"
                                required
                                autocomplete="username"
                                autofocus
                                placeholder="you@email.com or phone"
                            >
                        </div>

                        <div class="mb-5">
                            <label class="block text-sm font-medium text-white/80 mb-2" for="password">Password</label>
                            <div class="relative">
                                <input
                                    class="w-full rounded-xl border border-white/20 bg-white/10 px-4 py-3 pr-10 text-white placeholder:text-white/40 focus:border-indigo-400/60 focus:outline-none focus:ring-2 focus:ring-indigo-500/40"
                                    id="password"
                                    type="password"
                                    name="password"
                                    value="{{ \Illuminate\Support\Facades\Cookie::get('remembered_password') }}"
                                    required
                                    autocomplete="current-password"
                                    placeholder="••••••••"
                                >
                                <button type="button" 
                                    onmousedown="document.getElementById('password').type='text'; this.querySelector('i').classList.replace('fa-eye', 'fa-eye-slash');" 
                                    onmouseup="document.getElementById('password').type='password'; this.querySelector('i').classList.replace('fa-eye-slash', 'fa-eye');" 
                                    onmouseleave="document.getElementById('password').type='password'; this.querySelector('i').classList.replace('fa-eye-slash', 'fa-eye');" 
                                    ontouchstart="document.getElementById('password').type='text'; this.querySelector('i').classList.replace('fa-eye', 'fa-eye-slash');" 
                                    ontouchend="document.getElementById('password').type='password'; this.querySelector('i').classList.replace('fa-eye-slash', 'fa-eye');" 
                                    class="absolute inset-y-0 right-0 flex items-center pr-3 text-white/50 hover:text-white focus:outline-none">
                                    <i class="fas fa-eye"></i>
                                </button>
                            </div>
                            <div class="text-right mt-2">
                                <a href="{{ route('password.request') }}" class="text-sm font-medium text-indigo-200 hover:text-white">Forgot password?</a>
                            </div>
                        </div>

                        <div class="mb-6">
                            <label class="inline-flex items-center gap-2 text-sm text-white/80 cursor-pointer">
                                <input type="checkbox" name="remember" class="h-4 w-4 rounded border-white/30 bg-white/10 text-indigo-600 focus:ring-indigo-500 focus:ring-offset-0" {{ \Illuminate\Support\Facades\Cookie::has('remembered_login') ? 'checked' : '' }}>
                                Remember me
                            </label>
                        </div>

                        <button type="submit" class="w-full flex items-center justify-center gap-2 rounded-lg bg-white px-4 py-3 text-base font-semibold text-indigo-700 shadow transition hover:bg-indigo-50">
                            <i class="fas fa-sign-in-alt"></i>
                            Login
                        </button>

                        <p class="mt-6 text-center text-sm text-white/70">
                            Don&apos;t have an account?
                            <a href="{{ route('client.register') }}" class="font-semibold text-white hover:underline">Register</a>
                        </p>
                    </form>
                </div>

                <p class="text-center mt-6 text-xs text-white/50">
                    <a href="{{ route('client.register') }}" class="text-indigo-200 hover:text-white">Get started</a>
                </p>
            </div>
        </div>

        <p class="text-center mt-8 text-xs text-white/45 px-4">
            <a href="{{ route('public.privacy') }}" class="hover:text-white/90">Privacy</a>
            <span class="mx-2">·</span>
            <a href="{{ route('public.terms') }}" class="hover:text-white/90">Terms</a>
            <span class="mx-2">·</span>
            <a href="{{ route('public.home') }}" class="hover:text-white/90">Marketing site</a>
        </p>
    </div>
</body>
</html>
