@extends('layouts.client')

@section('title', 'Pre-wedding countdown')

@section('content')
@php
    $themeHints = [
        'misty_dusk' => 'Cool dusk & serif',
        'golden_hour' => 'Warm amber glow',
        'garden_bloom' => 'Botanical colour',
        'midnight_rose' => 'Rose on dark',
        'coastal_fog' => 'Airy ocean blue',
        'saffron_edge' => 'Cream & saffron',
        'lavender_veil' => 'Soft violet',
        'cherry_romance' => 'Deep romantic red',
        'ivory_script' => 'Ivory & script',
        'modern_mono' => 'Bold minimal',
        'blush_arch' => 'Pink blush',
        'emerald_night' => 'Emerald jewel',
        'sunset_warm' => 'Sunset orange',
        'royal_plum' => 'Royal purple',
        'paper_minimal' => 'Clean paper',
        'celebration_gold' => 'Gold celebration',
    ];
@endphp

<div class="max-w-6xl mx-auto">
    <div class="mb-6">
        <h1 class="cb-page-title">Pre-wedding countdown</h1>
        <p class="cb-subtitle max-w-3xl">Upload a different photo for each milestone — every card uses its <strong>own layout, colours, and typography</strong>. Download a high-resolution PNG for Instagram, WhatsApp, or printing.</p>
        @if($showDemoOnly)
            @php $pwPack = number_format((float) config('packs.celebration.amount_inr', 300), 0); @endphp
            <div class="mt-4 rounded-xl border border-amber-200 bg-amber-50/80 px-4 py-3 text-sm text-amber-950">
                <p class="font-semibold mb-2">Preview mode — celebration pack not active on this account yet.</p>
                <p class="text-amber-900/90 mb-3">Below are <strong>demo thumbnails</strong> only. Pay <strong>₹{{ $pwPack }}</strong> on Razorpay with the <strong>same email or phone</strong> as your login, then refresh this page.</p>
                <a href="{{ route('client.packs.celebration.pay') }}" data-loader="payment" class="cb-btn cb-btn--gold cb-btn--sm inline-flex">
                    <i class="fas fa-arrow-up-right-from-square text-xs" aria-hidden="true"></i> Pay ₹{{ $pwPack }} celebration pack
                </a>
            </div>
        @endif
    </div>

    @if(!$showDemoOnly)
    <div class="cb-card p-5 sm:p-6 mb-8 border border-slate-200/90">
        <h2 class="text-sm font-bold text-cb-navy uppercase tracking-wide mb-3">Wedding date (optional)</h2>
        <p class="text-sm text-slate-600 mb-4">For your reference on this page only — cards use the milestone text you pick, not auto-calculated days.</p>
        <form action="{{ route('client.pre-wedding.settings') }}" method="POST" class="flex flex-wrap items-end gap-3">
            @csrf
            <div>
                <label for="wedding_date" class="block text-xs font-semibold text-slate-600 mb-1">Date</label>
                <input type="date" name="wedding_date" id="wedding_date" value="{{ $setting->wedding_date?->format('Y-m-d') }}"
                       class="rounded-lg border border-slate-200 px-3 py-2 text-sm text-cb-navy">
            </div>
            <button type="submit" class="cb-btn cb-btn--navy cb-btn--sm">Save date</button>
        </form>
    </div>
    @endif

    @if($errors->has('pack'))
        <div class="mb-6 rounded-xl border border-rose-200 bg-rose-50 text-rose-900 text-sm px-4 py-3">{{ $errors->first('pack') }}</div>
    @endif

    <div class="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-5">
        @if($showDemoOnly)
            @include('client.pre-wedding.partials.demo-milestone-cards', ['milestones' => $milestones, 'themeHints' => $themeHints])
        @else
        @foreach($milestones as $key => $m)
            @php
                $asset = $assets->get($key);
                $hasPhoto = $asset && $asset->image_path && \Illuminate\Support\Facades\Storage::disk('public')->exists($asset->image_path);
                $thumb = $hasPhoto ? \Illuminate\Support\Facades\Storage::disk('public')->url($asset->image_path) : null;
                $theme = $m['theme'] ?? '';
            @endphp
            <div class="cb-card p-4 sm:p-5 border border-slate-200/90 flex flex-col gap-4">
                <div class="flex flex-wrap items-start justify-between gap-2">
                    <div>
                        <h3 class="font-bold text-cb-navy text-base">{{ $m['label'] }}</h3>
                        <p class="text-xs text-violet-700 font-medium mt-1">{{ $themeHints[$theme] ?? $theme }}</p>
                    </div>
                    @if($hasPhoto)
                        <span class="inline-flex items-center rounded-full bg-emerald-100 text-emerald-800 text-xs font-semibold px-2.5 py-0.5">Photo saved</span>
                    @else
                        <span class="inline-flex items-center rounded-full bg-slate-100 text-slate-600 text-xs font-medium px-2.5 py-0.5">No photo yet</span>
                    @endif
                </div>

                <div class="relative rounded-xl overflow-hidden border border-slate-200 bg-slate-100 aspect-[9/16] max-h-56 w-full sm:max-w-[240px]">
                    <iframe
                        src="{{ route('client.pre-wedding.thumbnail-preview', ['milestoneKey' => $key]) }}"
                        title="{{ $m['label'] }} preview"
                        loading="lazy"
                        class="pointer-events-none absolute inset-0 h-full w-full border-0"
                        referrerpolicy="no-referrer-when-downgrade"
                    ></iframe>
                </div>

                <form action="{{ route('client.pre-wedding.upload') }}" method="POST" enctype="multipart/form-data" class="space-y-2">
                    @csrf
                    <input type="hidden" name="milestone_key" value="{{ $key }}">
                    <label class="block text-xs font-semibold text-slate-600">Upload image (JPG, PNG, WebP · max 15&nbsp;MB)</label>
                    <input type="file" name="photo" accept="image/jpeg,image/png,image/jpg,image/webp" required
                           class="block w-full text-sm text-slate-600 file:mr-3 file:rounded-lg file:border-0 file:bg-amber-100 file:px-3 file:py-2 file:text-sm file:font-semibold file:text-amber-900">
                    <button type="submit" class="cb-btn cb-btn--gold cb-btn--sm w-full sm:w-auto justify-center">
                        <i class="fas fa-cloud-arrow-up" aria-hidden="true"></i> Save photo for this card
                    </button>
                </form>

                <div class="flex flex-wrap gap-2 pt-2 border-t border-slate-100">
                    <a href="{{ route('client.pre-wedding.card', ['milestoneKey' => $key]) }}" target="_blank" rel="noopener"
                       class="cb-btn cb-btn--ghost cb-btn--sm border border-slate-200 flex-1 min-w-[8rem] justify-center">
                        <i class="fas fa-eye text-xs" aria-hidden="true"></i> Preview
                    </a>
                    <a href="{{ route('client.pre-wedding.export.png', ['milestoneKey' => $key]) }}" target="_blank" rel="noopener"
                       class="cb-btn cb-btn--navy cb-btn--sm flex-1 min-w-[8rem] justify-center">
                        <i class="fas fa-download text-xs" aria-hidden="true"></i> Download PNG
                    </a>
                </div>
                @if(!$hasPhoto)
                    <p class="text-xs text-slate-500">Without a photo, the card uses a simple gradient background until you upload one.</p>
                @endif
            </div>
        @endforeach
        @endif
    </div>
</div>
@endsection
