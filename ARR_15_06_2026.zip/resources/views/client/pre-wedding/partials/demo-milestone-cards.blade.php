@foreach($milestones as $key => $m)
    @php
        $theme = $m['theme'] ?? '';
    @endphp
    <div class="cb-card p-4 sm:p-5 border border-slate-200/90 flex flex-col gap-4 relative overflow-hidden">
        <span class="absolute top-2 right-2 z-10 inline-flex items-center gap-1 rounded-full bg-slate-900/75 text-white text-[0.65rem] font-semibold px-2 py-0.5 backdrop-blur-sm">
            <i class="fas fa-lock text-[0.6rem]" aria-hidden="true"></i> Demo
        </span>
        <div class="flex flex-wrap items-start justify-between gap-2">
            <div>
                <h3 class="font-bold text-cb-navy text-base">{{ $m['label'] }}</h3>
                <p class="text-xs text-violet-700 font-medium mt-1">{{ $themeHints[$theme] ?? $theme }}</p>
            </div>
        </div>
        <div class="relative rounded-xl overflow-hidden border border-slate-200 bg-slate-100 aspect-[9/16] max-h-56 w-full">
            <iframe
                src="{{ route('client.pre-wedding.thumbnail-preview', ['milestoneKey' => $key]) }}"
                title="{{ $m['label'] }} preview"
                loading="lazy"
                class="pointer-events-none absolute inset-0 h-full w-full border-0"
                referrerpolicy="no-referrer-when-downgrade"
            ></iframe>
        </div>
        <p class="text-xs text-slate-600 leading-relaxed">{{ $m['quote'] ?? '' }}</p>
        <p class="text-xs text-amber-800 font-medium">Pay the celebration pack to upload your photo and download real PNGs for each milestone.</p>
    </div>
@endforeach
