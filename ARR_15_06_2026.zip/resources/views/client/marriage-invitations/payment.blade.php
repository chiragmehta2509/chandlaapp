@extends('layouts.client')

@section('title', 'Pay for invitation card')

@section('content')
<div class="mb-6">
    <a href="{{ route('client.marriage-invitations.show', $invitation->id) }}" class="cb-link text-sm inline-flex items-center gap-2 mb-2">← Back to card</a>
    <h1 class="cb-page-title">Pay ₹{{ number_format($amount, 0) }}</h1>
    <p class="cb-subtitle max-w-2xl">Pay with <strong>Razorpay</strong> — when payment succeeds, your card unlocks automatically (usually within seconds). Use the <strong>same email</strong> as your Chandla Book account at checkout.</p>
</div>

@if ($errors->has('pay'))
    <div class="mb-6 rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-950">{{ $errors->first('pay') }}</div>
@endif

@if (trim((string) ($rzpLink ?? '')) !== '')
    <div class="cb-card p-6 sm:p-8 mb-8 border-2 border-emerald-200/80 bg-gradient-to-br from-emerald-50/90 via-white to-white max-w-2xl">
        <p class="text-xs font-bold uppercase tracking-wider text-emerald-800 mb-2">Recommended</p>
        <h2 class="text-xl font-bold text-cb-navy mb-2">Pay ₹{{ number_format($amount, 0) }} with Razorpay</h2>
        <p class="text-sm text-slate-600 mb-6 leading-relaxed">Opens Razorpay’s secure checkout. After payment is captured, you can open and download every layout — <strong>no admin confirmation</strong>.</p>
        <a href="{{ route('client.marriage-invitations.payment.razorpay', $invitation->id) }}" class="cb-btn cb-btn-gold w-full sm:w-auto justify-center px-8 py-3.5 text-base shadow-lg ring-1 ring-amber-400/40">
            <i class="fas fa-arrow-up-right-from-square text-xs mr-2" aria-hidden="true"></i>
            Continue to Razorpay
        </a>
        <p class="text-xs text-slate-500 mt-4">Configured Payment Link amount should match ₹{{ number_format((float) config('marriage_invitations.amount', 300), 0) }} for this card.</p>
    </div>
@else
    <div class="rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-950 mb-8 max-w-2xl">
        Set <code class="bg-white/80 px-1 rounded text-xs">MARRIAGE_INVITATION_RAZORPAY_LINK</code> in <code class="bg-white/80 px-1 rounded text-xs">.env</code> or rely on the default in config.
    </div>
@endif

<p class="text-sm font-semibold text-slate-700 mb-4 max-w-2xl">Manual UPI (slower)</p>
<p class="text-sm text-slate-600 mb-6 max-w-2xl">Pay from your bank app and submit the reference below — our team verifies before unlock.</p>

<div class="grid grid-cols-1 lg:grid-cols-2 gap-6 max-w-5xl">
    <div class="cb-card p-5 sm:p-6">
        <h2 class="text-lg font-bold text-cb-navy mb-4">UPI QR</h2>
        <p class="text-sm text-slate-600 mb-2">Amount</p>
        <p class="text-2xl font-bold text-cb-navy">₹{{ number_format($amount, 2) }}</p>
        <div class="mt-4">
            @if($qrSvg)
                <div class="bg-slate-50 border border-slate-200 rounded-xl p-4 inline-block">
                    {!! $qrSvg !!}
                </div>
                <p class="text-xs text-slate-500 mt-2">UPI: {{ $upiId }}</p>
            @else
                <div class="rounded-lg border border-amber-200 bg-amber-50 text-amber-900 px-4 py-3 text-sm">
                    Set <code class="bg-white/80 px-1 rounded">UPI_ID</code> in <code class="bg-white/80 px-1 rounded">.env</code>.
                </div>
            @endif
        </div>
    </div>
    <div class="cb-card p-5 sm:p-6">
        <h2 class="text-lg font-bold text-cb-navy mb-4">Submit transaction ID</h2>
        <form method="POST" action="{{ route('client.marriage-invitations.payment.store', $invitation->id) }}" class="space-y-4">
            @csrf
            <div>
                <label class="cb-label !normal-case !text-slate-600 !text-sm" for="transaction_id">UPI reference / transaction ID</label>
                <input type="text" name="transaction_id" id="transaction_id" value="{{ old('transaction_id') }}" class="cb-field" required placeholder="From bank or GPay">
            </div>
            <button type="submit" class="cb-btn cb-btn-navy w-full justify-center py-3">Submit for verification</button>
        </form>
    </div>
</div>
@endsection
