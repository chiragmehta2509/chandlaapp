<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#312e81">
    @stack('head')
    <title>@yield('page_title', 'Chandla Book')</title>
    <link rel="stylesheet" href="{{ asset('css/tailwind.css') }}?v=2">
    <link rel="stylesheet" href="{{ asset('css/cb-loader.css') }}?v=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="{{ asset('js/cb-loader.js') }}?v=1" defer></script>
    <link rel="icon" type="image/png" href="{{ asset('images/chandla-favicon.png') }}">
    <link rel="apple-touch-icon" href="{{ asset('images/chandla-app-icon.png') }}">
</head>
<body class="min-h-screen flex flex-col bg-gradient-to-br from-indigo-950 via-purple-900 to-slate-950 text-white">
    <header class="max-w-6xl w-full mx-auto px-4 sm:px-6 py-4 flex items-center justify-between shrink-0">
        <a href="{{ route('public.home') }}" class="flex items-center gap-2 sm:gap-3 group">
            <img src="{{ asset('images/chandla-favicon.png') }}" alt="Chandla Book" class="h-10 sm:h-12 w-auto" width="48" height="48" decoding="async">
            <span class="text-lg sm:text-2xl font-bold text-white group-hover:text-white/90">Chandla Book</span>
        </a>
        <a href="{{ route('public.home') }}" class="text-sm text-white/80 hover:text-white font-medium">
            ← Home
        </a>
    </header>

    <main class="flex-1 w-full max-w-6xl mx-auto px-4 sm:px-6 pb-10">
        @yield('content')
    </main>

    <footer class="shrink-0 text-center text-xs text-white/55 pb-8 px-4">
        <div class="mb-4 space-x-3">
            @unless(View::hasSection('omit_footer_marketing_link'))
                <a href="{{ route('public.home') }}" class="hover:text-white transition-colors">Marketing site</a>
                <span class="text-white/35">·</span>
            @endunless
            <a href="{{ route('public.contact') }}" class="hover:text-white transition-colors">Contact</a>
            <span class="text-white/35">·</span>
            <a href="{{ route('public.privacy') }}" class="hover:text-white transition-colors">Privacy</a>
            <span class="text-white/35">·</span>
            <a href="{{ route('public.terms') }}" class="hover:text-white transition-colors">Terms</a>
        </div>
        <div class="text-white/40 flex flex-col items-center gap-1">
            <span>All rights reserved to SkyLight Technologies</span>
            <span class="flex items-center gap-1.5 mt-1">
                Developed with <i class="fa-solid fa-heart text-red-500 text-[10px]" aria-hidden="true"></i> by
                <a href="https://skylighttech.in/" target="_blank" rel="noopener noreferrer" class="font-medium hover:text-white transition-colors underline decoration-white/20 underline-offset-2 hover:decoration-white/70">SkyLight Technologies</a>
            </span>
        </div>
    </footer>
    @stack('scripts')
</body>
</html>
