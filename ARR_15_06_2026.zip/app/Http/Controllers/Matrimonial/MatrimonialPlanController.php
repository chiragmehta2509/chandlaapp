<?php

namespace App\Http\Controllers\Matrimonial;

use App\Http\Controllers\Controller;
use App\Models\MatrimonialPlan as MatrimonialPlanModel;
use App\Support\MatrimonialPlan;
use App\Support\RazorpayTestAmount;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use Razorpay\Api\Api;

class MatrimonialPlanController extends Controller
{
    public function showPlans()
    {
        $user = Auth::user();
        $active = MatrimonialPlan::activePlanFor($user->id);
        $plans = config('matrimonial.plans', []);

        return view('client.matrimonial.plans', compact('active', 'plans'));
    }

    /**
     * Optional: legacy Razorpay Orders API checkout (not used when only payment links are shown).
     */
    public function createOrder(Request $request)
    {
        $keys = array_keys(config('matrimonial.plans', []));
        $request->validate([
            'plan' => 'required|in:' . implode(',', $keys),
        ]);

        $planKey = $request->input('plan');
        $planDef = config("matrimonial.plans.{$planKey}");
        if (!$planDef) {
            abort(400);
        }

        $key = config('services.razorpay.key_id');
        $secret = config('services.razorpay.key_secret');
        if (empty($key) || empty($secret)) {
            return response()->json(['message' => 'Payment gateway is not configured.'], 503);
        }

        $api = new Api($key, $secret);
        $amountPaise = RazorpayTestAmount::resolve((int) round((float) $planDef['price_inr'] * 100));
        $receipt = 'm_' . Auth::id() . '_' . Str::lower(Str::random(8));

        $order = $api->order->create([
            'receipt' => $receipt,
            'amount' => $amountPaise,
            'currency' => 'INR',
            'payment_capture' => 1,
        ]);

        return response()->json([
            'order_id' => $order['id'],
            'amount' => $amountPaise,
            'key_id' => $key,
        ]);
    }

    public function verify(Request $request)
    {
        $keys = array_keys(config('matrimonial.plans', []));
        $validated = $request->validate([
            'plan' => 'required|in:' . implode(',', $keys),
            'razorpay_order_id' => 'required|string|max:64',
            'razorpay_payment_id' => 'required|string|max:64',
            'razorpay_signature' => 'required|string|max:255',
        ]);

        $planDef = config("matrimonial.plans.{$validated['plan']}");
        if (!$planDef) {
            abort(400);
        }

        $key = config('services.razorpay.key_id');
        $secret = config('services.razorpay.key_secret');
        if (empty($secret)) {
            return back()->withErrors(['payment' => 'Payment verification unavailable.']);
        }

        if (MatrimonialPlanModel::where('payment_id', $validated['razorpay_payment_id'])->exists()) {
            return redirect()->route('client.matrimonial.plans')->with('success', 'This payment was already applied.');
        }

        $api = new Api($key, $secret);
        try {
            $fetched = $api->order->fetch($validated['razorpay_order_id']);
            $expectedPaise = RazorpayTestAmount::resolve((int) round((float) $planDef['price_inr'] * 100));
            if (isset($fetched['amount']) && (int) $fetched['amount'] !== $expectedPaise) {
                return back()->withErrors(['payment' => 'Order amount does not match the selected plan.']);
            }
        } catch (\Throwable $e) {
            return back()->withErrors(['payment' => 'Could not confirm your order with the payment provider.']);
        }

        try {
            $api->utility->verifyPaymentSignature([
                'razorpay_order_id' => $validated['razorpay_order_id'],
                'razorpay_payment_id' => $validated['razorpay_payment_id'],
                'razorpay_signature' => $validated['razorpay_signature'],
            ]);
        } catch (\Throwable $e) {
            return back()->withErrors(['payment' => 'Payment verification failed. If money was debited, contact support with your UPI/transaction id.']);
        }

        $start = Carbon::today();
        $months = max(1, (int) ($planDef['months'] ?? 1));
        $expiry = (clone $start)->addMonths($months)->endOfDay();

        MatrimonialPlanModel::create([
            'user_id' => Auth::id(),
            'plan_type' => $validated['plan'],
            'price' => (float) $planDef['price_inr'],
            'start_date' => $start,
            'expiry_date' => $expiry->toDateString(),
            'payment_id' => $validated['razorpay_payment_id'],
            'razorpay_order_id' => $validated['razorpay_order_id'],
        ]);

        return redirect()
            ->route('client.matrimonial.index')
            ->with('success', 'Your plan is active. You can now view full profiles and send interests.');
    }
}
