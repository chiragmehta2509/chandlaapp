<?php

namespace App\Http\Controllers\Public;

use App\Http\Controllers\Controller;

class SeoController extends Controller
{
    /**
     * Plain-text robots.txt — keeps crawl rules aligned with APP_URL when deployed.
     */
    public function robots()
    {
        $lines = [
            'User-agent: *',
            'Allow: /',
            'Disallow: /admin/',
            '',
            'Sitemap: '.url('/sitemap.xml'),
        ];

        return response(implode("\n", $lines), 200)
            ->header('Content-Type', 'text/plain; charset=UTF-8');
    }

    /**
     * Minimal XML sitemap for public marketing/legal URLs.
     */
    public function sitemap()
    {
        $urls = [
            url('/'),
            route('public.contact'),
            route('public.privacy'),
            route('public.terms'),
        ];

        return response()
            ->view('public.sitemap-xml', compact('urls'))
            ->header('Content-Type', 'application/xml; charset=UTF-8');
    }

    /**
     * Public marketing contact (no auth).
     */
    public function contact()
    {
        return view('public.contact');
    }
}
