<?php

namespace App\Http\Controllers\Client;

use App\Http\Controllers\Controller;
use App\Models\MarriageInvitation;
use App\Support\RazorpayTestAmount;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\View\View;

class PackPurchaseController extends Controller
{
    /**
     * Redirect to Razorpay Payment Link (celebration ₹300). Payer should use the same email or phone as their Chandla Book account so the webhook can unlock features.
     */
    public function celebrationRedirect(): RedirectResponse
    {
        $user = Auth::user();
        if ($user && $user->planLevel() >= 1) {
            return redirect()
                ->route('client.plans')
                ->withErrors(['pack' => 'You already have this plan or a higher plan active.']);
        }

        $this->stashTestIntent('celebration');
        return $this->redirectToPaymentUrl((string) config('packs.celebration.payment_url'));
    }

    /**
     * Redirect to Razorpay Payment Link (₹700 bundle: celebration + ledger unlimited scope + PDF).
     */
    public function bundleRedirect(): RedirectResponse
    {
        $user = Auth::user();
        if ($user && $user->planLevel() >= 5) {
            return redirect()
                ->route('client.plans')
                ->withErrors(['pack' => 'You already have this plan or a higher plan active.']);
        }

        $this->stashTestIntent('premium_bundle');
        return $this->redirectToPaymentUrl((string) config('packs.premium_bundle.payment_url'));
    }

    /** Host Duo pack — ₹500, 2 events + unlimited chandla (configure PACK_LEDGER_DUO_RAZORPAY_URL). */
    public function hostDuoRedirect(): RedirectResponse
    {
        $user = Auth::user();
        if ($user && $user->planLevel() >= 3) {
            return redirect()
                ->route('client.plans')
                ->withErrors(['pack' => 'You already have this plan or a higher plan active.']);
        }

        $this->stashTestIntent('ledger_duo');
        return $this->redirectToPaymentUrl((string) config('packs.ledger_duo.payment_url'));
    }

    /** Family pack — ₹600, ledger features + 3 family editor accounts (configure PACK_FAMILY_RAZORPAY_URL). */
    public function familyRedirect(): RedirectResponse
    {
        $user = Auth::user();
        if ($user && $user->planLevel() >= 4) {
            return redirect()
                ->route('client.plans')
                ->withErrors(['pack' => 'You already have this plan or a higher plan active.']);
        }

        $this->stashTestIntent('family');
        return $this->redirectToPaymentUrl((string) config('packs.family.payment_url'));
    }

    /** Single-event Guest pay pack — ₹400, credit applied on “Unlock Direct QR” (configure PACK_GUEST_PAY_SINGLE_RAZORPAY_URL). */
    public function guestPaySingleRedirect(): RedirectResponse
    {
        $user = Auth::user();
        if ($user && $user->planLevel() >= 2) {
            return redirect()
                ->route('client.plans')
                ->withErrors(['pack' => 'You already have this plan active.']);
        }

        $this->stashTestIntent('guest_pay_single');
        return $this->redirectToPaymentUrl((string) config('packs.guest_pay_single.payment_url'));
    }

    // getUserLedgerLevel() removed since it's replaced by User->planLevel()

    /**
     * Thanks page — also the Razorpay test-mode callback target.
     * If a test intent is stashed and a razorpay_payment_id is present, apply the unlock.
     */
    public function thanks(Request $request): View|RedirectResponse
    {
        $applied = $this->maybeApplyTestIntent($request);

        return view('client.packs.thanks', [
            'appliedKind' => $applied,
            'razorpayPaymentId' => $request->query('razorpay_payment_id') ?: $request->query('razorpay_payment_link_id'),
        ]);
    }

    /**
     * Stash a pending payment intent in session — used in test mode where the shared
     * Razorpay Payment Link has no way to encode which pack was bought. The thanks
     * page reads it after redirect and unlocks the matching feature.
     */
    private function stashTestIntent(string $kind): void
    {
        if (!RazorpayTestAmount::hasTestPaymentLink()) {
            return;
        }
        $user = Auth::user();
        if (!$user) {
            return;
        }
        session([
            'rzp_test_intent' => [
                'kind' => $kind,
                'user_id' => $user->dataOwnerId(),
                'created_at' => now()->timestamp,
            ],
        ]);
    }

    /**
     * On the thanks page, if a stashed test intent matches the current user and a
     * Razorpay payment id is present in the callback URL, unlock the pack/plan and
     * clear the intent. Returns the applied kind, or null if nothing was applied.
     */
    private function maybeApplyTestIntent(Request $request): ?string
    {
        $paymentId = $request->query('razorpay_payment_id') ?: $request->query('razorpay_payment_link_id');
        if (!$paymentId) {
            return null; // no proof of payment — don't unlock
        }

        /** @var \App\Models\User|null $user */
        $user = Auth::user();
        if (!$user) {
            return null;
        }
        $ownerId = $user->dataOwnerId();

        // Secure live/test payment verification via Razorpay API if keys are configured
        $verified = false;
        $key = (string) config('services.razorpay.key_id');
        $secret = (string) config('services.razorpay.key_secret');
        if ($key !== '' && $secret !== '') {
            try {
                $api = new \Razorpay\Api\Api($key, $secret);
                $payment = $api->payment->fetch($paymentId);
                $paymentArray = $payment->toArray();

                $status = $paymentArray['status'] ?? '';
                if (in_array($status, ['captured', 'authorized'], true)) {
                    // Check if payment belongs to the logged in user
                    $payerUser = \App\Support\RazorpayPayerUser::findFromPayment($paymentArray);
                    if ($payerUser && (int) $payerUser->id === (int) $ownerId) {
                        $verified = true;
                    }
                }
            } catch (\Throwable $e) {
                \Illuminate\Support\Facades\Log::warning('Razorpay thanks page payment verification failed: ' . $e->getMessage());
            }
        }

        // If not verified via API, only allow local auto-unlock in test mode
        if (!$verified) {
            if (!RazorpayTestAmount::hasTestPaymentLink()) {
                return null;
            }
        }
        
        // Check reference_id from query first to support direct links, fall back to session intent
        $refId = (string) $request->query('razorpay_payment_link_reference_id');
        $kind = null;
        $eventId = null;
        $invitationId = null;

        if ($refId !== '') {
            if (str_starts_with($refId, 'test_celebration')) {
                $kind = 'celebration';
            } elseif (str_starts_with($refId, 'test_ledger_duo')) {
                $kind = 'ledger_duo';
            } elseif (str_starts_with($refId, 'test_family')) {
                $kind = 'family';
            } elseif (str_starts_with($refId, 'test_premium_bundle')) {
                $kind = 'premium_bundle';
            } elseif (str_starts_with($refId, 'test_guest_pay_single')) {
                $kind = 'guest_pay_single';
            } elseif (str_starts_with($refId, 'test_marriage_inv')) {
                $kind = 'marriage_inv';
            } elseif (str_starts_with($refId, 'test_matrimonial_500')) {
                $kind = 'matrimonial_500';
            } elseif (str_starts_with($refId, 'test_matrimonial_200')) {
                $kind = 'matrimonial_200';
            }
        }

        // Fall back to session if reference_id didn't yield a match
        if ($kind === null) {
            $intent = session('rzp_test_intent');
            if (is_array($intent) && !empty($intent['kind'])) {
                // Check user matches
                if ((int) ($intent['user_id'] ?? 0) === (int) $ownerId) {
                    // 1 hour TTL
                    if ((time() - (int) ($intent['created_at'] ?? 0)) <= 3600) {
                        $kind = (string) $intent['kind'];
                        $eventId = $intent['event_id'] ?? null;
                        $invitationId = $intent['invitation_id'] ?? null;
                    }
                }
            }
        }

        if ($kind === null) {
            return null;
        }

        $now = now();

        try {
            DB::transaction(function () use ($kind, $ownerId, $now, $paymentId, $eventId, $invitationId) {
                /** @var \App\Models\User $owner */
                $owner = \App\Models\User::findOrFail($ownerId);

                // Create PackPaymentReceipt if it's a pack purchase
                if (in_array($kind, ['celebration', 'ledger_duo', 'family', 'premium_bundle', 'guest_pay_single'], true)) {
                    $amountInr = (float) config("packs.{$kind}.amount_inr", 0);
                    \App\Models\PackPaymentReceipt::firstOrCreate([
                        'razorpay_payment_id' => $paymentId,
                    ], [
                        'user_id' => $ownerId,
                        'pack_type' => $kind,
                        'amount_paise' => (int) round($amountInr * 100),
                    ]);
                }

                switch ($kind) {
                    case 'celebration':
                        $owner->celebration_pack_paid_at ??= $now;
                        break;
                    case 'ledger_duo':
                        $owner->ledger_duo_pack_paid_at ??= $now;
                        break;
                    case 'family':
                        $owner->family_pack_paid_at ??= $now;
                        $owner->ledger_duo_pack_paid_at ??= $now;
                        break;
                    case 'premium_bundle':
                        $owner->premium_bundle_paid_at ??= $now;
                        $owner->celebration_pack_paid_at ??= $now;
                        $owner->ledger_duo_pack_paid_at ??= $now;
                        $owner->family_pack_paid_at ??= $now;
                        MarriageInvitation::where('user_id', $owner->id)
                            ->whereNull('paid_at')
                            ->update(['paid_at' => $now]);
                        break;
                    case 'guest_pay_single':
                        $owner->guest_pay_single_event_credits = (int) ($owner->guest_pay_single_event_credits ?? 0) + 1;
                        break;
                    case 'event_unlimited':
                        $evId = $eventId;
                        if ($evId > 0) {
                            $event = \App\Models\Event::where('id', $evId)
                                ->where('user_id', $ownerId)
                                ->first();
                            if ($event) {
                                \App\Services\EventUnlimitedRazorpayCompletion::applyIfNeeded(
                                    $event,
                                    $ownerId,
                                    $paymentId,
                                    null
                                );
                            }
                        }
                        break;
                    case 'marriage_inv':
                        $invId = $invitationId;
                        if (!$invId) {
                            $unpaidInv = MarriageInvitation::where('user_id', $ownerId)
                                ->whereNull('paid_at')
                                ->orderByDesc('created_at')
                                ->first();
                            if ($unpaidInv) {
                                $invId = $unpaidInv->id;
                            }
                        }
                        if ($invId > 0) {
                            $invitation = MarriageInvitation::where('id', $invId)
                                ->where('user_id', $ownerId)
                                ->first();
                            if ($invitation) {
                                $invitation->update(['paid_at' => $now]);
                                
                                $amount = (float) $invitation->amount;
                                $tx = \App\Models\UPITransaction::firstOrCreate([
                                    'transaction_id' => $paymentId,
                                ], [
                                    'user_id' => $ownerId,
                                    'event_id' => null,
                                    'razorpay_payment_id' => $paymentId,
                                    'amount' => $amount,
                                    'status' => 'completed',
                                    'payment_method' => 'card',
                                    'description' => 'Marriage invitation template unlock (Razorpay)',
                                    'paid_at' => $now,
                                    'metadata' => [
                                        'type' => 'marriage_invitation',
                                        'marriage_invitation_id' => $invitation->id,
                                        'source' => 'razorpay',
                                    ],
                                ]);
                                
                                $invitation->upi_transaction_id = $tx->id;
                                $invitation->save();
                            }
                        }
                        break;
                    case 'matrimonial_500':
                    case 'matrimonial_200':
                        $planType = $kind === 'matrimonial_500' ? '500' : '200';
                        $planDef = config("matrimonial.plans.{$planType}");
                        if ($planDef) {
                            $start = \Carbon\Carbon::today();
                            $months = max(1, (int) ($planDef['months'] ?? 1));
                            $expiry = (clone $start)->addMonths($months)->endOfDay();
                            
                            $exists = \App\Models\MatrimonialPlan::where('payment_id', $paymentId)->exists();
                            if (!$exists) {
                                \App\Models\MatrimonialPlan::create([
                                    'user_id' => $ownerId,
                                    'plan_type' => $planType,
                                    'price' => (float) $planDef['price_inr'],
                                    'start_date' => $start,
                                    'expiry_date' => $expiry->toDateString(),
                                    'payment_id' => $paymentId,
                                ]);
                            }
                        }
                        break;
                }
                $owner->save();
            });
        } catch (\Throwable $e) {
            report($e);
            return null;
        }

        session()->forget('rzp_test_intent');
        return $kind;
    }

    private function redirectToPaymentUrl(string $base): RedirectResponse
    {
        $url = trim($base);
        if ($url === '') {
            return redirect()
                ->route('client.dashboard')
                ->withErrors(['pack' => 'Payment link is not configured.']);
        }

        $email = Auth::user()?->email;
        if (is_string($email) && $email !== '' && filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $url .= (str_contains($url, '?') ? '&' : '?').'email='.rawurlencode($email);
        }

        return redirect()->away($url);
    }
}
